#ifndef MINECRAFT_FOG_GLSL
#define MINECRAFT_FOG_GLSL

// 슈퍼로봇대전: 물 밖(환경 안개가 긴 곳)은 지수 연무 + 번개 밝기(밤 팔레트), 물속·실명 등 짧은 안개는 바닐라 그대로
#include <minecraft:globals.glsl>

layout(std140) uniform Fog {
    vec4 FogColor;
    float FogEnvironmentalStart;
    float FogEnvironmentalEnd;
    float FogRenderDistanceStart;
    float FogRenderDistanceEnd;
    float FogSkyEnd;
    float FogCloudsEnd;
};

#include <srw:srw_atmos.glsl>

float linear_fog_value(float vertexDistance, float fogStart, float fogEnd) {
    if (vertexDistance <= fogStart) {
        return 0.0;
    } else if (vertexDistance >= fogEnd) {
        return 1.0;
    }

    return (vertexDistance - fogStart) / (fogEnd - fogStart);
}

float total_fog_value(float sphericalVertexDistance, float cylindricalVertexDistance, float environmentalStart, float environmantalEnd, float renderDistanceStart, float renderDistanceEnd) {
    return max(linear_fog_value(sphericalVertexDistance, environmentalStart, environmantalEnd), linear_fog_value(cylindricalVertexDistance, renderDistanceStart, renderDistanceEnd));
}

vec4 apply_fog(vec4 inColor, float sphericalVertexDistance, float cylindricalVertexDistance, float environmentalStart, float environmantalEnd, float renderDistanceStart, float renderDistanceEnd, vec4 fogColor) {
    if (environmantalEnd < 60.0) {
        float fogValue = total_fog_value(sphericalVertexDistance, cylindricalVertexDistance, environmentalStart, environmantalEnd, renderDistanceStart, renderDistanceEnd);
        return vec4(mix(inColor.rgb, fogColor.rgb, fogValue * fogColor.a), inColor.a);
    }
    // OIT 누적 단계는 fogColor 가 알파로 미리 곱해져 옴 → 같은 비율을 연무색에도
    float m = max(max(FogColor.r, FogColor.g), FogColor.b);
    float k = m > 1e-5 ? max(max(fogColor.r, fogColor.g), fogColor.b) / m : 1.0;
    float edge = smoothstep(renderDistanceEnd * srwEdge.x, renderDistanceEnd * srwEdge.y, cylindricalVertexDistance);
    float f = max(max(srwHazeAmount(sphericalVertexDistance / srwDesertVis()), edge), srwDesertDust(sphericalVertexDistance)); // 사막 = 연무 거리 ÷ 배율, 먼지 안개 360 한계
    return vec4(mix(inColor.rgb, srwHazeColor(srwFlash() * (1.0 - edge)) * k, f), inColor.a);
}

float fog_spherical_distance(vec3 pos) {
    return length(pos);
}

float fog_cylindrical_distance(vec3 pos) {
    float distXZ = length(pos.xz);
    float distY = abs(pos.y);
    return max(distXZ, distY);
}

#endif
