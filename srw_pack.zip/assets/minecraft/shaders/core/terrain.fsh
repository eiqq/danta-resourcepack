#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:fog.glsl>
#include <minecraft:globals.glsl>
#include <minecraft:texture_sampling.glsl>
#include <minecraft:oit.glsl>
#include <minecraft:terrainglobals.glsl>
#ifndef MULTIDRAW_TERRAIN
    #include <minecraft:chunksection.glsl>
#endif
#include <srw:srw_data.glsl>

uniform sampler2D Sampler0;

layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
layout(location = 2) in vec4 vertexColor;
layout(location = 3) in vec2 texCoord0;
layout(location = 4) in float chunkVisibility;
layout(location = 5) in vec3 srwRel;

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

vec4 calculateFinalColor(vec4 color) {
    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif
    return apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
}

// 슈퍼로봇대전 바다는 후처리(srw_light.fsh)가 그림 — 지형 셰이더를 바꾸는 Sodium 이어도 똑같이 보이게.
// 여기선 중립 바탕만(물 텍스처 알파 228 = 물 표시): 탁한 깊은 물색, 거의 불투명(해저가 안 비침). 후처리가 없을 때(데이터 줄 없음)의 모습이기도 함
vec3 srwWater(vec3 rel, out float alpha) {
    float night = srwNight();
    alpha = 0.93;
    return mix(vec3(0.05, 0.11, 0.13), SRW_NIGHT_SEA, night) * (1.0 + srwFlash() * 1.5);
}

void main() {
    vec4 tex = UseRgss == 1 ? sampleRGSS(Sampler0, texCoord0, 1.0f / TextureSize) : sampleNearest(Sampler0, texCoord0, 1.0f / TextureSize);
    vec4 color = tex * vertexColor;
    #ifdef OIT
    if (srwDataPixel()) {
        discard;
    }
    #endif
    if (abs(tex.a - 228.0 / 255.0) < 0.004 && float(CameraBlockPos.y) - CameraOffset.y > SRW_SEA_Y) { // 물 위에서 볼 때만
        float a;
        color.rgb = srwWater(srwRel, a);
        color.a = a;
    }
    #ifndef OIT_ALPHA_ONLY
    color = mix(vec4(mix(FogColor.rgb, SRW_NIGHT_FOG, srwNight()), FogColor.a) * vec4(1, 1, 1, color.a), color, chunkVisibility); // 새 청크 나타날 때 밤 연무색으로
    #endif
    #ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
    #endif

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    srwFogDir = normalize(srwRel);
    fragColor = calculateFinalColor(color);
    #endif
}
