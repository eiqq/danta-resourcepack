#version 330
#extension GL_ARB_separate_shader_objects : require

// 바닐라 26.3 text.fsh + 보스바 HUD(IS_GUI, text.vsh 가 표시한 글자만): 계기는 효과 없이 선명하게, 레이더는 도는 쓸기 빛,
// 맞으면 지지직, 선체 위험이면 화면 가장자리 붉은 맥동(crtInfo.x 종류 — text.vsh).

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>
#ifdef IS_GUI
#include <minecraft:globals.glsl>
#endif

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#endif

layout(location = 2) in vec4 vertexColor;
layout(location = 3) in vec2 texCoord0;
#ifdef IS_GUI
layout(location = 4) in vec4 crtInfo;
layout(location = 5) in vec2 crtCenter;
#endif

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

vec4 calculateFinalColor(vec4 color) {
    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    #endif

    #if !defined(IS_SEE_THROUGH) && !defined(IS_GUI)

    #ifdef OIT_ACCUMULATE
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    color = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
    #endif

    return color;
}

void main() {
    #ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
    #else
    vec4 texColor = texture(Sampler0, texCoord0);
    #endif

    vec4 color = texColor * vertexColor * ColorModulator;

    float srwCut = 0.1; // 이보다 옅으면 버림(바닐라 0.1)
    #ifdef IS_GUI
    if (crtInfo.x > 6.75) { // 선체 위험(25% 아래): 화면 가장자리 붉은 맥동, 가운데는 비움 — text.vsh 가 글리프 하나를 화면 전체로 늘림(crtCenter = 화면 크기)
        float t = GameTime * 1200.0;
        vec2 px = min(crtInfo.zw, (crtCenter - crtInfo.zw) * vec2(1.0, 1.8)); // 가장자리까지(GUI 칸) — 아래쪽 띠는 얇게(단축바 아이콘을 덜 덮음)
        float e = 1.0 - smoothstep(0.0, crtCenter.y * 0.24, min(px.x * 0.8, px.y));
        float beat = 0.55 + 0.45 * pow(0.5 + 0.5 * sin(t * 5.2), 2.0);       // 약 1.2초 맥동
        color = vec4(1.0, 0.10, 0.06, vertexColor.a * e * e * beat * 0.52);
        srwCut = 0.004;
    } else if (crtInfo.x > 5.5) { // 관전 HUD(선명): 효과 없음. 글자 = 진한 칸만 그 색, 번짐 칸은 어두운 외곽선(밝은 배경에서도 읽힘)
        if (crtInfo.x < 6.25 && texColor.a < 0.6) {
            color = vec4(0.0, 0.0, 0.0, 0.6 * smoothstep(0.05, 0.35, texColor.a));
        }
    } else if (crtInfo.x > 1.5 && crtInfo.x < 2.5) { // 조종석 계기는 효과 없이 선명하게(유저 11/08 — 예전 주사선·간섭 띠·깜빡임 뺌). 레이더만 쓸기
        float t = GameTime * 1200.0;
        { // 레이더: 3초에 한 바퀴(시계 방향) 쓸기, 지나간 자리는 잔광
            vec2 d = crtInfo.zw - crtCenter;
            float a = atan(d.x, -d.y);                                        // 위 = 0, 시계 방향 +
            float lag = mod(t * 2.0943951 - a, 6.2831853);                   // 쓸기 선에서 뒤로 얼마나
            color.rgb *= 0.65 + 0.9 * exp(-lag * 2.2);
        }
    }
    float srwGl = crtInfo.x > 0.5 && crtInfo.x < 5.0 ? floor(fract(crtInfo.x) * 10.0 + 0.5) : 0.0; // 조종석 피격 지지직 세기(text.vsh)
    if (srwGl > 0.5) {
        float t = GameTime * 1200.0;
        float rn = fract(sin(floor(crtInfo.y * 0.5) * 12.9898 + floor(t * 40.0) * 78.233) * 43758.5453);
        if (rn < 0.1 * srwGl) {
            discard; // 가로줄이 통째로 끊김
        }
        float pn = fract(sin(dot(floor(gl_FragCoord.xy * 0.5) + floor(t * 60.0), vec2(12.9898, 78.233))) * 43758.5453);
        color.rgb *= 0.7 + 0.6 * pn;                                                               // 지지직 밝기 잡음
        color.rgb = mix(color.rgb, vec3(1.0, 0.32, 0.25), step(0.93 - 0.05 * srwGl, pn) * 0.6);    // 붉은 잡음 점
    }
    #endif

    if (color.a < srwCut) {
        discard;
    }

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}
