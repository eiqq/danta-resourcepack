#version 330
#extension GL_ARB_separate_shader_objects : require

// 바닐라 26.3 text.fsh + 보스바 계기판(IS_GUI, text.vsh 가 표시한 글자만): 주사선·깜빡임·내려가는 밝은 띠, 레이더는 도는 쓸기 빛.

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>
#ifdef IS_GUI
#include <minecraft:globals.glsl>
#endif

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#endif

layout(location = 2) in vec4 vertexColor;
layout(location = 3) in vec2 texCoord0;
#ifdef IS_GUI
layout(location = 4) in vec4 crtInfo;
layout(location = 5) in vec2 crtCenter;
#endif

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

vec4 calculateFinalColor(vec4 color) {
    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    #endif

    #if !defined(IS_SEE_THROUGH) && !defined(IS_GUI)

    #ifdef OIT_ACCUMULATE
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    color = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
    #endif

    return color;
}

void main() {
    #ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
    #else
    vec4 texColor = texture(Sampler0, texCoord0);
    #endif

    vec4 color = texColor * vertexColor * ColorModulator;

    #ifdef IS_GUI
    if (crtInfo.x > 5.5) { // 관전 HUD(선명): 효과 없음. 글자 = 진한 칸만 그 색, 번짐 칸은 어두운 외곽선(밝은 배경에서도 읽힘)
        if (crtInfo.x < 6.25 && texColor.a < 0.6) {
            color = vec4(0.0, 0.0, 0.0, 0.6 * smoothstep(0.05, 0.35, texColor.a));
        }
    } else if (crtInfo.x > 3.5) { // 홀로그램(조종석): 가는 줄, 위로 흐르는 간섭 띠, 가끔 어두워짐, 살짝 비침
        float t = GameTime * 1200.0;
        float scan = fract(crtInfo.y * 0.5) < 0.5 ? 1.0 : 0.8;
        float band = exp(-pow((fract(crtInfo.y / 46.0 + t * 0.4) - 0.5) * 10.0, 2.0));
        float dip = fract(sin(floor(t * 16.0) * 12.9898) * 43758.5453) > 0.92 ? 0.7 : 1.0;
        color.rgb *= scan * dip * (1.0 + 0.4 * band);
        color.a *= 0.86 + 0.14 * band;
    } else if (crtInfo.x > 0.5 && crtInfo.x < 2.5) {
        float t = GameTime * 1200.0;
        float scan = fract(crtInfo.y) < 0.66 ? 1.0 : 0.6;                                // GUI 픽셀마다 어두운 줄
        float band = exp(-pow((fract(crtInfo.y / 70.0 - t * 0.12) - 0.5) * 9.0, 2.0)); // 천천히 내려가는 밝은 띠
        float flick = 0.94 + 0.06 * sin(t * 47.0) * sin(t * 7.3);
        color.rgb *= scan * flick * (1.08 + 0.22 * band);
        if (crtInfo.x > 1.5) { // 레이더: 3초에 한 바퀴(시계 방향) 쓸기, 지나간 자리는 잔광
            vec2 d = crtInfo.zw - crtCenter;
            float a = atan(d.x, -d.y);                                        // 위 = 0, 시계 방향 +
            float lag = mod(t * 2.0943951 - a, 6.2831853);                   // 쓸기 선에서 뒤로 얼마나
            color.rgb *= 0.65 + 0.9 * exp(-lag * 2.2);
        }
    }
    float srwGl = crtInfo.x > 0.5 && crtInfo.x < 5.0 ? floor(fract(crtInfo.x) * 10.0 + 0.5) : 0.0; // 조종석 피격 지지직 세기(text.vsh)
    if (srwGl > 0.5) {
        float t = GameTime * 1200.0;
        float rn = fract(sin(floor(crtInfo.y * 0.5) * 12.9898 + floor(t * 40.0) * 78.233) * 43758.5453);
        if (rn < 0.1 * srwGl) {
            discard; // 가로줄이 통째로 끊김
        }
        float pn = fract(sin(dot(floor(gl_FragCoord.xy * 0.5) + floor(t * 60.0), vec2(12.9898, 78.233))) * 43758.5453);
        color.rgb *= 0.7 + 0.6 * pn;                                                               // 지지직 밝기 잡음
        color.rgb = mix(color.rgb, vec3(1.0, 0.32, 0.25), step(0.93 - 0.05 * srwGl, pn) * 0.6);    // 붉은 잡음 점
    }
    #endif

    if (color.a < 0.1) {
        discard;
    }

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}
