#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>
#include <srw:srw_data.glsl>

uniform sampler2D Sampler0;

layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
layout(location = 2) in vec2 texCoord0;
layout(location = 3) in vec4 vertexColor;
layout(location = 4) in vec3 srwWorld;

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

vec4 calculateFinalColor(vec4 color) {
    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif
    return apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
}

bool isRain() {
    return textureSize(Sampler0, 0) == ivec2(128, 512);
}

void main() {
    if (srwDataPixel()) {
        discard;
    }
    vec4 color = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
    if (isRain()) {
        vec4 t = texture(Sampler0, texCoord0);
        float flash = srwFlash();
        float night = srwNight();
        vec3 day = mix(vec3(0.62, 0.68, 0.74), vec3(1.0), flash * 0.6) * (0.85 + flash);
        vec3 nite = mix(vec3(0.26, 0.30, 0.36), vec3(0.95, 1.0, 1.05), flash * 0.7) * (1.0 + flash * 1.5);
        // 돌풍 띠: 바람 따라 흘러가는 짙은 비 막(세계 좌표 잡음)
        float tt = srwSeconds();
        vec2 g = srwWorld.xz * 0.035 - SRW_WIND * tt * 0.9;
        float sheet = smoothstep(0.32, 0.72, srwFbm(g + vec2(srwWorld.y * 0.01), 3));
        float a = t.a * vertexColor.a * ColorModulator.a * mix(0.45, 1.15, sheet);
        color = vec4(mix(day, nite, night), a);
    }
    if (color.a < 0.1) {
        discard;
    }
    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    srwFogDir = normalize(srwWorld - (vec3(CameraBlockPos) - CameraOffset));
    fragColor = calculateFinalColor(color);
    #endif
}
