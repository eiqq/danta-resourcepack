#version 330
#extension GL_ARB_separate_shader_objects : require

// 밤 폭풍 하늘: 두꺼운 구름층(영역 뒤틀린 fbm) + 빠르게 흐르는 낮은 구름, 수평선은 먼 바다보다 밝게(하늘·바다 경계),
// 번개 = 그쪽 구름 속이 번쩍(얇은 곳이 더 밝게) + 처음 0.3초는 번개 줄기, 수평선 근처 빗줄기 기둥.
// 수평선 아래(sky.vsh 가 원판을 원뿔로 늘림) = 먼 연무색 → 렌더 거리 끝 바다와 이어짐.
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>

layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
layout(location = 2) in vec3 skyDir;

layout(location = 0) out vec4 fragColor;

const float PI = 3.14159265;

vec3 daySky(vec3 d, float flash) {
    float up = clamp(d.y, 0.0, 1.0);
    float fl = flash * smoothstep(0.0, 0.2, up);
    vec3 col = mix(srwHazeColor(fl), ColorModulator.rgb * 0.62 * (1.0 + fl * 0.9), smoothstep(0.02, 0.55, up));
    vec2 uv = d.xz / (max(d.y, 0.0) + 0.12) * 1.4 + vec2(srwSeconds() * 0.004, srwSeconds() * 0.0017);
    float c = srwFbm(uv, 5);
    col *= mix(0.78, 1.12, c) * mix(1.0, 0.9, up);
    col += SRW_FLASH * fl * (0.15 + 0.85 * pow(max(dot(d, srwFlashDir()), 0.0), 5.0)) * mix(0.6, 1.3, c);
    return col;
}

vec3 nightSky(vec3 d, float flash) {
    float t = srwSeconds();
    float up = d.y;
    vec3 base = srwNightSky(d);
    // 구름 평면 좌표(가까운 머리 위는 크게, 수평선 쪽은 촘촘히)
    vec2 uv = d.xz / (max(up, 0.0) + 0.06);
    vec2 drift = SRW_WIND * t * (0.010 + 0.004 * srwGust(t));
    vec2 q = uv * 0.5 + drift;
    vec2 wq = vec2(srwFbm(q * 1.4 + vec2(1.7, 9.2), 4), srwFbm(q * 1.4 + vec2(8.3, 2.8), 4));
    float deck = srwFbm(q + wq * 1.8, 5);
    float scud = srwFbm(uv * 1.6 + drift * 3.4 + wq * 0.8, 4);
    float dens = smoothstep(0.30, 0.74, deck);
    float sd = smoothstep(0.52, 0.82, scud);
    float fade = smoothstep(0.0, 0.25, up);
    vec3 c = mix(base, mix(SRW_NIGHT_CLOUD_HI, SRW_NIGHT_CLOUD_LO, dens), 0.9 * fade);
    c = mix(c, SRW_NIGHT_CLOUD_LO * 0.75, sd * 0.65 * fade);
    // 수평선 근처: 멀리 내리는 빗줄기 기둥(세로 결)
    float a = atan(d.z, d.x);
    float shaft = srwFbm(vec2(a * 10.0 + drift.x * 0.3, up * 2.0 - t * 0.04), 3);
    float band = smoothstep(-0.01, 0.02, up) * (1.0 - smoothstep(0.03, 0.22, up));
    c *= 1.0 - 0.28 * smoothstep(0.45, 0.75, shaft) * band;
    // 번개: 그쪽 구름 속이 번쩍(얇은 곳·뒤틀린 결을 따라)
    vec3 fd = srwFlashDir();
    float az = dot(normalize(d.xz + vec2(1e-5)), normalize(fd.xz));
    float near = pow(max(az, 0.0), 6.0) * smoothstep(-0.02, 0.3, up) * (1.0 - 0.6 * smoothstep(0.35, 0.9, up));
    float glow = near * (0.3 + 1.3 * (1.0 - dens) + 0.9 * wq.x);
    c += SRW_FLASH * flash * (0.06 + 1.7 * glow);
    // 번개 줄기(친 직후 0.3초): 구름 밑(고도 ~0.3)에서 수평선까지 지그재그 + 가지
    int seed;
    float age = srwFlashAge(seed);
    if (age < 0.32 && up > -0.01 && up < 0.34) {
        float fa = atan(fd.z, fd.x) + (srwHashI(seed * 4 + 7) - 0.5) * 0.35;
        float da = mod(a - fa + PI, 2.0 * PI) - PI;
        float s = float(seed % 997);
        float off = (srwFbm(vec2(up * 16.0, s), 4) - 0.5) * 0.11 + (srwFbm(vec2(up * 70.0, s + 3.0), 3) - 0.5) * 0.025;
        float w = 0.0012 + 0.004 * smoothstep(0.34, 0.0, up) * 0.5;
        float core = exp(-abs(da - off) / w);
        float off2 = off + (srwFbm(vec2(up * 22.0, s + 9.0), 3) - 0.5) * 0.16 * smoothstep(0.26, 0.08, up);
        core += 0.55 * exp(-abs(da - off2) / (w * 0.7)) * step(up, 0.22) * step(0.05, up);
        float life = exp(-age * 12.0) + 0.8 * step(0.15, age) * exp(-(age - 0.15) * 22.0);
        float hal = exp(-abs(da - off) / (w * 14.0)) * 0.12;
        c += vec3(0.82, 0.88, 1.0) * (core + hal) * life * 2.6 * smoothstep(0.34, 0.26, up);
    }
    // 수평선 아래 = 먼 연무(지형 안개 끝과 같은 색)
    vec3 below = SRW_NIGHT_FOG;
    return mix(below, c, smoothstep(-0.012, 0.008, up));
}

void main() {
    vec3 d = normalize(skyDir);
    float flash = srwFlash();
    float night = srwNight();
    vec3 col = night < 0.999 ? daySky(d, flash) : vec3(0.0);
    if (night > 0.001) {
        col = mix(col, nightSky(d, flash), night);
    }
    fragColor = vec4(col, 1.0);
}
