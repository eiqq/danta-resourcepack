#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:sample_lightmap.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec2 UV0;
layout(location = 2) in vec4 Color;
layout(location = 3) in ivec2 UV2;

uniform sampler2D Sampler0;
uniform sampler2D Sampler2;

layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
layout(location = 2) out vec2 texCoord0;
layout(location = 3) out vec4 vertexColor;
layout(location = 4) out vec3 srwWorld;

void main() {
    vec3 pos = Position;
    // 비(빗줄기 텍스처 128×512): 기둥 사각형을 바람 쪽으로 기울임 → 위는 바람 위쪽, 아래는 바람 아래쪽(비바람).
    // 텍스처가 기둥을 따라 흐르므로 빗줄기도 비스듬히 떨어짐. 기울기는 돌풍 따라 출렁임
    if (textureSize(Sampler0, 0) == ivec2(128, 512)) {
        float t = srwSeconds();
        float lean = 0.32 + 0.42 * srwGust(t);
        pos.xz -= SRW_WIND * pos.y * lean;
    }
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    sphericalVertexDistance = fog_spherical_distance(pos);
    cylindricalVertexDistance = fog_cylindrical_distance(pos);
    texCoord0 = UV0;
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
    srwWorld = pos + vec3(CameraBlockPos) - CameraOffset;
}
