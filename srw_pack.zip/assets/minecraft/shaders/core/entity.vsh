#version 330
#extension GL_ARB_separate_shader_objects : require

#if defined(PER_FACE_LIGHTING) || !defined(NO_CARDINAL_LIGHTING)
#include <minecraft:light.glsl>
#endif
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:sample_lightmap.glsl>

// 슈퍼로봇대전: 26.3 바닐라 entity 셰이더 + 조종사 모형(스킨 부위) 변환.
// 조종사 모형 = 부위마다 그 조종사 프로필의 player_head 아이템 디스플레이 하나(PilotDoll.java). 머리 상자(8×8×8)를
//   디스플레이 변환의 배율로 팔·다리·몸통 모양으로 늘이고, 변환의 평행이동 y 에 −1024 × 부위 번호를 더해 보냄 →
//   여기서 번호를 읽어 제자리로 되돌리고(정점), 조각 셰이더가 머리 UV 를 그 부위의 스킨 UV 로 바꿈.
// (자비스 GCB 팩·ModelEngine 의 플레이어 팔다리 기법을 옮겨 옴 — 위·아래 반쪽으로 나눈 팔다리를 더함)
// 스킨 부위 번호가 없는 것(바닐라 엔티티·보통 머리)은 바닐라 그대로.
#if defined(ALPHA_CUTOUT) && !defined(EMISSIVE) && !defined(NO_OVERLAY) && !defined(APPLY_TEXTURE_MATRIX)
#define SRW_PILOT 1
#endif

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
layout(location = 3) in ivec2 UV1;
layout(location = 4) in ivec2 UV2;
layout(location = 5) in vec3 Normal;

#ifdef SRW_PILOT
uniform sampler2D Sampler0;
#endif

#if !defined(NO_OVERLAY) && !defined(OIT_ALPHA_ONLY)
uniform sampler2D Sampler1;
#endif

#if !defined(EMISSIVE) && !defined(OIT_ALPHA_ONLY)
uniform sampler2D Sampler2;
#endif

layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;

#ifdef PER_FACE_LIGHTING
layout(location = 2) out vec4 vertexPerFaceColorBack;
layout(location = 3) out vec4 vertexPerFaceColorFront;
#else
layout(location = 2) out vec4 vertexColor;
#endif

#ifndef EMISSIVE
layout(location = 4) out vec4 lightMapColor;
#endif

#ifndef NO_OVERLAY
layout(location = 5) out vec4 overlayColor;
#endif

layout(location = 6) out vec2 texCoord0;
#ifdef GLINT
layout(location = 7) out vec2 texCoordGlint;
#endif

#ifdef SRW_PILOT
layout(location = 9) flat out int srwPart; // 0 = 보통, 1~13 = 조종사 모형 부위(entity.fsh 표)
#define SRW_SPACING 1024.0
#define SRW_PARTS 13
#endif

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);

#ifdef PER_FACE_LIGHTING
    vec2 light = minecraft_compute_light(Light0_Direction, Light1_Direction, Normal);
    vertexPerFaceColorBack = minecraft_mix_light_separate(-light, Color);
    vertexPerFaceColorFront = minecraft_mix_light_separate(light, Color);
#elif defined(NO_CARDINAL_LIGHTING)
    vertexColor = Color;
#else
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
#endif

#if !defined(EMISSIVE) && !defined(OIT_ALPHA_ONLY)
    lightMapColor = sample_lightmap(Sampler2, UV2);
#endif

#if !defined(NO_OVERLAY) && !defined(OIT_ALPHA_ONLY)
    overlayColor = texelFetch(Sampler1, UV1, 0);
#endif

    texCoord0 = UV0;

#ifdef APPLY_TEXTURE_MATRIX
    texCoord0 = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
#endif

#ifdef GLINT
    texCoordGlint = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
#endif

#ifdef SRW_PILOT
    srwPart = 0;
    // 세계 투영(GUI 아님) · 64×64 텍스처(플레이어 스킨) · 안개 값 정상(손 그리기 아님)일 때만
    if (abs(ProjMat[2][3]) > 1e-5 && textureSize(Sampler0, 0) == ivec2(64) && FogRenderDistanceEnd > FogRenderDistanceStart) {
        // 부위 번호 = 카메라 기준 y 가 −1024 × 번호 근처(±512)에 있음. 번호 0 = 옮기지 않은 보통 것
        int k = -int((Position.y - 0.5 * SRW_SPACING) / SRW_SPACING);
        if (k > 0 && k <= SRW_PARTS) {
            srwPart = k;
            vec3 wpos = Position + vec3(0.0, SRW_SPACING * float(k), 0.0);
            gl_Position = ProjMat * ModelViewMat * vec4(wpos, 1.0);
            sphericalVertexDistance = fog_spherical_distance(wpos);
            cylindricalVertexDistance = fog_cylindrical_distance(wpos);
        }
    }
#endif
}
