#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

layout(location = 0) in vec3 Position;

layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
layout(location = 2) out vec3 skyDir;

void main() {
    vec3 pos = Position;
    // 하늘 원판(높이 16, 반지름 512)의 테두리를 수평선 아래로 끌어내려 원뿔로 → 수평선 밑까지 하늘 셰이더가 칠함
    // (원래는 위 1.8° 까지만 덮고 그 아래는 바닐라 지움 색 → 수평선 색을 마음대로 못 정했음)
    if (pos.y > 0.0 && length(pos.xz) > 100.0) {
        pos.y = -220.0;
    }
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    sphericalVertexDistance = fog_spherical_distance(pos);
    cylindricalVertexDistance = fog_cylindrical_distance(pos);
    skyDir = pos;
}
