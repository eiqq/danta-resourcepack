#version 330
#extension GL_ARB_separate_shader_objects : require

#ifdef GLINT
#include <minecraft:globals.glsl>
#endif
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>
#ifndef OIT
#include <minecraft:projection.glsl>
#include <srw:srw_robot.glsl>
#else
#include <srw:srw_data.glsl>
#endif

uniform sampler2D Sampler0;

#ifdef GLINT
uniform sampler2D GlintSampler;
#endif

#ifndef OIT_ALPHA_ONLY
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#endif
layout(location = 2) in vec4 vertexColor;
#ifndef OIT_ALPHA_ONLY
layout(location = 3) in vec4 lightMapColor;
layout(location = 4) in vec4 overlayColor;
#endif
layout(location = 5) in vec2 texCoord0;
#ifdef GLINT
layout(location = 6) in vec2 texCoordGlint;
#endif
#ifndef OIT
layout(location = 7) flat in ivec2 srwMat;
layout(location = 8) in vec3 srwPos;
layout(location = 9) flat in ivec2 srwMk;
layout(location = 10) flat in vec3 srwMkPos;
#endif

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

#ifndef OIT_ALPHA_ONLY
vec4 calculateFinalColor(vec4 color) {
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
    color *= lightMapColor;

    #ifdef GLINT
    vec4 glintColor = GlintAlpha * texture(GlintSampler, texCoordGlint);// Glint color modulator?
    // Matches BlendFuntion.GLINT
    color.rgb += glintColor.rgb * glintColor.rgb;
    #endif

    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    return apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
}
#endif

void main() {
    #ifndef OIT
    // 조명 표식 = 데이터 줄(후처리가 읽음)
    if (srwMk.x > 0) {
        fragColor = vec4(srwMarkerColor(srwMk, srwMkPos), 1.0);
        return;
    }
    #endif
    vec4 color = texture(Sampler0, texCoord0);
    #ifndef OIT
    SrwFrag srw = srwGather(Sampler0, texCoord0, srwMat, srwPos);
    #else
    if (srwDataPixel()) {
        discard;
    }
    #endif
    #ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
    #endif

    #ifndef OIT
    if (srwMat.x == SRW_FLAT) { // 고정색(개틀링 예광탄): 빛·안개 없이 그대로
        fragColor = vec4(color.rgb, 1.0);
        return;
    }
    if (srwMat.x > 0) {
        float emis;
        vec3 n = srwNormal(srw, srwPos, emis);
        srwFogDir = normalize(srwPos);
        bool glow = srwMat.x == SRW_GLOW;
        vec3 lit = glow ? color.rgb * 1.55 : srwLight(color.rgb, n, srwPos, emis);
        vec4 fogged = apply_fog(vec4(lit, 1.0), sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
        // 빛나는 곳(발광 유리·발광 텍셀)은 안개를 뚫고 먼저 보임: 안개 정도를 srwFogGlow 로 줄여 섞음
        float g = glow ? 1.0 : smoothstep(0.15, 0.6, emis);
        if (g > 0.0 && FogEnvironmentalEnd >= 60.0) {
            float f = srwHazeAmount(sphericalVertexDistance);
            vec3 hz = srwHazeColor(0.0);
            vec3 thru = mix(lit, hz, srwFogGlow(f));
            fogged.rgb = mix(fogged.rgb, thru, g);
        }
        fragColor = fogged;
        return;
    }
    #endif

    color *= vertexColor * ColorModulator;

    #ifdef GLINT
    color.a = max(color.a, GlintAlpha);
    #endif

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}
