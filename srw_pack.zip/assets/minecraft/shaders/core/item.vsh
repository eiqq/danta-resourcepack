#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:light.glsl>
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:sample_lightmap.glsl>
#ifndef OIT
#define SRW_VERTEX
#include <srw:srw_robot.glsl>
#endif

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
layout(location = 3) in ivec2 UV1;
layout(location = 4) in ivec2 UV2;
#ifdef GLINT_SPECIAL
layout(location = 5) in vec2 UV3;
#endif
layout(location = 6) in vec3 Normal;

#ifndef OIT_ALPHA_ONLY
uniform sampler2D Sampler1;
uniform sampler2D Sampler2;

layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif
layout(location = 2) out vec4 vertexColor;
#ifndef OIT_ALPHA_ONLY
layout(location = 3) out vec4 lightMapColor;
layout(location = 4) out vec4 overlayColor;
#endif

layout(location = 5) out vec2 texCoord0;
#ifdef GLINT
layout(location = 6) out vec2 texCoordGlint;
#endif
#ifndef OIT
layout(location = 7) flat out ivec2 srwMat;
layout(location = 8) out vec3 srwPos;
layout(location = 9) flat out ivec2 srwMk;    // 조명 표식: x = 종류 + 1(0 = 아님), y = 조명 칸
layout(location = 10) flat out vec3 srwMkPos; // 표식 위치(카메라 기준)
#endif

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    #ifndef OIT_ALPHA_ONLY
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    #endif
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
    #ifndef OIT_ALPHA_ONLY
    lightMapColor = sample_lightmap(Sampler2, UV2);
    overlayColor = texelFetch(Sampler1, UV1, 0);
    #endif

    texCoord0 = UV0;
    #ifndef OIT
    srwMat = srwMaterial(Color);
    srwPos = Position;
    srwMk = ivec2(0);
    srwMkPos = Position;
    if (srwMat.x > 0) {
        vertexColor = vec4(1.0);
    }
    // 조명 표식: 작은 사각형을 화면 맨 아래 줄 정해진 칸으로 옮김(가장 가까운 깊이 → 항상 보임)
    ivec3 mc = ivec3(round(Color.rgb * 255.0));
    if (mc.r == SRW_MARKER && Color.a > 0.99) {
        int kind = mc.b;
        srwMk = ivec2(kind + 1, mc.g);
        int x0 = kind == 2 ? 0 : 32 + mc.g * 8 + (kind == 0 ? 0 : 4);
        int w = kind == 2 ? 32 : (kind == 0 ? 4 : 3);
        int k = gl_VertexIndex % 4;
        float px = float(x0 + ((k == 1 || k == 2) ? w : 0));
        float py = k >= 2 ? 1.0 : 0.0;
        vec4 nearClip = ProjMat * vec4(0.0, 0.0, -0.1, 1.0);
        gl_Position = vec4(px / ScreenSize.x * 2.0 - 1.0, py / ScreenSize.y * 2.0 - 1.0, nearClip.z / nearClip.w, 1.0);
    }
    #endif
    #ifdef GLINT
    #ifdef GLINT_SPECIAL
    texCoordGlint = (TextureMat * vec4(UV3, 0.0, 1.0)).xy;
    #else
    texCoordGlint = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
    #endif
    #endif
}
