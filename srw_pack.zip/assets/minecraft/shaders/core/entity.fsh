#version 330
#extension GL_ARB_separate_shader_objects : require

#ifdef GLINT
#include <minecraft:globals.glsl>
#endif
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>
#ifdef OIT
#include <srw:srw_data.glsl>
#endif

uniform sampler2D Sampler0;

// 슈퍼로봇대전: 조종사 모형(스킨 부위) — entity.vsh 설명 참고
#if defined(ALPHA_CUTOUT) && !defined(EMISSIVE) && !defined(NO_OVERLAY) && !defined(APPLY_TEXTURE_MATRIX)
#define SRW_PILOT 1
#endif

#ifdef DISSOLVE
uniform sampler2D DissolveMaskSampler;
#endif

#ifdef GLINT
uniform sampler2D GlintSampler;
#endif

layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#ifdef PER_FACE_LIGHTING
layout(location = 2) in vec4 vertexPerFaceColorBack;
layout(location = 3) in vec4 vertexPerFaceColorFront;
#else
layout(location = 2) in vec4 vertexColor;
#endif

#ifndef EMISSIVE
layout(location = 4) in vec4 lightMapColor;
#endif

#ifndef NO_OVERLAY
layout(location = 5) in vec4 overlayColor;
#endif

layout(location = 6) in vec2 texCoord0;
#ifdef GLINT
layout(location = 7) in vec2 texCoordGlint;
#endif

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

#ifdef SRW_PILOT
layout(location = 9) flat in int srwPart;

// 겉옷 층(스킨 둘째 층)의 반투명 화소: 가까이서는 점 무늬로, 멀면 불투명(바탕 층과 섞은 색)
#define SRW_FADE_FAR 12.0
#define SRW_FADE_NEAR 8.0
#define SRW_MIN_ALPHA 0.25
const mat4 srwBayer = mat4(0.0 / 16.0, 8.0 / 16.0, 2.0 / 16.0, 10.0 / 16.0,
                           12.0 / 16.0, 4.0 / 16.0, 14.0 / 16.0, 6.0 / 16.0,
                           3.0 / 16.0, 11.0 / 16.0, 1.0 / 16.0, 9.0 / 16.0,
                           15.0 / 16.0, 7.0 / 16.0, 13.0 / 16.0, 5.0 / 16.0);

// 부위(0 오른팔 · 1 왼팔 · 2 몸통 · 3 오른다리 · 4 왼다리)의 스킨 전개도 원점(px): xy = 바탕 층, zw = 겉옷 층
const vec4[] srwOrigin = vec4[](
    vec4(40.0, 16.0, 40.0, 32.0),
    vec4(32.0, 48.0, 48.0, 48.0),
    vec4(16.0, 16.0, 16.0, 32.0),
    vec4(0.0, 16.0, 0.0, 32.0),
    vec4(16.0, 48.0, 0.0, 48.0));

// 머리 전개도 8px 칸 → 면(0 위 · 1 아래 · 2 오른 옆 · 3 앞 · 4 왼 옆 · 5 뒤). 칸 번호 = (가로 % 4) + 4 × 세로
const int[] srwFace = int[](0, 0, 1, 1, 2, 3, 4, 5);

// 부위 번호(1~13): 1·2 오른팔 위·아래, 3·4 왼팔 위·아래, 5~8 = 가는 팔(슬림 스킨) 같은 순서, 9 몸통,
//   10·11 오른다리 위·아래, 12·13 왼다리 위·아래.
// 팔다리 위 반쪽 = 전개도 0~8줄(8px — 관절 너머 2px 까지 덮어 굽힌 모서리가 안 비게), 아래 반쪽 = 6~12줄(6px).
// 머리 상자의 조각이 놓인 칸(면·층)과 칸 안 위치를 그 부위 상자(가로 w × 세로 12 × 깊이 4)의 같은 면으로 옮김.
void srwPilotUV(int k, vec2 headUV, out vec2 uvOut, out vec2 uvUnder) {
    bool slim = k >= 5 && k <= 8;
    int limb;
    bool lower;
    if (k <= 8) {
        int a = (k - 1) % 4;
        limb = a / 2;
        lower = (a % 2) == 1;
    } else if (k == 9) {
        limb = 2;
        lower = false;
    } else {
        limb = 3 + (k - 10) / 2;
        lower = ((k - 10) % 2) == 1;
    }
    float w = limb == 2 ? 8.0 : (slim ? 3.0 : 4.0);
    float d = 4.0;
    float r0 = 0.0;
    float r1 = 12.0;
    if (limb != 2) {
        if (lower) {
            r0 = 6.0;
        } else {
            r1 = 8.0;
        }
    }
    vec2 g = headUV * 8.0;
    vec2 cell = floor(g);
    vec2 inCell = clamp(g - cell, 0.0, 1.0);
    int cx = int(cell.x);
    int cy = int(cell.y);
    int face = srwFace[clamp((cx % 4) + 4 * cy, 0, 7)];
    vec4 rect;
    if (face == 0) {
        rect = vec4(d, 0.0, d + w, d);
    } else if (face == 1) {
        rect = vec4(d + w, 0.0, d + 2.0 * w, d);
    } else if (face == 2) {
        rect = vec4(0.0, d + r0, d, d + r1);
    } else if (face == 3) {
        rect = vec4(d, d + r0, d + w, d + r1);
    } else if (face == 4) {
        rect = vec4(d + w, d + r0, 2.0 * d + w, d + r1);
    } else {
        rect = vec4(2.0 * d + w, d + r0, 2.0 * d + 2.0 * w, d + r1);
    }
    // 자른 끝 면(위 반쪽의 아래 뚜껑 · 아래 반쪽의 위 뚜껑): 손바닥·발바닥 그림 대신 앞면의 관절 자리 두 줄(소매·바지 색)
    if (limb != 2 && ((face == 1 && !lower) || (face == 0 && lower))) {
        rect = vec4(d, d + 6.0, d + w, d + 8.0);
    }
    vec2 off = mix(rect.xy, rect.zw, inCell);
    vec4 org = srwOrigin[limb];
    uvUnder = (org.xy + off) / 64.0;
    uvOut = ((cx >= 4 ? org.zw : org.xy) + off) / 64.0;
}
#endif

vec4 calculateFinalColor(vec4 color) {
    #ifndef NO_OVERLAY
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
    #endif

    #ifndef EMISSIVE
    color *= lightMapColor;
    #endif

    #ifdef GLINT
    vec4 glintColor = GlintAlpha * texture(GlintSampler, texCoordGlint);
    // Matches BlendFuntion.GLINT
    color.rgb += glintColor.rgb * glintColor.rgb;
    #endif

    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    return apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
}

void main() {
    #ifdef OIT
    // 반투명 누적 단계가 조명 데이터 줄(화면 맨 아래·위 한 줄)을 덮지 않게(item·particle·terrain 과 같은 규칙)
    if (srwDataPixel()) {
        discard;
    }
    #endif
    vec2 uv0 = texCoord0;
    #ifdef SRW_PILOT
    vec2 uvUnder = vec2(0.0);
    if (srwPart > 0) {
        srwPilotUV(srwPart, texCoord0, uv0, uvUnder);
    }
    #endif
    vec4 color = texture(Sampler0, uv0);

    #ifdef OIT_ADDITIVE
    color.a = min(0.99, color.a);
    #endif

    #ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
    #endif

    #ifdef PER_FACE_LIGHTING
    vec4 faceVertexColor = gl_FrontFacing ? vertexPerFaceColorFront : vertexPerFaceColorBack;
    #else
    vec4 faceVertexColor = vertexColor;
    #endif

    #ifdef DISSOLVE
    if (faceVertexColor.a < texture(DissolveMaskSampler, uv0).a) {
        discard;
    }
    // The dissolve effect entirely replaces translucency
    faceVertexColor.a = 1.0;
    #endif

    color *= faceVertexColor * ColorModulator;

    #ifdef GLINT
    color.a = max(color.a, GlintAlpha);
    #endif

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);

    #if defined(SRW_PILOT) && !defined(OIT_ACCUMULATE)
    if (srwPart > 0 && fragColor.a < 1.0) {
        fragColor.a = max(fragColor.a, SRW_MIN_ALPHA);
        vec3 under = texture(Sampler0, uvUnder).rgb;
        vec3 mixed = mix(under, fragColor.rgb, fragColor.a);
        float fade = mix(fragColor.a, 1.0, clamp((cylindricalVertexDistance - SRW_FADE_NEAR) / (SRW_FADE_FAR - SRW_FADE_NEAR), 0.0, 1.0));
        fragColor = vec4((mixed - (1.0 - fade) * under) / fade, fade);
        if (fragColor.a < srwBayer[int(gl_FragCoord.x) % 4][int(gl_FragCoord.y) % 4] + (0.5 / 16.0)) {
            discard;
        }
        fragColor.a = 1.0;
    }
    #endif
    #endif
}
