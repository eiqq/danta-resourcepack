#version 330
#extension GL_ARB_separate_shader_objects : require

// 바닐라 26.3 text.vsh + 보스바 제목으로 그리는 HUD(IS_GUI 만): 글자색 R = 254 인 글자만 화면 자리로 옮김.
//   G = 덩어리(0~15) + 16 × 옅기(0~15), B = 색 번호 + 32 × 지지직(0~3) — plugin Hud.Strip
// 모든 HUD 제목(조종석 Hud.pilot · 관전 CrtHud.title · 안내 Hud.info)은 덩어리를 같은 차례·같은 폭으로 전부 담음(안 그리는 덩어리는 빈칸)
// → 제목 왼쪽 끝 = 화면 가운데 − HUD_TOTAL / 2, 덩어리 시작 = 거기 + HUD_OFF[덩어리]. 보스바 맨 위(제목 줄 y 3)라고 가정 — 한 사람에게 HUD 보스바는 하나만.
//   10 선체 위험 가장자리(화면 전체) · 0·1 관전 판(위 모서리) · 13 관전 남은 시간(두 판 사이) · 2 방향키(왼쪽 가운데) · 3 레이더(오른쪽 열 셋째)
//   4 조준선(한가운데 — 명중 ✕·피해 수치·맞은 방향 호·동기화 표식 포함) · 5 상태 판(오른쪽 위) · 6 무기 판(그 아래) · 7 알림(조준선 위) · 8 조작 안내(왼쪽 위)
//   9 가운데 위(남은 시간·상대 선체 — 조작 안내 아래 높이) · 11 큰 글(가운데 위, 2~2.5배) · 14 안내 줄(큰 글 아래) · 12 결과 판(오른쪽 가운데)
// 다른 글자·월드 글자는 바닐라 그대로. 자리 식은 plugin/check/CrtCheck.place 가 똑같이 따라 하며 겹침을 검사함(여길 고치면 거기도).

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#ifdef IS_GUI
#include <minecraft:globals.glsl>
#include <srw:srw_pick.glsl>
#endif

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;
#ifdef IS_GUI
layout(location = 4) out vec4 crtInfo;   // x = 종류(0 아님, 2 레이더 쓸기, 3·4 그대로, 6 관전 글자, 6.5 관전 판, 7 선체 위험 가장자리) + 0.1 × 지지직, y = GUI y, zw = 옮긴 GUI 자리
layout(location = 5) out vec2 crtCenter; // 레이더 화면 가운데(GUI) · 종류 7 = 화면 크기(GUI)

// 덩어리 시작(번호 순)·전체 폭 — plugin Hud.SEQ·WIDTH 에서 나온 값(CrtCheck 가 이 줄을 읽어 맞는지 검사)
const float HUD_OFF[16] = float[16](66.0, 226.0, 434.0, 494.0, 542.0, 606.0, 756.0, 906.0, 1022.0, 1252.0, 0.0, 1368.0, 1708.0, 386.0, 1468.0, 0.0);
const float HUD_TOTAL = 1908.0;
const float CRT_W = 160.0, CRT_MARGIN = 4.0, SPEC_SCALE = 1.35, MID_W = 48.0;
const float RADAR_W = 48.0, RADAR_C = 24.0, RET_W = 64.0, RET_H = 32.0, PANEL_W = 150.0, PANEL_H = 55.0;
const float CEN_W = 116.0, CEN_UP = 48.0, CTL_W = 230.0, CTL_TOP = 6.0; // 가운데(조준선 위 — Hud.CEN_W)·조작 안내(왼쪽 위 — Hud.CTL_W)
const float TOP_W = 116.0, BAN_W = 100.0, NOTE_W = 240.0, RES_W = 200.0, EDGE_PX = 64.0;
// 유저 11/08: 계기는 오른쪽에 — 오른쪽 위부터 상태 판 · 무기 판 · 레이더 차례로, 왼쪽 위 = 조작 안내, 왼쪽 가운데 = 방향키
const float SIDE_MARGIN = 6.0, TITLE_Y = 3.0, PANEL_TOP = 4.0, PAD = 4.0; // 판 바탕은 제목 줄보다 4칸 위에서 시작

// 관전 HUD(G 0·1) 색: 브라운관 인광 대신 팀 색(A 빨강·B 파랑) + 분명한 상태색 — 유저 11/07 '선명·가시성 높게'
vec3 specPalette(int i, int side, float t) {
    vec3 team = side == 0 ? vec3(1.00, 0.45, 0.38) : vec3(0.48, 0.72, 1.00);
    if (i == 0 || i == 1) return team;                                                // 값·이름(팀 색)
    if (i == 6 || i == 7) return vec3(0.60, 0.62, 0.68);                               // 글자표·빈 칸(회색)
    if (i == 2) return vec3(1.00, 0.86, 0.25);                                         // 손상(노랑)
    if (i == 3) return vec3(1.00, 0.20, 0.15) * (fract(t * 2.2) < 0.55 ? 1.0 : 0.45); // 위험(깜빡임)
    if (i == 4) return vec3(0.40, 0.42, 0.46);                                         // 잃음
    return vec3(1.0);                                                                  // 5 = 그림 색 그대로(판)
}

vec3 crtPalette(int i, float t) {
    if (i == 0) return vec3(0.42, 1.00, 0.50); // 초록 인광
    if (i == 1) return vec3(1.00, 0.70, 0.26); // 호박색 인광
    if (i == 2) return vec3(1.00, 0.90, 0.32); // 손상
    if (i == 3) return vec3(1.00, 0.24, 0.17) * (fract(t * 2.2) < 0.55 ? 1.0 : 0.35); // 위험(깜빡임)
    if (i == 4) return vec3(0.27, 0.31, 0.28); // 잃음
    if (i == 6) return vec3(0.22, 0.62, 0.29); // 초록 어둡게
    if (i == 7) return vec3(0.64, 0.43, 0.15); // 호박 어둡게
    if (i == 8) return vec3(1.00, 0.36, 0.24); // 레이더 점
    // 조종석 계기(유저 11/08: 80년대 모니터 말고 가시성 있게) — 어두운 판 위 밝은 글자, 라벨도 밝은 회청색
    if (i == 10) return vec3(0.40, 0.90, 1.00); // 값·정상(밝은 청록)
    if (i == 11) return vec3(0.62, 0.70, 0.78); // 라벨·꺼진 것(밝은 회청)
    if (i == 12) return vec3(1.00, 0.74, 0.22) * (fract(t * 1.6) < 0.6 ? 1.0 : 0.75); // 호박(바뀌는 중·경고, 느린 깜빡임)
    if (i == 13) return vec3(1.00, 0.30, 0.24) * (fract(t * 2.4) < 0.55 ? 1.0 : 0.55); // 빨강(위험·요청, 깜빡임)
    if (i == 14) return vec3(1.00, 1.00, 1.00); // 고른 것·준비(흰색)
    if (i == 15) return vec3(1.00, 0.45, 0.38); // A팀·빨강 군단(안 깜빡임)
    if (i == 16) return vec3(0.48, 0.72, 1.00); // B팀·파랑 군단
    if (i == 17) return vec3(1.00, 0.27, 0.20); // 맞은 방향(안 깜빡이는 빨강)
    return vec3(1.0);                          // 5 = 그림 색 그대로(배경)
}
#endif

void main() {
#ifdef IS_GUI
    vec3 pos = Position;
    vertexColor = Color;
    crtInfo = vec4(0.0, Position.y, Position.xy);
    crtCenter = vec2(0.0);
    if (abs(Color.r * 255.0 - 254.0) < 0.5 && ProjMat[3][3] > 0.5) {
        int g = int(Color.g * 255.0 + 0.5);
        float fade = float(g / 16) / 15.0; // 옅기(Hud.Strip: G = 덩어리 0~15 + 16 × 옅기 0~15 — 상황에 따라 서서히 진해지고 옅어짐, 유저 11/08)
        g -= (g / 16) * 16;
        int pal = int(Color.b * 255.0 + 0.5);
        int glitch = pal / 32; // 조종석 피격 지지직 세기 0~3(Hud.Strip: 색 번호 + 32 × 세기 — 유저 11/07 '타격감')
        pal -= glitch * 32;
        float t = GameTime * 1200.0; // 초
        float guiW = 2.0 / ProjMat[0][0], guiH = 2.0 / abs(ProjMat[1][1]);
        float cx = guiW * 0.5, cy = guiH * 0.5;
        float ps = clamp((guiH - 200.0) / 56.0, 1.0, 1.15); // 조종석 판 배율(유저 11/08 가시성): GUI 높이 256 이상부터 커져 1080p 1.15배 — 작은 화면은 1배
        // 좁은 화면(4:3·5:4·16:10 에 GUI 크게 — 11/09): 오른쪽 열은 조준선 위 알림(가운데 ±58)에 안 닿게 줄이고, 왼쪽 위 조작 안내는 오른쪽 판에 안 닿게 줄임
        float sr = min(ps, (cx - 66.0) / PANEL_W);                              // 오른쪽 열(상태·무기 판·레이더) 배율
        float cs = clamp((guiW - 4.0 - PANEL_W * sr - 20.0) / CTL_W, 0.6, 1.0); // 조작 안내 배율
        float colH = PANEL_H * sr + 4.0;                                        // 오른쪽 열: 판 하나 높이 + 틈
        float ss = min(SPEC_SCALE, (guiW - 2.0 * CRT_MARGIN - MID_W - 6.0) / (2.0 * CRT_W)); // 관전 판 배율(두 판 사이에 남은 시간(1배) 자리를 남김)
        float topY = CTL_TOP + 29.0 * cs + 4.0;                                 // 가운데 위 줄(조작 안내 바로 아래 높이)
        float bsc = clamp((guiH - 190.0) / 32.0, 2.0, 2.5);                     // 큰 글 배율
        float ns = min(1.2, (guiW - 16.0) / NOTE_W);                            // 안내 줄 배율
        float noteY = topY + 5.0 + 10.0 * bsc;                                  // 안내 줄 윗변(큰 글 한 줄 아래)
        // 덩어리 → 화면: at = 덩어리 왼쪽·제목 줄 윗변이 갈 자리, sc = 배율(그 자리 기준), slide = 옅어질 때 살짝 밀림
        vec2 at = vec2(0.0), slide = vec2(0.0);
        float sc = 1.0, kind = 4.0;
        if (g <= 1) { // 관전 판: 두 위 모서리(떨림 없음 — 선명하게)
            at = vec2(g == 0 ? CRT_MARGIN : guiW - CRT_MARGIN - CRT_W * ss, PANEL_TOP + PAD * ss);
            sc = ss;
            kind = pal == 5 ? 6.5 : 6.0; // text.fsh: 6 = 또렷한 글자(번짐 → 어두운 외곽선), 6.5 = 판 그대로
        } else if (g == 13) { // 관전 남은 시간: 두 판 사이(1배)
            at = vec2(cx - MID_W * 0.5, PANEL_TOP + PAD);
        } else if (g == 2) { // 방향키: 왼쪽 가운데(조작 안내 아래, 채팅 위) · 옅어질수록 바깥으로 살짝 밀림
            at = vec2(SIDE_MARGIN, max(CTL_TOP + 29.0 * cs + 6.0, cy - 60.0));
            slide.x = -6.0 * fade;
            kind = 3.0;
        } else if (g == 3) { // 레이더: 오른쪽 열 셋째(무기 판 아래)
            at = vec2(guiW - SIDE_MARGIN - RADAR_W * sr, PANEL_TOP + 2.0 * colH + 2.0);
            sc = sr;
            slide.x = 6.0 * fade * sr;
            crtCenter = at + slide + vec2(RADAR_C, 20.0) * sr;
            kind = pal == 5 || pal == 8 ? 2.0 : 4.0;
        } else if (g == 4) { // 조준선: 한가운데
            at = vec2(cx - RET_W * 0.5, cy - RET_H * 0.5);
        } else if (g == 5 || g == 6) { // 상태 판(오른쪽 위)·무기 판(그 아래)
            at = vec2(guiW - CRT_MARGIN - PANEL_W * sr, PANEL_TOP + (g == 6 ? colH : 0.0) + PAD * sr);
            sc = sr;
            slide.x = 4.0 * fade * sr;
        } else if (g == 7) { // 알림: 조준선 바로 위 — 나타날 때 위에서 살짝 내려옴(옅어지면 위로 물러남)
            at = vec2(cx - CEN_W * 0.5, cy - CEN_UP);
            slide.y = -5.0 * fade;
        } else if (g == 8) { // 조작 안내: 왼쪽 위
            at = vec2(SIDE_MARGIN, CTL_TOP);
            sc = cs;
            slide.x = -6.0 * fade * cs;
        } else if (g == 9) { // 가운데 위: 남은 시간·상대 선체
            at = vec2(cx - TOP_W * 0.5, topY);
            slide.y = -4.0 * fade;
        } else if (g == 11) { // 큰 글(결정타·승리·시작 카운트): 가운데 위
            at = vec2(cx - BAN_W * 0.5 * bsc, topY + 2.0);
            sc = bsc;
            slide.y = -5.0 * fade;
        } else if (g == 14) { // 안내 줄(세 줄까지): 큰 글 아래
            sc = ns;
            at = vec2(cx - NOTE_W * 0.5 * ns, noteY);
            slide.y = -3.0 * fade;
        } else if (g == 12) { // 결과 판: 오른쪽 가운데(이긴 로봇은 화면 왼쪽에 — Finale 카메라), 안내 세 줄 아래로
            sc = min(1.25, (guiW * 0.55 - 10.0) / RES_W);
            at = vec2(guiW - 10.0 - RES_W * sc, max(cy - 24.0, noteY + 30.0 * ns + 4.0) + PAD * sc);
            slide.x = 10.0 * fade;
        }
        if (glitch > 0) { // 피격: 덩어리마다 프레임마다 크게 흔들림(세기만큼)
            float gs = float(glitch), f = floor(t * 30.0);
            slide.x += (fract(sin((f + float(g) * 17.0) * 91.345) * 47453.21) - 0.5) * 6.0 * gs;
            slide.y += (fract(sin((f + float(g) * 29.0) * 37.719) * 23421.63) - 0.5) * 2.5 * gs;
        }
        vec2 rel = pos.xy - vec2(cx - HUD_TOTAL * 0.5 + HUD_OFF[g], TITLE_Y);
        vertexColor = vec4(g <= 1 ? specPalette(pal, g, t) : crtPalette(pal, t), Color.a * (1.0 - fade));
        if (g == 10) { // 선체 위험: 글리프 하나(64칸, 윗변 = 제목 줄 − 1)를 화면 전체로 — 그림은 text.fsh 가 가장자리만 붉게
            pos.xy = (rel + vec2(0.0, 1.0)) / EDGE_PX * vec2(guiW, guiH);
            crtCenter = vec2(guiW, guiH);
            kind = 7.0;
        } else {
            pos.xy = at + slide + rel * sc;
        }
        crtInfo = vec4(kind + 0.1 * float(glitch), pos.y, pos.xy); // 소수 첫째 자리 = 지지직 세기(text.fsh)
    }
    if (ProjMat[3][3] > 0.5) { // 기체 선택 픽창(글자색 R 249~253, srw_pick.glsl) — 위 HUD(R 254)와 안 겹침
        vec4 pickColor, pickInfo;
        if (srwPick(pos, Color, 2.0 / ProjMat[0][0], 2.0 / abs(ProjMat[1][1]), pickColor, pickInfo)) {
            vertexColor = pickColor;
            crtInfo = pickInfo;
        }
    }
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);
#else
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#elif !defined(IS_GUI)
    vertexColor = Color;
#endif
    texCoord0 = UV0;
}
