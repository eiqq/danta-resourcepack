#version 330
#extension GL_ARB_separate_shader_objects : require

// 바닐라 26.3 text.vsh + 보스바 제목으로 그리는 계기판(IS_GUI 만): 글자색 R = 254 인 글자만 화면 자리로 옮김, B = 색 번호.
//   G 0·1 = 관전자 브라운관 패널(왼쪽 위·오른쪽 위, 각 160칸 — plugin CrtHud), 가끔 가로 떨림
//   G 2~6 = 조종석 계기(plugin Hud.pilot, 제목 = [방향키 60][레이더 48][조준선 64][상태 150][무기 150], 보스바 맨 위 = 제목 줄 y 3 가정):
//     방향키 = 왼쪽 가장자리(채팅 위), 레이더 = 오른쪽 가운데, 조준선 = 한가운데, 상태 = 왼쪽 위, 무기 = 오른쪽 위
// 다른 글자·월드 글자는 바닐라 그대로.

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#ifdef IS_GUI
#include <minecraft:globals.glsl>
#include <srw:srw_pick.glsl>
#endif

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;
#ifdef IS_GUI
layout(location = 4) out vec4 crtInfo;   // x = 종류(0 아님, 1 브라운관, 2 브라운관 + 레이더 쓸기, 3 그대로, 4 홀로그램), y = GUI y, zw = 옮긴 GUI 자리
layout(location = 5) out vec2 crtCenter; // 레이더 화면 가운데(GUI)

const float CRT_W = 160.0, CRT_MARGIN = 4.0, SPEC_SCALE = 1.35;
const float KEYS_W = 60.0, KEYS_H = 38.0, RADAR_W = 48.0, RADAR_H = 49.0, RADAR_C = 24.0, RET_W = 64.0, RET_H = 32.0, PANEL_W = 150.0;
const float CEN_W = 116.0, CEN_UP = 48.0, CTL_W = 230.0, CTL_TOP = 6.0, PANEL_H = 55.0; // 가운데(조준선 위 — Hud.CEN_W)·조작 안내(왼쪽 위 — Hud.CTL_W)
// 유저 11/08: 계기는 오른쪽에 — 오른쪽 위부터 상태 판 · 무기 판 · 레이더 차례로, 왼쪽 위 = 조작 안내, 왼쪽 가운데 = 방향키
const float SIDE_MARGIN = 6.0, TITLE_Y = 3.0, PANEL_TOP = 4.0, PANEL_ASCENT_PAD = 4.0; // 패널 바탕은 제목 줄보다 4칸 위에서 시작

// 관전 HUD(G 0·1) 색: 브라운관 인광 대신 팀 색(A 빨강·B 파랑) + 분명한 상태색 — 유저 11/07 '선명·가시성 높게'
vec3 specPalette(int i, int side, float t) {
    vec3 team = side == 0 ? vec3(1.00, 0.45, 0.38) : vec3(0.48, 0.72, 1.00);
    if (i == 0 || i == 1) return team;                                                // 값·이름(팀 색)
    if (i == 6 || i == 7) return vec3(0.60, 0.62, 0.68);                               // 글자표·빈 칸(회색)
    if (i == 2) return vec3(1.00, 0.86, 0.25);                                         // 손상(노랑)
    if (i == 3) return vec3(1.00, 0.20, 0.15) * (fract(t * 2.2) < 0.55 ? 1.0 : 0.45); // 위험(깜빡임)
    if (i == 4) return vec3(0.40, 0.42, 0.46);                                         // 잃음
    return vec3(1.0);                                                                  // 5 = 그림 색 그대로(판)
}

vec3 crtPalette(int i, float t) {
    if (i == 0) return vec3(0.42, 1.00, 0.50); // 초록 인광
    if (i == 1) return vec3(1.00, 0.70, 0.26); // 호박색 인광
    if (i == 2) return vec3(1.00, 0.90, 0.32); // 손상
    if (i == 3) return vec3(1.00, 0.24, 0.17) * (fract(t * 2.2) < 0.55 ? 1.0 : 0.35); // 위험(깜빡임)
    if (i == 4) return vec3(0.27, 0.31, 0.28); // 잃음
    if (i == 6) return vec3(0.22, 0.62, 0.29); // 초록 어둡게
    if (i == 7) return vec3(0.64, 0.43, 0.15); // 호박 어둡게
    if (i == 8) return vec3(1.00, 0.36, 0.24); // 레이더 점
    // 조종석 계기(유저 11/08: 80년대 모니터 말고 가시성 있게) — 어두운 판 위 밝은 글자, 라벨도 밝은 회청색
    if (i == 10) return vec3(0.40, 0.90, 1.00); // 값·정상(밝은 청록)
    if (i == 11) return vec3(0.62, 0.70, 0.78); // 라벨·꺼진 것(밝은 회청)
    if (i == 12) return vec3(1.00, 0.74, 0.22) * (fract(t * 1.6) < 0.6 ? 1.0 : 0.75); // 호박(바뀌는 중·경고, 느린 깜빡임)
    if (i == 13) return vec3(1.00, 0.30, 0.24) * (fract(t * 2.4) < 0.55 ? 1.0 : 0.55); // 빨강(위험·요청, 깜빡임)
    if (i == 14) return vec3(1.00, 1.00, 1.00); // 고른 것·준비(흰색)
    return vec3(1.0);                          // 5 = 그림 색 그대로(배경)
}
#endif

void main() {
#ifdef IS_GUI
    vec3 pos = Position;
    vertexColor = Color;
    crtInfo = vec4(0.0, Position.y, Position.xy);
    crtCenter = vec2(0.0);
    if (abs(Color.r * 255.0 - 254.0) < 0.5 && ProjMat[3][3] > 0.5) {
        int g = int(Color.g * 255.0 + 0.5);
        float fade = float(g / 16) / 15.0; // 계기 옅기(Hud.Strip: G = 덩어리 0~15 + 16 × 옅기 0~15 — 상황에 따라 서서히 진해지고 옅어짐, 유저 11/08)
        g -= (g / 16) * 16;
        int pal = int(Color.b * 255.0 + 0.5);
        int glitch = pal / 32; // 조종석 피격 지지직 세기 0~3(Hud.Strip: 색 번호 + 32 × 세기 — 유저 11/07 '타격감')
        pal -= glitch * 32;
        float t = GameTime * 1200.0; // 초
        float guiW = 2.0 / ProjMat[0][0], guiH = 2.0 / abs(ProjMat[1][1]);
        float ps = clamp((guiH - 200.0) / 56.0, 1.0, 1.15); // 조종석 판 배율(유저 11/08 가시성): GUI 높이 256 이상부터 커져 1080p 1.15배 — 작은 화면은 1배
        // 좁은 화면(4:3·5:4·16:10 에 GUI 크게 — 11/09): 오른쪽 열은 조준선 위 알림(가운데 ±58)에 안 닿게 줄이고, 왼쪽 위 조작 안내는 오른쪽 판에 안 닿게 줄임
        float sr = min(ps, (guiW * 0.5 - 66.0) / PANEL_W);              // 오른쪽 열(상태·무기 판·레이더) 배율
        float cs = clamp((guiW - 4.0 - PANEL_W * sr - 20.0) / CTL_W, 0.6, 1.0); // 조작 안내 배율
        float colH = PANEL_H * sr + 4.0;                   // 오른쪽 열: 판 하나 높이 + 틈
        float ss = min(SPEC_SCALE, (guiW * 0.5 - CRT_MARGIN - 4.0) / CRT_W); // 관전 판 배율(두 판이 가운데서 안 겹치게)
        vec2 shift = vec2(0.0);
        float kind = 1.0;
        float panelY = PANEL_TOP + PANEL_ASCENT_PAD - TITLE_Y; // 바탕 윗변이 화면 위에서 4칸
        if (g <= 1) {
            // 제목 = [왼 패널 160][오른 패널 160] 가운데 정렬 → 각 패널을 위쪽 모서리로(떨림 없음 — 관전 HUD 는 선명하게, 아래에서 1.35배)
            shift = vec2(g == 0 ? CRT_MARGIN + CRT_W - guiW * 0.5 : guiW * 0.5 - CRT_MARGIN - CRT_W, panelY);
            kind = pal == 5 ? 6.5 : 6.0; // text.fsh: 6 = 또렷한 글자(번짐 → 어두운 외곽선), 6.5 = 판 그대로
        } else {
            // 제목 = [방향키][레이더][조준선][상태][무기][가운데][조작 안내] 가운데 정렬 → 덩어리마다 제자리로
            float start = guiW * 0.5 - (KEYS_W + RADAR_W + RET_W + PANEL_W * 2.0 + CEN_W + CTL_W) * 0.5;
            float cy = guiH * 0.5;
            kind = 4.0;
            if (g == 2) { // 방향키: 왼쪽 가운데(조작 안내 아래, 채팅 위) · 옅어질수록 바깥으로 살짝 밀림
                shift = vec2(SIDE_MARGIN - start - 6.0 * fade, max(CTL_TOP + 29.0 * cs + 6.0, cy - 60.0) - TITLE_Y);
                kind = 3.0;
            } else if (g == 3) { // 레이더: 오른쪽 열 셋째(무기 판 아래)
                start += KEYS_W;
                float ry = PANEL_TOP + 2.0 * colH + 2.0;
                shift = vec2(guiW - SIDE_MARGIN - RADAR_W - start + 6.0 * fade, ry - TITLE_Y);
                vec2 rc = vec2(guiW - SIDE_MARGIN, ry); // 레이더 오른쪽 위 모서리(배율 기준)
                crtCenter = rc + (vec2(guiW - SIDE_MARGIN - RADAR_W + RADAR_C + 6.0 * fade, ry + 20.0) - rc) * sr;
                kind = pal == 5 || pal == 8 ? 2.0 : 4.0;
            } else if (g == 4) {
                start += KEYS_W + RADAR_W;
                shift = vec2(guiW * 0.5 - RET_W * 0.5 - start, cy - RET_H * 0.5 - TITLE_Y);
            } else if (g == 5) { // 상태 판: 오른쪽 위
                start += KEYS_W + RADAR_W + RET_W;
                shift = vec2(guiW - CRT_MARGIN - PANEL_W - start + 4.0 * fade, panelY);
            } else if (g == 6) { // 무기 판: 상태 판 바로 아래
                start += KEYS_W + RADAR_W + RET_W + PANEL_W;
                shift = vec2(guiW - CRT_MARGIN - PANEL_W - start + 4.0 * fade, panelY + colH);
            } else if (g == 7) { // 가운데: 나타날 때 위에서 살짝 내려옴(옅어지면 위로 물러남)
                start += KEYS_W + RADAR_W + RET_W + PANEL_W * 2.0;
                shift = vec2(guiW * 0.5 - CEN_W * 0.5 - start, cy - CEN_UP - TITLE_Y - 5.0 * fade);
            } else { // 8 = 조작 안내: 왼쪽 위
                start += KEYS_W + RADAR_W + RET_W + PANEL_W * 2.0 + CEN_W;
                shift = vec2(SIDE_MARGIN - start - 6.0 * fade, CTL_TOP - TITLE_Y);
            }
            if (glitch > 0) { // 피격: 덩어리마다 프레임마다 크게 흔들림(세기만큼)
                float gs = float(glitch), f = floor(t * 30.0);
                shift.x += (fract(sin((f + float(g) * 17.0) * 91.345) * 47453.21) - 0.5) * 6.0 * gs;
                shift.y += (fract(sin((f + float(g) * 29.0) * 37.719) * 23421.63) - 0.5) * 2.5 * gs;
            }
        }
        pos.xy += shift;
        if (g <= 1 || g == 5 || g == 6) { // 관전 HUD 1.35배(두 위 모서리) · 조종석 상태(5)·무기(6) 판 sr 배(오른쪽 열, 각 판 오른쪽 위 모서리 기준)
            vec2 corner = vec2(g == 0 ? CRT_MARGIN : guiW - CRT_MARGIN, PANEL_TOP + (g == 6 ? colH : 0.0));
            pos.xy = corner + (pos.xy - corner) * (g <= 1 ? ss : sr);
        } else if (g == 3) { // 레이더: 오른쪽 위 모서리 기준 sr 배
            vec2 corner = vec2(guiW - SIDE_MARGIN, PANEL_TOP + 2.0 * colH + 2.0);
            pos.xy = corner + (pos.xy - corner) * sr;
        } else if (g == 8) { // 조작 안내: 왼쪽 위 모서리 기준 cs 배
            vec2 corner = vec2(SIDE_MARGIN, CTL_TOP);
            pos.xy = corner + (pos.xy - corner) * cs;
        }
        vertexColor = vec4(g <= 1 ? specPalette(pal, g, t) : crtPalette(pal, t), Color.a * (1.0 - fade));
        crtInfo = vec4(kind + 0.1 * float(glitch), pos.y, pos.xy); // 소수 첫째 자리 = 지지직 세기(text.fsh)
    }
    if (ProjMat[3][3] > 0.5) { // 기체 선택 픽창(글자색 R 249~253, srw_pick.glsl) — 위 계기판(R 254)과 안 겹침
        vec4 pickColor, pickInfo;
        if (srwPick(pos, Color, 2.0 / ProjMat[0][0], 2.0 / abs(ProjMat[1][1]), pickColor, pickInfo)) {
            vertexColor = pickColor;
            crtInfo = pickInfo;
        }
    }
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);
#else
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#elif !defined(IS_GUI)
    vertexColor = Color;
#endif
    texCoord0 = UV0;
}
