#version 330
#extension GL_ARB_separate_shader_objects : require

// 바닐라 26.3 text.vsh + 보스바 제목으로 그리는 계기판(IS_GUI 만): 글자색 R = 254 인 글자만 화면 자리로 옮김, B = 색 번호.
//   G 0·1 = 관전자 브라운관 패널(왼쪽 위·오른쪽 위, 각 160칸 — plugin CrtHud), 가끔 가로 떨림
//   G 2~6 = 조종석 계기(plugin Hud.pilot, 제목 = [방향키 60][레이더 48][조준선 64][상태 150][무기 150], 보스바 맨 위 = 제목 줄 y 3 가정):
//     방향키 = 왼쪽 가장자리(채팅 위), 레이더 = 오른쪽 가운데, 조준선 = 한가운데, 상태 = 왼쪽 위, 무기 = 오른쪽 위
// 다른 글자·월드 글자는 바닐라 그대로.

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#ifdef IS_GUI
#include <minecraft:globals.glsl>
#include <srw:srw_pick.glsl>
#endif

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;
#ifdef IS_GUI
layout(location = 4) out vec4 crtInfo;   // x = 종류(0 아님, 1 브라운관, 2 브라운관 + 레이더 쓸기, 3 그대로, 4 홀로그램), y = GUI y, zw = 옮긴 GUI 자리
layout(location = 5) out vec2 crtCenter; // 레이더 화면 가운데(GUI)

const float CRT_W = 160.0, CRT_MARGIN = 4.0;
const float KEYS_W = 60.0, KEYS_H = 38.0, RADAR_W = 48.0, RADAR_H = 49.0, RADAR_C = 24.0, RET_W = 64.0, RET_H = 32.0, PANEL_W = 150.0;
const float SIDE_MARGIN = 6.0, TITLE_Y = 3.0, PANEL_TOP = 4.0, PANEL_ASCENT_PAD = 4.0; // 패널 바탕은 제목 줄보다 4칸 위에서 시작

vec3 crtPalette(int i, float t) {
    if (i == 0) return vec3(0.42, 1.00, 0.50); // 초록 인광
    if (i == 1) return vec3(1.00, 0.70, 0.26); // 호박색 인광
    if (i == 2) return vec3(1.00, 0.90, 0.32); // 손상
    if (i == 3) return vec3(1.00, 0.24, 0.17) * (fract(t * 2.2) < 0.55 ? 1.0 : 0.35); // 위험(깜빡임)
    if (i == 4) return vec3(0.27, 0.31, 0.28); // 잃음
    if (i == 6) return vec3(0.22, 0.62, 0.29); // 초록 어둡게
    if (i == 7) return vec3(0.64, 0.43, 0.15); // 호박 어둡게
    if (i == 8) return vec3(1.00, 0.36, 0.24); // 레이더 점
    if (i == 10) return vec3(0.50, 0.92, 1.00); // 홀로그램 청록
    if (i == 11) return vec3(0.22, 0.48, 0.58); // 청록 어둡게
    if (i == 12) return vec3(1.00, 0.72, 0.26) * (fract(t * 1.6) < 0.6 ? 1.0 : 0.6); // 호박(바뀌는 중·경고, 느린 깜빡임)
    if (i == 13) return vec3(1.00, 0.28, 0.20) * (fract(t * 2.4) < 0.55 ? 1.0 : 0.35); // 빨강(위험·요청, 깜빡임)
    if (i == 14) return vec3(0.92, 1.00, 1.00); // 고른 것·준비
    return vec3(1.0);                          // 5 = 그림 색 그대로(배경)
}
#endif

void main() {
#ifdef IS_GUI
    vec3 pos = Position;
    vertexColor = Color;
    crtInfo = vec4(0.0, Position.y, Position.xy);
    crtCenter = vec2(0.0);
    if (abs(Color.r * 255.0 - 254.0) < 0.5 && ProjMat[3][3] > 0.5) {
        int g = int(Color.g * 255.0 + 0.5);
        int pal = int(Color.b * 255.0 + 0.5);
        float t = GameTime * 1200.0; // 초
        float guiW = 2.0 / ProjMat[0][0], guiH = 2.0 / abs(ProjMat[1][1]);
        vec2 shift = vec2(0.0);
        float kind = 1.0;
        float panelY = PANEL_TOP + PANEL_ASCENT_PAD - TITLE_Y; // 바탕 윗변이 화면 위에서 4칸
        if (g <= 1) {
            // 제목 = [왼 패널 160][오른 패널 160] 가운데 정렬 → 각 패널을 위쪽 모서리로
            shift = vec2(g == 0 ? CRT_MARGIN + CRT_W - guiW * 0.5 : guiW * 0.5 - CRT_MARGIN - CRT_W, panelY);
            float h = fract(sin((floor(t * 12.0) + float(g) * 37.0) * 12.9898) * 43758.5453);
            if (h > 0.93) shift.x += floor((fract(h * 91.7) - 0.5) * 3.0 + 0.5); // 가끔 1칸 떨림
        } else {
            // 제목 = [방향키][레이더][조준선][상태][무기] 가운데 정렬 → 덩어리마다 제자리로
            float start = guiW * 0.5 - (KEYS_W + RADAR_W + RET_W + PANEL_W * 2.0) * 0.5;
            float cy = guiH * 0.5;
            kind = 4.0;
            if (g == 2) { // 채팅(왼쪽 아래)보다 위: 윗변 = 가운데 − 60(상태 패널 아래 62 이상)
                shift = vec2(SIDE_MARGIN - start, max(62.0, cy - 60.0) - TITLE_Y);
                kind = 3.0;
            } else if (g == 3) {
                start += KEYS_W;
                shift = vec2(guiW - SIDE_MARGIN - RADAR_W - start, cy - RADAR_H * 0.5 - TITLE_Y);
                crtCenter = vec2(guiW - SIDE_MARGIN - RADAR_W + RADAR_C, cy - RADAR_H * 0.5 + 20.0);
                kind = pal == 5 || pal == 8 ? 2.0 : 4.0;
            } else if (g == 4) {
                start += KEYS_W + RADAR_W;
                shift = vec2(guiW * 0.5 - RET_W * 0.5 - start, cy - RET_H * 0.5 - TITLE_Y);
            } else if (g == 5) {
                start += KEYS_W + RADAR_W + RET_W;
                shift = vec2(CRT_MARGIN - start, panelY);
            } else {
                start += KEYS_W + RADAR_W + RET_W + PANEL_W;
                shift = vec2(guiW - CRT_MARGIN - PANEL_W - start, panelY);
            }
            if (kind > 3.5) { // 홀로그램: 가끔 가로로 튐(덩어리마다 따로)
                float h = fract(sin((floor(t * 9.0) + float(g) * 53.0) * 78.233) * 43758.5453);
                if (h > 0.96) shift.x += h > 0.985 ? 2.0 : -1.0;
            }
        }
        pos.xy += shift;
        vertexColor = vec4(crtPalette(pal, t), Color.a);
        crtInfo = vec4(kind, pos.y, pos.xy);
    }
    if (ProjMat[3][3] > 0.5) { // 기체 선택 픽창(글자색 R 249~253, srw_pick.glsl) — 위 계기판(R 254)과 안 겹침
        vec4 pickColor, pickInfo;
        if (srwPick(pos, Color, 2.0 / ProjMat[0][0], 2.0 / abs(ProjMat[1][1]), pickColor, pickInfo)) {
            vertexColor = pickColor;
            crtInfo = pickInfo;
        }
    }
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);
#else
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#elif !defined(IS_GUI)
    vertexColor = Color;
#endif
    texCoord0 = UV0;
}
