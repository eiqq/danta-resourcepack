#ifndef SRW_CORE_GLSL
#define SRW_CORE_GLSL

// 슈퍼로봇대전 공통(안개 UBO 없이도 쓰는 것): 시간·해시·번개·밤 팔레트·바람·잡음·바다 물결·데이터 줄 부호화.
// 먼저 minecraft:globals.glsl 을 include 할 것(GameTime·ScreenSize·카메라).
// 시간 = Globals GameTime(월드 나이) → 모든 클라·서버(Weather.java)가 같은 번개 일정.

const vec3 SRW_FLASH = vec3(0.82, 0.88, 1.0);     // 번개 빛
const float SRW_SEA_Y = 62.889;                    // 수면(해수면 63 아래 물 블록 윗면)

// 밤 폭풍 팔레트(8비트 화면값 그대로)
const vec3 SRW_NIGHT_ZENITH = vec3(0.030, 0.037, 0.052);
const vec3 SRW_NIGHT_HORIZON = vec3(0.165, 0.195, 0.245);  // 수평선 하늘: 먼 바다보다 밝게 → 하늘·바다 경계가 보임
const vec3 SRW_NIGHT_FOG = vec3(0.080, 0.096, 0.122);      // 먼 연무(바다 쪽)
const vec3 SRW_NIGHT_SEA = vec3(0.010, 0.020, 0.026);      // 깊은 바닷물
const vec3 SRW_NIGHT_CLOUD_LO = vec3(0.036, 0.043, 0.057); // 짙은 구름 밑면
const vec3 SRW_NIGHT_CLOUD_HI = vec3(0.120, 0.137, 0.168); // 얇은 구름(뒤 빛이 비침)
const vec2 SRW_WIND = vec2(0.5547, 0.8321);                 // 바람이 부는 쪽(세계 xz)
// 구름 뒤 달(11/10 개수: 밤 로봇이 새까만 덩어리라 형태·세부가 안 읽힘 → 약한 옆 주광). 두 기체가 마주 보는 축(z)의 옆(−x) 높이 약 25°:
//   조종사가 보는 상대는 한쪽 옆이 밝고 반대쪽이 어두워 덩어리가 읽히고, 달 쪽을 보는 관전자에겐 역광 윤곽 + 바다 빛길
const vec3 SRW_MOON_DIR = vec3(-0.7995, 0.4197, 0.4297);
const vec3 SRW_MOON_COL = vec3(0.56, 0.67, 0.86);

float srwSeconds() {
    return GameTime * 1200.0;
}

// 정수 해시(PCG) — 서버 Weather.java 와 같은 식(천둥소리 맞춤)
float srwHashI(int n) {
    uint h = uint(n) * 747796405u + 2891336453u;
    h = ((h >> ((h >> 28u) + 4u)) ^ h) * 277803737u;
    h = (h >> 22u) ^ h;
    return float(h) / 4294967295.0;
}

// 번개 세기: 9초 칸마다 45% 확률로 한 번, 2~3번 깜빡이며 사그라듦
float srwFlash() {
    float t = srwSeconds();
    int slot = int(floor(t / 9.0));
    float f = 0.0;
    for (int k = 0; k < 2; k++) {
        int s = slot - k;
        if (srwHashI(s * 4) < 0.55) {
            continue;
        }
        float t0 = float(s) * 9.0 + srwHashI(s * 4 + 1) * 6.5;
        float d = t - t0;
        if (d < 0.0 || d > 1.6) {
            continue;
        }
        float p = exp(-d * 10.0);
        p += 0.75 * step(0.16, d) * exp(-(d - 0.16) * 12.0);
        p += 0.55 * step(0.45, d) * step(0.4, srwHashI(s * 4 + 2)) * exp(-(d - 0.45) * 9.0);
        f = max(f, p * (0.55 + 0.45 * srwHashI(s * 4 + 3)));
    }
    return f;
}

// 지금 번개의 칸 번호(줄기 모양 씨앗)와 친 뒤 지난 시간(없으면 큰 값)
float srwFlashAge(out int seed) {
    float t = srwSeconds();
    int slot = int(floor(t / 9.0));
    for (int k = 0; k < 2; k++) {
        int s = slot - k;
        if (srwHashI(s * 4) < 0.55) {
            continue;
        }
        float d = t - (float(s) * 9.0 + srwHashI(s * 4 + 1) * 6.5);
        if (d >= 0.0 && d < 1.6) {
            seed = s;
            return d;
        }
    }
    seed = 0;
    return 99.0;
}

// 번개 친 쪽(수평 방위 랜덤, 높이 약 25°)
vec3 srwFlashDir() {
    int s = int(floor(srwSeconds() / 9.0));
    float a = srwHashI(s * 4 + 5) * 6.2831853;
    return normalize(vec3(cos(a), 0.45, sin(a)));
}

// 돌풍 세기(0.2~1): 여러 느린 사인의 곱 — 비 기울기·물결·구름 속도 공통
float srwGust(float t) {
    return clamp(0.6 + 0.3 * sin(t * 0.31) * sin(t * 0.17 + 1.7) + 0.15 * sin(t * 1.13 + 0.4), 0.2, 1.0);
}

// ---------------- 잡음
float srwHash2(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

float srwNoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(srwHash2(i), srwHash2(i + vec2(1, 0)), f.x), mix(srwHash2(i + vec2(0, 1)), srwHash2(i + vec2(1, 1)), f.x), f.y);
}

float srwFbm(vec2 p, int oct) {
    float v = 0.0;
    float a = 0.5;
    for (int i = 0; i < oct; i++) {
        v += a * srwNoise(p);
        p = mat2(1.6, 1.2, -1.2, 1.6) * p + vec2(17.1, 9.2);
        a *= 0.5;
    }
    return v;
}

// ---------------- 바다 물결(세계 xz, 블록). 법선용 기울기만(면은 평평): 바람 쪽 큰 너울 + 엇갈린 물결 + 잔물결
vec3 srwWaveNormal(vec2 p, float t, out float crest) {
    vec2 g = vec2(0.0);
    float h = 0.0;
    float amp = 0.0;
    for (int i = 0; i < 7; i++) {
        float fi = float(i);
        float wl = 64.0 * pow(0.62, fi);                         // 64 → 3.6블록
        float ang = (srwHashI(i * 3 + 11) - 0.5) * 1.5;          // 바람 ±43°
        vec2 d = vec2(SRW_WIND.x * cos(ang) - SRW_WIND.y * sin(ang), SRW_WIND.x * sin(ang) + SRW_WIND.y * cos(ang));
        float k = 6.2831853 / wl;
        float w = sqrt(9.8 * k) * 0.45;                          // 거대 스케일이라 조금 느리게
        float a = wl * 0.018;
        float ph = dot(d, p) * k - w * t + srwHashI(i * 3 + 12) * 6.2831853;
        float s = sin(ph);
        h += a * s;
        amp += a;
        g += a * k * cos(ph) * d;
    }
    // 잔물결(빗방울·바람 결): 잡음 기울기
    vec2 q = p * 0.9 + SRW_WIND * t * 0.8;
    float e = 0.15;
    float n0 = srwFbm(q, 3);
    g += vec2(srwFbm(q + vec2(e, 0.0), 3) - n0, srwFbm(q + vec2(0.0, e), 3) - n0) / e * 0.10;
    crest = h / amp;
    return normalize(vec3(-g.x, 1.0, -g.y));
}

// 안개 곡선(거리 → 0~1): 150블록까지는 옅은 공기감만, 그 너머는 지수로 급격히 짙어져 250에서 거의 다 가림.
// 마주 보고 다가오면: 250 밖 = 빛나는 곳만(srwFogGlow), 200 근처 = 실루엣, 150 = 안개를 뚫고 등장
float srwFogCurve(float dist) {
    float near = (1.0 - exp(-max(dist - 4.0, 0.0) / 240.0)) * 0.9;
    float wall = 1.0 - exp(-max(dist - 150.0, 0.0) * 0.035);
    return min(near + (1.0 - near) * wall, 0.985);
}

// 빛나는 면(발광·바이저·원자로)이 받는 안개: 훨씬 덜 가려짐(250 밖에서도 20% 남짓 보임)
float srwFogGlow(float f) {
    return f * f * f * f * 0.85;
}

// 밤 하늘 기본 기울기(구름 빼고): 반사용으로 가볍게
vec3 srwNightSky(vec3 d) {
    float up = clamp(d.y, -0.2, 1.0);
    float hz = 1.0 - smoothstep(-0.02, 0.5, up);
    float m = max(dot(normalize(d), SRW_MOON_DIR), 0.0);
    float m2 = m * m, m8 = m2 * m2 * m2 * m2;
    // 달 둘레로 넓게 번진 빛(구름에 퍼짐) + 좁은 심 — 젖은 장갑·수면 반사에 빛길이 생김
    return mix(SRW_NIGHT_ZENITH, SRW_NIGHT_HORIZON, hz * hz) + SRW_MOON_COL * (0.07 * m2 * m2 + 0.22 * m8 * m8 * m8 * m8);
}

// ---------------- 데이터 줄(화면 맨 아래 줄 왼쪽 224칸): 조명 표식이 그리고 후처리(srw_light)가 읽음. 칸 0~15 = 로봇 둘(×8), 16~23 = 격납고 둘(×4)
// 칸: 0 = 확인색, 1~9 = 시점 회전(ModelViewMat 3×3), 10~25 = ProjMat 4×4(제곱근 압축 srwEncP), 26~28 = 카메라 세계 좌표, 29~31 = 바닐라 안개색(FogColor rgb)
//     32 + 조명*8: 0 = 확인색, 1~3 = 조명 위치, 4~6 = 방향점(위치 + 방향) — 카메라 기준 좌표
const vec3 SRW_DATA_CHECK = vec3(53.0, 167.0, 92.0) / 255.0;
const int SRW_DATA_W = 256;
const int SRW_LIGHTS = 28; // 24~27 = 효과 조명(타격 번쩍임 — plugin Effects.flashLight, 11/10)

// 24비트 정수 0~16777214 ↔ [lo, hi]. 분모가 짝수라 한가운데(대칭 범위의 0)가 정확히 표현됨 — 홀수 분모(16777215)였을 땐
// 0 이 +3.8e-6(±64 범위)으로 읽혀 투영 행렬 z 줄에 화면 x·y 가 섞였고, 되살린 해수면이 기울어 바다가 청크·띠 모양으로 끊겼음
vec3 srwEnc(float v, float lo, float hi) {
    float u = clamp((v - lo) / (hi - lo), 0.0, 1.0) * 16777214.0;
    uint n = uint(u + 0.5);
    return vec3(float((n >> 16u) & 255u), float((n >> 8u) & 255u), float(n & 255u)) / 255.0;
}

float srwDec(vec3 c, float lo, float hi) {
    ivec3 b = ivec3(round(c * 255.0));
    return 0.5 * (lo + hi) + 0.5 * (hi - lo) * float(b.r * 65536 + b.g * 256 + b.b - 8388607) / 8388607.0;
}

// 투영 행렬 칸: 제곱근 압축(±64) — 아주 작은 깊이 항(ProjMat[2][2] ≈ 2.4e-5)도 1e-8 정밀도(선형 24비트면 7.6e-6 → 거리 따라 수면 높이 오차)
vec3 srwEncP(float v) {
    return srwEnc(sign(v) * sqrt(abs(v) / 64.0), -1.0, 1.0);
}

float srwDecP(vec3 c) {
    float s = srwDec(c, -1.0, 1.0);
    return sign(s) * s * s * 64.0;
}

#endif
