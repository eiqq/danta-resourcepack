#ifndef SRW_ATMOS_GLSL
#define SRW_ATMOS_GLSL

// 안개 UBO(FogColor)가 필요한 분위기 함수. minecraft:fog.glsl 이 Fog 블록 다음에 include 한다.
#include <srw:srw_core.glsl>

// 밤 정도(0 낮 ~ 1 밤): 바닐라 안개색 밝기로 판단(서버가 자정 고정. 낮으로 바꿔도 예전 모습으로 돌아가게)
float srwNight() {
    return 1.0 - smoothstep(0.045, 0.22, dot(FogColor.rgb, vec3(0.3, 0.5, 0.2)));
}

// 시선 방향(카메라 기준 단위 벡터): 셰이더가 apply_fog 전에 넣음. 안개에 다 묻힌 물체가 뒤 배경(하늘 높이별 색·먼 바다)과 같은 색이 되게
vec3 srwFogDir = vec3(0.0, -1.0, 0.0);

// 연무색(번개 때 밝아짐). 밤 = 수평선 위는 그 높이의 하늘색, 아래는 먼 바다 연무색(하늘 셰이더와 같은 이음), 낮 = 바닐라 안개색
vec3 srwHazeColor(float flash) {
    vec3 day = FogColor.rgb * (1.0 + flash * 1.3);
    vec3 night = mix(SRW_NIGHT_FOG, srwNightSky(srwFogDir), smoothstep(-0.012, 0.008, srwFogDir.y)) * (1.0 + flash * 2.4);
    return mix(day, night, srwNight());
}

// 거리 → 연무 정도(0~1). 지수 곡선: 가까이는 맑고 멀수록 뿌옇게(밤엔 조금 더 짙게)
// 밤 안개 = 공기 속에 있는 매질처럼: 수면 가까이 짙고(높이 밀도, 해수면 위 24블록 규모) 바람 따라 흐르는 짙고 옅은 덩어리.
// 시선 선분의 평균 밀도로 '실효 거리'를 만들어 srwFogCurve 에 넣음 → 몸 가운데 높이(수면 위 약 30)에서 150/250 기준이 맞고,
// 다리는 먼저 안개에 잠기고 머리는 늦게 묻힘. 덩어리가 지나가며 몸 일부만 가려 반투명처럼 보이지 않게
float srwFogDensity(float h) {
    return 0.55 + 1.1 * exp(-max(h, 0.0) / 24.0);
}

float srwHazeAmount(float dist) {
    float day = (1.0 - exp(-max(dist - 4.0, 0.0) / 215.0)) * 0.95;
    float night = srwNight();
    if (night < 0.001) {
        return day;
    }
    vec3 cam = vec3(CameraBlockPos) - CameraOffset;
    float y0 = cam.y - SRW_SEA_Y;
    float y1 = y0 + srwFogDir.y * dist;
    float dy = y1 - y0;
    float avg = abs(dy) < 0.5 ? srwFogDensity(0.5 * (y0 + y1)) : 0.55 + 1.1 * 24.0 * (exp(-max(y0, 0.0) / 24.0) - exp(-max(y1, 0.0) / 24.0)) / dy;
    vec3 mid = cam + srwFogDir * dist * 0.6;
    float t = srwSeconds();
    float bank = 0.62 + 0.76 * srwFbm(mid.xz * 0.011 + vec2(mid.y * 0.004) + SRW_WIND * t * 0.035, 3);
    float eff = dist * avg / srwFogDensity(30.0) * bank;
    return mix(day, srwFogCurve(eff), night);
}

#endif
