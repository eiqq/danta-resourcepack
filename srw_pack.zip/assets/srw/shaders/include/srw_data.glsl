#ifndef SRW_DATA_GLSL
#define SRW_DATA_GLSL

// 조각 셰이더 전용: 데이터 줄(맨 아래·맨 위 한 줄, 왼쪽 SRW_DATA_W 칸)이면 true.
// 반투명(물·비·입자)이 이 칸을 덮어 조명 데이터를 망치지 않게 그 자리 조각을 버릴 때 쓴다.
#include <minecraft:globals.glsl>
#include <srw:srw_core.glsl>

bool srwDataPixel() {
    return gl_FragCoord.x < float(SRW_DATA_W) && (gl_FragCoord.y < 1.0 || gl_FragCoord.y > ScreenSize.y - 1.0);
}

#endif
