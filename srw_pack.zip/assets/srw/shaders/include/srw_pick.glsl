// 기체 선택 픽창(plugin Pick · tools/pick_glyphs.py) — text.vsh(IS_GUI)에 덧붙인 훅. 글자 한 줄을 덩어리마다 화면 자리로 옮김.
// 판 = 보스바 제목(맨 위 보스바, 줄 y 3): [바탕 66][머리 180][카드 128 ×5][팀 190 ×2][결과 202] (각 덩어리 정확히 그 칸만큼 전진, 가운데 정렬)
//   글자색 R 253 = 덩어리: G = 번호(0 바탕 1 머리 2~6 카드 7·8 팀 9 결과), B = 색 번호. 카드 다섯은 0.74배(GUI 480 폭에도 들어가게)
// 커서 = 액션바(줄 y = 화면 높이 − 72): [커서 18 ×4], 글자색 R 252~249 = 커서 0~3, G·B = 화면 가운데 기준 GUI 칸 / 2 + 128 (Pick.java 와 같게)
// 덩어리 기준점 = (줄 시작 + 앞 덩어리 너비 합, 줄 y − 1 = 0번 글자 줄 윗변) → 가운데 + 자리 + (원래 − 기준점) × 배율.
// 바탕은 화면 전체(조금 넘치게)로 늘림. 색은 픽창 팔레트, 커서는 그림 색 그대로. crtInfo.x: 1 = 주사선(text.fsh 브라운관), 3 = 그대로.
const float PICK_TITLE_Y = 3.0;
const float PICK_TOTAL = 1468.0;
const float PICK_OFF[10] = float[10](0.0, 66.0, 246.0, 374.0, 502.0, 630.0, 758.0, 886.0, 1076.0, 1266.0);
const vec2 PICK_AT[10] = vec2[10](vec2(0.0), vec2(-176.0, -106.0), vec2(-236.0, -70.0), vec2(-141.0, -70.0), vec2(-46.0, -70.0), vec2(49.0, -70.0),
                                 vec2(144.0, -70.0), vec2(-196.0, 70.0), vec2(6.0, 70.0), vec2(-200.0, -24.0));
const float PICK_SCALE[10] = float[10](1.0, 2.0, 0.74, 0.74, 0.74, 0.74, 0.74, 1.0, 1.0, 2.0);
const float PICK_CUR_TOTAL = 72.0, PICK_CUR_W = 18.0, PICK_BG = 64.0;

vec3 pickPalette(int i) {
    if (i == 0) return vec3(0.93, 0.96, 1.00); // 흰
    if (i == 1) return vec3(0.43, 0.86, 1.00); // 청록
    if (i == 2) return vec3(0.24, 0.47, 0.55); // 청록 어둡게
    if (i == 3) return vec3(1.00, 0.36, 0.27); // A 팀
    if (i == 4) return vec3(0.27, 0.55, 1.00); // B 팀
    if (i == 6) return vec3(0.78, 0.43, 1.00); // 두 팀 다
    if (i == 7) return vec3(0.43, 0.46, 0.49); // 회색(못 고름·흐리게)
    if (i == 8) return vec3(1.00, 0.70, 0.24); // 호박(시간 얼마 안 남음)
    if (i == 9) return vec3(0.35, 1.00, 0.55); // 초록(정해짐)
    if (i == 10) return vec3(0.59, 0.65, 0.69); // 글 어둡게
    return vec3(1.0);                          // 5 = 그림 색 그대로
}

// 픽창 글자면 pos·색·crtInfo 를 고치고 true
bool srwPick(inout vec3 pos, vec4 color, float guiW, float guiH, out vec4 outColor, out vec4 info) {
    outColor = color;
    info = vec4(0.0, pos.y, pos.xy);
    int r = int(color.r * 255.0 + 0.5);
    if (r < 249 || r > 253) return false;
    vec2 c = vec2(guiW, guiH) * 0.5;
    int g = int(color.g * 255.0 + 0.5), b = int(color.b * 255.0 + 0.5);
    if (r == 253) {
        int e = clamp(g, 0, 9);
        vec2 rel = pos.xy - vec2(c.x - PICK_TOTAL * 0.5 + PICK_OFF[e], PICK_TITLE_Y - 1.0);
        if (e == 0) pos.xy = rel / PICK_BG * vec2(guiW, guiH) * 1.2 - vec2(guiW, guiH) * 0.1; // 화면 전체(넘치게)
        else pos.xy = c + PICK_AT[e] + rel * PICK_SCALE[e];
        outColor = vec4(pickPalette(b), color.a);
        info = vec4(1.0, pos.y, pos.xy);
    } else {
        float slot = float(252 - r);
        vec2 rel = pos.xy - vec2(c.x - PICK_CUR_TOTAL * 0.5 + slot * PICK_CUR_W, guiH - 73.0);
        pos.xy = c + vec2(float(g - 128), float(b - 128)) * 2.0 + rel;
        outColor = vec4(1.0, 1.0, 1.0, color.a);
        info = vec4(3.0, pos.y, pos.xy);
    }
    return true;
}
