// 기체 선택 픽창(plugin Pick · tools/pick_glyphs.py) — text.vsh(IS_GUI)에 덧붙인 훅. 글자 한 줄을 덩어리마다 화면 자리로 옮김.
// 판 = 보스바 제목(맨 위 보스바, 줄 y 3): [바탕 66][머리 180][카드 128 ×8][팀 190 ×2][결과 띠 202][안내 300] (각 덩어리 정확히 그 칸만큼 전진, 가운데 정렬)
//   글자색 R 253 = 덩어리: G = 번호(0 바탕 · 1 머리 · 2~9 카드 · 10·11 팀 · 12 결과 띠 · 13 안내) + 16 × 카드 장수, B = 색 번호
// 커서 = 액션바(줄 y = 화면 높이 − 72): [커서 18 ×4], 글자색 R 252~249 = 커서 0~3, G·B = 설계 화면 가운데 기준 칸 / 2 + 128 (Pick.java 와 같게)
// 설계 화면 = GUI 480×270: 자리는 모두 그 가운데 기준 칸, 화면에 꽉 차게 통째로 줄이거나 키움(fit) — 4:3·큰 GUI 배율에서도 안 잘리고 어느 GUI 크기에서나 같은 모습.
// 카드는 한 줄, 장수 n 에 따라 배율(Pick.cardScale 과 같은 식 — plugin/check/PickCheck 가 배치를 검사): 5장 0.74 · 6장 0.62 · 7장 0.53 · 8장 0.46.
// 덩어리 기준점 = (줄 시작 + 앞 덩어리 너비 합, 줄 y − 1 = 0번 글자 줄 윗변) → 가운데 + (자리 + (원래 − 기준점) × 배율) × fit.
// 바탕은 화면 전체(조금 넘치게)로 늘림. 색은 픽창 팔레트, 커서는 그림 색 그대로. crtInfo.x: 1·3 = 그대로(text.fsh 효과 없음).
const float PICK_TITLE_Y = 3.0;
const float PICK_TOTAL = 2152.0;
const int PICK_MAX = 8; // 카드 한도(Pick.MAX_CARDS)
const float PICK_HEAD_OFF = 66.0, PICK_CARD_OFF = 246.0, PICK_CARD_W = 128.0, PICK_PANEL_OFF = 1270.0, PICK_PANEL_W = 190.0, PICK_BANNER_OFF = 1650.0, PICK_HINT_OFF = 1852.0;
const float PICK_CARD_PX = 124.0, PICK_CARD_PY = 132.0, PICK_ROW_W = 472.0, PICK_GAP = 2.0, PICK_CARD_MID = -10.0, PICK_CARD_MAX = 0.74;
const float PICK_DESIGN_W = 480.0, PICK_DESIGN_H = 270.0;
const float PICK_CUR_TOTAL = 72.0, PICK_CUR_W = 18.0, PICK_BG = 64.0;

vec3 pickPalette(int i) {
    if (i == 0) return vec3(0.93, 0.96, 1.00); // 흰
    if (i == 1) return vec3(0.43, 0.86, 1.00); // 청록
    if (i == 2) return vec3(0.24, 0.47, 0.55); // 청록 어둡게
    if (i == 3) return vec3(1.00, 0.36, 0.27); // A 팀
    if (i == 4) return vec3(0.27, 0.55, 1.00); // B 팀
    if (i == 6) return vec3(0.78, 0.43, 1.00); // 두 팀 다
    if (i == 7) return vec3(0.43, 0.46, 0.49); // 회색(못 고름·흐리게)
    if (i == 8) return vec3(1.00, 0.70, 0.24); // 호박(시간 얼마 안 남음)
    if (i == 9) return vec3(0.35, 1.00, 0.55); // 초록(정해짐)
    if (i == 10) return vec3(0.59, 0.65, 0.69); // 글 어둡게
    return vec3(1.0);                          // 5 = 그림 색 그대로
}

// 픽창 글자면 pos·색·crtInfo 를 고치고 true
bool srwPick(inout vec3 pos, vec4 color, float guiW, float guiH, out vec4 outColor, out vec4 info) {
    outColor = color;
    info = vec4(0.0, pos.y, pos.xy);
    int r = int(color.r * 255.0 + 0.5);
    if (r < 249 || r > 253) return false;
    vec2 c = vec2(guiW, guiH) * 0.5;
    float fit = min(min(guiW / PICK_DESIGN_W, guiH / PICK_DESIGN_H), 4.0);
    int g = int(color.g * 255.0 + 0.5), b = int(color.b * 255.0 + 0.5);
    if (r == 253) {
        int n = g / 16, e = g - (g / 16) * 16;
        float off = 0.0, sc = 1.0;
        vec2 at = vec2(0.0);
        if (e == 1) { // 머리(제목·남은 시간)
            off = PICK_HEAD_OFF;
            at = vec2(-176.0, -106.0);
            sc = 2.0;
        } else if (e >= 2 && e < 2 + PICK_MAX) { // 카드: 장수에 맞춰 한 줄 가운데 정렬
            float k = float(e - 2), cnt = float(max(n, 1));
            sc = min(PICK_CARD_MAX, (PICK_ROW_W - PICK_GAP * (cnt - 1.0)) / (PICK_CARD_PX * cnt));
            float step = PICK_CARD_PX * sc + PICK_GAP;
            off = PICK_CARD_OFF + PICK_CARD_W * k;
            at = vec2(-(step * cnt - PICK_GAP) * 0.5 + step * k, PICK_CARD_MID - (PICK_CARD_PY * 0.5 - 4.0) * sc); // 카드 그림은 글자 줄보다 4칸 위에서 시작
        } else if (e == 2 + PICK_MAX || e == 3 + PICK_MAX) { // 팀 둘
            float t = float(e - 2 - PICK_MAX);
            off = PICK_PANEL_OFF + PICK_PANEL_W * t;
            at = vec2(t < 0.5 ? -196.0 : 6.0, 70.0);
        } else if (e == 4 + PICK_MAX) { // 결과 띠
            off = PICK_BANNER_OFF;
            at = vec2(-200.0, -24.0);
            sc = 2.0;
        } else if (e == 5 + PICK_MAX) { // 안내 줄
            off = PICK_HINT_OFF;
            at = vec2(-150.0, 106.0);
        }
        vec2 rel = pos.xy - vec2(c.x - PICK_TOTAL * 0.5 + off, PICK_TITLE_Y - 1.0);
        if (e == 0) pos.xy = rel / PICK_BG * vec2(guiW, guiH) * 1.2 - vec2(guiW, guiH) * 0.1; // 화면 전체(넘치게)
        else pos.xy = c + (at + rel * sc) * fit;
        outColor = vec4(pickPalette(b), color.a);
        info = vec4(1.0, pos.y, pos.xy);
    } else {
        float slot = float(252 - r);
        vec2 rel = pos.xy - vec2(c.x - PICK_CUR_TOTAL * 0.5 + slot * PICK_CUR_W, guiH - 73.0);
        pos.xy = c + (vec2(float(g - 128), float(b - 128)) * 2.0 + rel) * fit;
        outColor = vec4(1.0, 1.0, 1.0, color.a);
        info = vec4(3.0, pos.y, pos.xy);
    }
    return true;
}
