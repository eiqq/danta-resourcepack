#ifndef SRW_ROBOT_GLSL
#define SRW_ROBOT_GLSL

// 로봇 재질: 아이템 틴트 R = 247 이면 로봇 면. G = 노멀 절반까지 가로 거리(px/16), B = 재질(1 = 장갑, 2 = 발광 유리, 3 = 고정색).
// 텍스처 = 왼쪽 절반 색, 오른쪽 절반(같은 배치) = 면 접선 공간 노멀 x,y(R,G) + 발광(B).
// 면 접선 공간 = 텍스처 U 증가 방향, V 증가 방향, 면 법선. 화면 미분으로 세계 방향을 되살린다(정점 법선은 6방향으로 뭉개져 안 씀).
// 틴트 R = 248 = 조명 표식(G = 조명 칸, B = 0 위치 / 1 방향점 / 2 카메라): item.vsh 가 데이터 줄로 옮겨 그림.

#define SRW_MAGIC 247
#define SRW_MARKER 248
#define SRW_LIT 1
#define SRW_GLOW 2
#define SRW_FLAT 3 // 고정색(예광탄 등): 조명·그림자·안개 없이 텍스처 색 그대로 — 어디서나 같은 색 점으로 보임(GCB 팩 '짝수 알파 = 빛 무시'와 같은 생각)

const vec3 SRW_SUN_DIR = vec3(-0.3584, 0.7168, 0.5974);

ivec2 srwMaterial(vec4 color) {
    ivec3 c = ivec3(round(color.rgb * 255.0));
    if (c.r != SRW_MAGIC || color.a < 0.99) {
        return ivec2(0);
    }
    return ivec2(c.b, c.g);
}

#ifndef SRW_VERTEX
// discard 전에(균일한 흐름에서) 미분·노멀 표본을 모아 둔다 — 잘린 픽셀과 같은 2×2 묶음의 미분이 깨지지 않게
struct SrwFrag {
    vec3 dpx;
    vec3 dpy;
    vec2 dtx;
    vec2 dty;
    vec4 nt;
};

SrwFrag srwGather(sampler2D tex, vec2 uv, ivec2 mat, vec3 pos) {
    SrwFrag f;
    f.dpx = dFdx(pos);
    f.dpy = dFdy(pos);
    f.dtx = dFdx(uv);
    f.dty = dFdy(uv);
    float halfU = float(mat.y * 16) / float(textureSize(tex, 0).x);
    f.nt = textureGrad(tex, uv + vec2(halfU, 0.0), f.dtx, f.dty);
    return f;
}

// pos = 카메라 기준 세계 좌표(정점 Position 그대로 보간)
vec3 srwNormal(SrwFrag f, vec3 pos, out float emis) {
    emis = f.nt.b;
    vec3 tn = vec3(f.nt.rg * 2.0 - 1.0, 0.0);
    tn.z = sqrt(max(1.0 - dot(tn.xy, tn.xy), 0.0));
    vec3 n = normalize(cross(f.dpx, f.dpy));
    if (dot(n, pos) > 0.0) {
        n = -n;
    }
    vec3 p2 = cross(f.dpy, n);
    vec3 p1 = cross(n, f.dpx);
    vec3 t = p2 * f.dtx.x + p1 * f.dty.x;
    vec3 b = p2 * f.dtx.y + p1 * f.dty.y;
    float im = inversesqrt(max(max(dot(t, t), dot(b, b)), 1e-30));
    return normalize(t * im * tn.x + b * im * tn.y + n * tn.z);
}

// 조명. 낮 = 흐린 하늘 환경광 + 약한 위쪽 주광, 밤 = 거의 빛 없음(어두운 실루엣) + 젖은 금속에 비친 밤하늘 + 흘러내리는 빗물 반짝임
// + 가장자리 빛. 번개가 치면 그쪽 면이 확 드러남. 로봇·상대 조명이 비추는 빛은 후처리(srw_light)가 깊이로 더함
vec3 srwLight(vec3 albedo, vec3 n, vec3 pos, float emis) {
    vec3 v = normalize(-pos);
    float flash = srwFlash();
    vec3 fd = srwFlashDir();
    vec3 r = reflect(-v, n);
    float nv = max(dot(n, v), 0.0);
    float fres = 0.04 + 0.96 * pow(1.0 - nv, 5.0);
    float night = srwNight();
    vec3 cd = vec3(0.0);
    if (night < 0.999) {
        vec3 ground = vec3(0.06, 0.075, 0.085);
        vec3 amb = mix(ground, FogColor.rgb * 1.08, 0.5 + 0.5 * n.y);
        vec3 key = vec3(0.50, 0.53, 0.58) * max(dot(n, SRW_SUN_DIR), 0.0);
        vec3 env = mix(ground, FogColor.rgb * 1.25, smoothstep(-0.25, 0.45, r.y));
        float spec = pow(max(dot(r, SRW_SUN_DIR), 0.0), 60.0);
        cd = albedo * (amb * 1.45 + key) + env * fres * 0.5 + vec3(0.55, 0.58, 0.62) * spec * 0.45;
        cd += SRW_FLASH * flash * (albedo * (0.2 + 1.3 * max(dot(n, fd), 0.0)) + pow(max(dot(r, fd), 0.0), 16.0) * 0.9);
        cd += albedo * emis * 3.0;
    }
    if (night < 0.001) {
        return cd;
    }
    vec3 amb = mix(vec3(0.005, 0.006, 0.008), vec3(0.018, 0.022, 0.030), 0.5 + 0.5 * n.y);
    vec3 env = srwNightSky(vec3(r.x, abs(r.y), r.z));
    float rim = pow(1.0 - nv, 4.0) * smoothstep(-0.4, 0.5, n.y + 0.2);
    vec3 wp = pos + vec3(CameraBlockPos) - CameraOffset;
    float streak = smoothstep(0.6, 0.95, srwNoise(vec2(dot(wp.xz, vec2(2.3, 1.7)) * 1.3, wp.y * 0.2 + srwSeconds() * 0.9)));
    vec3 cn = albedo * amb * 1.6 + env * fres * (0.7 + 1.1 * streak) + SRW_NIGHT_HORIZON * rim * 0.4;
    cn += SRW_FLASH * flash * (albedo * (0.10 + 2.0 * max(dot(n, fd), 0.0)) + pow(max(dot(r, fd), 0.0), 12.0) * 1.4);
    cn += albedo * emis * 3.2;
    return mix(cd, cn, night);
}

// 조명 표식 → 데이터 줄 색(srw_core.glsl 배치 참고). p = 표식 위치(카메라 기준)
vec3 srwMarkerColor(ivec2 mk, vec3 p) {
    int kind = mk.x - 1;
    int x = int(gl_FragCoord.x);
    if (kind == 2) {
        if (x == 0) {
            return SRW_DATA_CHECK;
        }
        if (x <= 9) {
            int q = x - 1;
            return srwEnc(ModelViewMat[q / 3][q % 3], -1.0, 1.0);
        }
        if (x <= 25) {
            int q = x - 10;
            return srwEncP(ProjMat[q / 4][q % 4]);
        }
        if (x <= 28) {
            vec3 cam = vec3(CameraBlockPos) - CameraOffset;
            return srwEnc(cam[x - 26], -32768.0, 32768.0);
        }
        return srwEnc(FogColor[min(x - 29, 2)], 0.0, 1.0); // 29~31 = 바닐라 안개색(후처리 바다의 낮·밤 판단·연무색)
    }
    int j = x - (32 + mk.y * 8);
    if (kind == 0) {
        return j == 0 ? SRW_DATA_CHECK : srwEnc(p[clamp(j - 1, 0, 2)], -1024.0, 1024.0);
    }
    return srwEnc(p[clamp(j - 4, 0, 2)], -1024.0, 1024.0);
}
#endif

#endif
