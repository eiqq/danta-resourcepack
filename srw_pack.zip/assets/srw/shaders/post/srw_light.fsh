#version 330
#extension GL_ARB_separate_shader_objects : require

// 로봇 조명이 실제로 빛을 쏨(지연 조명): 데이터 줄(로봇 조명 표식이 그림)에서 카메라·조명 위치를 읽고, 깊이로 각 픽셀 위치를 되살려
//  ① 표면에 닿는 빛(가까운 로봇·상대 로봇·수면) ② 빗속 산란(빛기둥·후광, 탐조등은 원뿔을 따라 적분) ③ 물결 수면 반사(줄무늬)
// 를 더한다. 수면: 물이 깊이를 쓰는 렌더러(이 26.3 반투명 파이프라인·Sodium)면 깊이 점이 해수면 위에 있을 때 그 점,
//   해저가 깊이에 보이는 렌더러면 해수면 평면과 시선의 교점(카메라가 물 위일 때만 — 물속 시점은 바닐라 그대로).
// 바다 자체도 여기서 그림(지형 셰이더를 갈아 끼우는 Sodium 이어도 똑같이): 해수면 평면 교점에서 바람 쪽 너울 법선·프레넬·밤하늘 반사·
//   화면 공간 반사(로봇·격납고·조명이 물에 비침)·아주 탁한 물(수면 아래 1~2블록만 흐릿, 그 아래 안 보임)·다리·물가 거품 띠·흰 물마루·빗방울 튐·연무.
//   바다 앞 빗줄기·입자는 지우지 않게: 둘레 최솟값(가는 밝은 줄을 뺀 바탕)보다 밝고 위아래로 이어진 것을 살려 위에 다시 얹음.
// 끝으로 데이터 줄을 바로 위(아래) 줄 색으로 덮어 감춘다.
#include <minecraft:globals.glsl>
#include <srw:srw_core.glsl>

#ifdef RENDERPEARL_DEPTH_IS_ZERO_TO_ONE
#define DZ_SCALE 1.0
#define DZ_BIAS 0.0
#else
#define DZ_SCALE 2.0
#define DZ_BIAS -1.0
#endif

uniform sampler2D MainSampler;
uniform sampler2D MainDepthSampler;

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

bool isCheck(vec3 c) {
    return all(lessThan(abs(c - SRW_DATA_CHECK), vec3(0.6 / 255.0)));
}

vec3 px(int x, int row) {
    return texelFetch(MainSampler, ivec2(x, row), 0).rgb;
}

float decAt(int x, int row, float lo, float hi) {
    return srwDec(px(x, row), lo, hi);
}

// 조명 종류. 칸 0~15(로봇, 칸 % 8): 0 원자로, 1 바이저, 2·3 탐조등(원뿔), 4·5 어깨 점멸등, 6 조종석 실내등, 7 플라즈마 탄
// 칸 16~23(격납고, (칸 − 16) % 4): 0·1 앞 위 양옆(상반신), 2 뒤 위(머리·어깨 윤곽), 3 바닥에서 다리 한 곳(국소) — Arena.java
void lightDef(int slot, float t, out vec3 col, out float I, out float r, out float cosIn, out float cosOut, out float scat) {
    cosIn = -2.0;
    cosOut = -2.0;
    int id = slot % 8;
    if (slot >= 26) { // 연출 조명(경기 끝 장면의 주광 — plugin Finale·Effects.keyLight): 차가운 흰빛, 넓게, 빗속 산란은 약하게(빛 덩어리가 안 보이게)
        col = vec3(0.80, 0.90, 1.0);
        I = 1.6;
        r = 30.0;
        scat = 0.12;
    } else if (slot >= 24) { // 효과 조명(타격 순간 번쩍임 — 유저 11/10 '타격 효과는 사실적으로'): 불똥 빛 같은 따뜻한 흰빛 점 조명. 세기는 main 이 표식 배율로 곱함
        col = vec3(1.0, 0.70, 0.40);
        I = 3.4;  // × 표식 배율(주먹 ≈ 2.5~3.5) → 맞은 자리 둘레 4~5블록만 하얗게, 25블록 밖은 은은히(기체 전체가 사진 플래시처럼 밝아지면 과함)
        r = 8.0;
        scat = 0.8;
    } else if (slot >= 16) {
        int k = (slot - 16) % 4;
        // 짧은 반경(r): 로봇(≈45블록)보다 먼 벽·바닥은 빨리 어두워짐. 세기는 로봇 면이 하얗게 날아가지 않게(정면 ≈ 0.4)
        if (k == 3) { // 바닥 → 무릎 근처 한 곳(은은하게)
            col = vec3(1.0, 0.78, 0.52);
            I = 0.45;
            r = 14.0;
            cosIn = 0.9962;
            cosOut = 0.9877;
            scat = 0.08;
        } else if (k == 2) { // 뒤 위 → 머리·어깨 윤곽
            col = vec3(0.70, 0.82, 1.0);
            I = 2.0;
            r = 35.0;
            cosIn = 0.9848;
            cosOut = 0.9563;
            scat = 0.2;
        } else { // 앞 양옆(거의 수평) → 가슴·머리 앞면
            col = vec3(0.92, 0.95, 1.0);
            I = 4.5;
            r = 35.0;
            cosIn = 0.9903;
            cosOut = 0.9703;
            scat = 0.22;
        }
    } else if (id == 0) {
        col = vec3(1.0, 0.48, 0.15);
        I = 5.0 * (0.88 + 0.12 * sin(t * 6.3) * sin(t * 2.3 + 1.0));
        r = 6.0;
        scat = 0.6;
    } else if (id == 1) {
        col = vec3(0.45, 0.68, 1.0);
        I = 2.2;
        r = 4.5;
        scat = 0.45;
    } else if (id == 2 || id == 3) {
        col = vec3(0.86, 0.93, 1.0);
        I = 11.0;
        r = 30.0;
        cosIn = 0.9991;
        cosOut = 0.9945;
        scat = 0.55;
    } else if (id == 7) { // 플라즈마 탄(날아가며 빗속·수면을 푸르게 비춤)
        col = vec3(0.35, 0.72, 1.0);
        I = 9.0;
        r = 7.0;
        scat = 1.3;
    } else if (id == 6) { // 조종석 실내등(산란 없음)
        col = vec3(0.55, 0.72, 1.0);
        I = 0.55;
        r = 1.7;
        scat = 0.0;
    } else {
        col = vec3(1.0, 0.13, 0.08);
        float ph = fract(t * 0.5 + (id == 5 ? 0.5 : 0.0));
        I = 0.6 + 3.5 * smoothstep(0.0, 0.03, ph) * (1.0 - smoothstep(0.12, 0.2, ph)); // 늘 은은히 + 2초마다 번쩍
        r = 2.5;
        scat = 0.7;
    }
}

float cone(vec3 fromL, vec3 ld, float cosIn, float cosOut) {
    return cosOut < -1.0 ? 1.0 : smoothstep(cosOut, cosIn, dot(normalize(fromL), ld));
}

float srwFogDensityPost(float h) {
    return 0.55 + 1.1 * exp(-max(h, 0.0) / 24.0);
}

// 화면 좌표(0~1) 깊이 → 그 픽셀 장면 점(시점 공간)
vec3 scenePt(vec2 uv, mat4 invP) {
    vec4 v = invP * vec4(uv * 2.0 - 1.0, texture(MainDepthSampler, uv).r * DZ_SCALE + DZ_BIAS, 1.0);
    return v.xyz / v.w;
}

// 깊이로 되살린 점이 수면인가의 높이 허용치(데이터 줄 투영 행렬이 정확해 실측 ±0.001 — 여유를 둠)
float surfTol(float t) {
    return 0.06 + 0.001 * t;
}

// 반사를 가릴 수 있는 면인가: 하늘·수면(물이 깊이를 씀)·그 아래는 아님(수면에 맞으면 반사가 물색 자신이 됨)
bool reflector(vec3 vs, float ds, mat3 rot, vec3 cam) {
    return ds < 1200.0 && dot(rot[1], vs) + cam.y - SRW_SEA_Y > surfTol(ds);
}

// 화면 공간 반사: 반사 광선을 세계에서 지수 간격으로 걸으며 화면 깊이와 비교, 맞으면 이분 탐색으로 다듬음.
// 수면 위 물체만(해저·물속은 버림). 반환 = (색, 믿음 0~1). P0·R = 카메라 기준 세계
vec4 ssr(vec3 P0, vec3 R, mat3 rot, mat4 proj, mat4 invP, vec3 cam) {
    float s = 1.2, prev = 0.0;
    for (int i = 0; i < 18; i++) {
        vec3 v = rot * (P0 + R * s);
        vec4 c = proj * vec4(v, 1.0);
        if (c.w <= 0.05) {
            break;
        }
        vec2 uv = c.xy / c.w * 0.5 + 0.5;
        if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) {
            break;
        }
        float dq = length(v);
        vec3 vs = scenePt(uv, invP);
        float ds = length(vs);
        if (ds < dq - 0.25 && dq - ds < 5.0 + s * 0.1 && reflector(vs, ds, rot, cam)) {
            float a = prev, b = s;
            for (int k = 0; k < 5; k++) {
                float m = 0.5 * (a + b);
                vec3 vm = rot * (P0 + R * m);
                vec4 cm = proj * vec4(vm, 1.0);
                vec2 um = cm.xy / cm.w * 0.5 + 0.5;
                vec3 vsm = scenePt(um, invP);
                float dsm = length(vsm);
                if (dsm < length(vm) - 0.25 && reflector(vsm, dsm, rot, cam)) {
                    b = m;
                    uv = um;
                } else {
                    a = m;
                }
            }
            vec3 hit = P0 + R * b;
            if (hit.y + cam.y < SRW_SEA_Y - 0.3) {
                return vec4(0.0); // 물속(해저)에 맞음
            }
            vec2 e = min(uv, 1.0 - uv);
            float fade = smoothstep(0.0, 0.07, e.x) * smoothstep(0.0, 0.07, e.y) * (1.0 - smoothstep(90.0, 220.0, b));
            return vec4(texture(MainSampler, uv).rgb, fade);
        }
        prev = s;
        s *= 1.33;
    }
    return vec4(0.0);
}

// 바다 한 픽셀. P = 수면 교점(카메라 기준), L = 수면에서 불투명 면까지 물속 거리(없으면 큼), base = 바다 뒤·앞(입자 뺀) 바탕,
// N = 물결 법선(멀수록 평평), fog = 바닐라 안개색, night = 밤 정도
vec3 seaColor(vec3 P, vec3 dir, float L, bool depthIsWater, float edge, vec3 base, vec3 N, vec3 cam, float crest, vec3 fog, float night, float t,
        mat3 rot, mat4 proj, mat4 invP) {
    float dist = length(P);
    vec3 wp = P + cam;
    float flash = srwFlash();
    vec3 fd = srwFlashDir();
    vec3 V = -dir;
    vec3 R = reflect(dir, N);
    R.y = abs(R.y);
    float fres = 0.02 + 0.98 * pow(1.0 - max(dot(N, V), 0.0), 5.0);
    vec3 sky = mix(fog * 1.1, srwNightSky(R), night);
    sky += SRW_FLASH * flash * (0.14 + 1.4 * pow(max(dot(R, fd), 0.0), 5.0));
    // 달 빛길(11/10): 구름 뒤 달이 물결 꼭대기마다 깨져 반짝임 — 달 쪽 바다에 깊이감, 그 앞에 선 로봇은 역광 윤곽
    float mr = max(dot(R, SRW_MOON_DIR), 0.0);
    float mr8 = mr * mr * mr * mr * mr * mr * mr * mr;
    float mr64 = mr8 * mr8 * mr8 * mr8 * mr8 * mr8 * mr8 * mr8;
    sky += SRW_MOON_COL * night * (0.16 * mr64 + 0.80 * mr64 * mr64 * mr64 * mr64);
    vec3 refl = sky;
    if (dist < 260.0) {
        vec4 h = ssr(P, R, rot, proj, invP, cam);
        refl = mix(sky, h.rgb, h.a * 0.85);
    }
    // 아주 탁한 물: 수면 바로 아래 1~2블록만 흐릿하게(흡수 1.6/블록), 그 아래 = 깊은 물색
    vec3 deep = mix(vec3(0.05, 0.11, 0.13), SRW_NIGHT_SEA, night) * (1.0 + flash * 1.5);
    float T = exp(-L * 1.6);
    vec3 c = mix(mix(deep, base, T * 0.7), refl, fres);
    // 흰 물마루: 너울 꼭대기 + 바람 방향으로 길게 늘인 결(가는 줄), 큰 돌풍 덩어리 안에서만 몰려 일어남
    vec3 foamCol = mix(vec3(0.72, 0.78, 0.82), vec3(0.17, 0.205, 0.25), night) * (1.0 + flash * 3.0);
    vec2 wd = normalize(SRW_WIND);
    vec2 wq = vec2(dot(wp.xz, wd), dot(wp.xz, vec2(-wd.y, wd.x)));
    float foamN = srwFbm(wq * vec2(0.16, 0.55) + vec2(t * 0.9, 0.0), 3);
    float gustF = smoothstep(0.35, 0.75, srwFbm(wp.xz * 0.012 + SRW_WIND * t * 0.02, 2));
    float foam = smoothstep(0.66, 0.95, crest * 0.6 + foamN * 0.6) * (0.35 + 0.65 * gustF) * (1.0 - 0.6 * smoothstep(90.0, 250.0, dist)) * 0.5;
    // 다리·물가 거품 띠: 물 밖으로 솟은 면이 가까움(edge, 화면 둘레 탐색) 또는 불투명 면이 수면 바로 아래(물속 거리 짧음)
    //   — 잡음으로 들쭉날쭉, 바람 따라 흐름
    float band = depthIsWater ? edge : max(edge, 1.0 - smoothstep(0.1, 1.2, L));
    if (band > 0.0) {
        float bn = srwFbm(wp.xz * 1.3 - SRW_WIND * t * 0.9, 3);
        foam = max(foam, band * smoothstep(0.3, 0.7, bn + band * 0.3) * 0.8);
    }
    c = mix(c, foamCol, foam);
    // 빗방울 튐(가까이만): 0.1초마다 다른 칸에서 작은 고리가 퍼지며 사라짐
    float ph = fract(t * 10.0);
    float rr = length(fract(wp.xz * 6.0) - 0.5);
    float ring = 1.0 - smoothstep(0.0, 0.1, abs(rr - mix(0.06, 0.4, ph)));
    float sp = step(0.993, srwHash2(floor(wp.xz * 6.0) + floor(t * 10.0) * 17.0)) * ring * (1.0 - ph * 0.7) * (1.0 - smoothstep(6.0, 26.0, dist));
    c += foamCol * sp * 0.45;
    // 연무(지형 안개와 같은 식: 수면 가까이 짙고 바람 따라 흐르는 덩어리)
    float y0 = cam.y - SRW_SEA_Y;
    float avg = y0 < 0.5 ? srwFogDensityPost(0.25) : 0.55 + 1.1 * 24.0 * (1.0 - exp(-y0 / 24.0)) / y0;
    vec3 mid = cam + dir * dist * 0.6;
    float bank = 0.62 + 0.76 * srwFbm(mid.xz * 0.011 + vec2(mid.y * 0.004) + SRW_WIND * t * 0.035, 3);
    float hzNight = srwFogCurve(dist * avg / srwFogDensityPost(30.0) * bank);
    float hzDay = (1.0 - exp(-max(dist - 4.0, 0.0) / 215.0)) * 0.95;
    float hz = mix(hzDay, hzNight, night);
    vec3 hazeCol = mix(fog * (1.0 + flash * 1.3), SRW_NIGHT_FOG * (1.0 + flash * 2.4), night);
    return mix(c, hazeCol, hz);
}

void main() {
    ivec2 fc = ivec2(gl_FragCoord.xy);
    int H = textureSize(MainSampler, 0).y;
    vec3 col = texelFetch(MainSampler, fc, 0).rgb;
    int row = isCheck(px(0, 0)) ? 0 : (isCheck(px(0, H - 1)) ? H - 1 : -1);
    if (row < 0) { // 데이터 없음(로봇 없음) → 그대로
        fragColor = vec4(col, 1.0);
        return;
    }
    ivec2 sp = fc;
    if (fc.y == row && fc.x < SRW_DATA_W) { // 데이터 줄 감추기: 옆 줄 색·깊이를 씀
        sp = ivec2(fc.x, row == 0 ? 1 : row - 1);
        col = texelFetch(MainSampler, sp, 0).rgb;
    }
    // 카메라
    mat3 rot;
    for (int q = 0; q < 9; q++) {
        rot[q / 3][q % 3] = decAt(1 + q, row, -1.0, 1.0);
    }
    mat4 proj;
    for (int q = 0; q < 16; q++) {
        proj[q / 4][q % 4] = srwDecP(px(10 + q, row));
    }
    vec3 cam = vec3(decAt(26, row, -32768.0, 32768.0), decAt(27, row, -32768.0, 32768.0), decAt(28, row, -32768.0, 32768.0));
    mat4 invP = inverse(proj);
    float depth = texelFetch(MainDepthSampler, sp, 0).r;
    vec2 ndc = (vec2(sp) + 0.5) / vec2(textureSize(MainSampler, 0)) * 2.0 - 1.0;
    #ifdef RENDERPEARL_DEPTH_IS_ZERO_TO_ONE
    float nz = depth;
    #else
    float nz = depth * 2.0 - 1.0;
    #endif
    vec4 vp = invP * vec4(ndc, nz, 1.0);
    vec3 view = vp.xyz / vp.w;
    vec4 vfar = invP * vec4(ndc, 0.5, 1.0);
    vec3 vdir = normalize(vfar.xyz / vfar.w);
    mat3 toWorld = transpose(rot);
    vec3 dir = normalize(toWorld * vdir);
    float tScene = length(view);
    bool sky = tScene > 1200.0;
    if (sky) {
        tScene = 1200.0;
    }
    // 수면(물 위에서 볼 때): 해수면 평면 교점. 물이 깊이를 쓰는 렌더러(Sodium 등)면 깊이 = 수면 → 그 점을 수면으로
    float tW = 1e9;
    if (cam.y > SRW_SEA_Y && dir.y < -1e-4) {
        tW = (SRW_SEA_Y - cam.y) / dir.y;
    }
    // 물이 깊이를 쓰는 렌더러(이 26.3 반투명 파이프라인·Sodium): 깊이로 되살린 점이 해수면 위면 그 점이 수면
    float hS = dir.y * tScene + cam.y - SRW_SEA_Y;
    bool depthIsWater = !sky && cam.y > SRW_SEA_Y && abs(hS) < surfTol(tScene);
    if (depthIsWater) {
        tW = tScene;
    }
    bool water = tW < tScene - 0.05 || depthIsWater;
    float tHit = water ? tW : tScene;
    vec3 P = dir * tHit;
    float t = srwSeconds();
    vec3 fog = vec3(decAt(29, row, 0.0, 1.0), decAt(30, row, 0.0, 1.0), decAt(31, row, 0.0, 1.0));
    float night = 1.0 - smoothstep(0.045, 0.22, dot(fog, vec3(0.3, 0.5, 0.2)));
    // 표면 법선: 수면 = 물결, 그 밖 = 깊이 미분(끊긴 곳은 시선 쪽)
    vec3 dx = dFdx(P), dy = dFdy(P); // 분기 전에(미분은 균일한 흐름에서)
    vec3 N;
    if (water) {
        float crest;
        N = srwWaveNormal(P.xz + cam.xz, t, crest);
        N = normalize(mix(N, vec3(0.0, 1.0, 0.0), smoothstep(70.0, 240.0, tW) * 0.65)); // 멀리는 반짝임 줄임
        // 바다 앞 입자(빗줄기 등)를 살리려 둘레 최솟값 = 바탕, 차이 = 얹을 것(가는 밝은 줄)
        // 둘레는 화면 안·데이터 줄 밖으로(화면 밖은 0 이 읽혀 가장자리 줄이 두 배로 밝아지고, 데이터 줄은 아무 색)
        ivec2 smin = ivec2(0, 1), smax = textureSize(MainSampler, 0) - ivec2(1, 2);
        vec3 b = col;
        b = min(b, texelFetch(MainSampler, clamp(sp + ivec2(2, 0), smin, smax), 0).rgb);
        b = min(b, texelFetch(MainSampler, clamp(sp - ivec2(2, 0), smin, smax), 0).rgb);
        b = min(b, texelFetch(MainSampler, clamp(sp + ivec2(0, 2), smin, smax), 0).rgb);
        b = min(b, texelFetch(MainSampler, clamp(sp - ivec2(0, 2), smin, smax), 0).rgb);
        // 얹을 것 = 바탕보다 뚜렷이 밝고 위아래로 이어진 것(빗줄기·입자)만. 낱점·잔무늬(Sodium 이면 비치는 바닐라 물 텍스처 결)는
        //   세로 연속성과 바탕 밝기에 비례한 문턱으로 거름
        vec3 dv = max(col - b, 0.0);
        vec3 dvU = vec3(0.0), dvD = vec3(0.0);
        for (int k = -1; k <= 1; k++) {
            dvU = max(dvU, texelFetch(MainSampler, clamp(sp + ivec2(k, 3), smin, smax), 0).rgb - b);
            dvD = max(dvD, texelFetch(MainSampler, clamp(sp + ivec2(k, -3), smin, smax), 0).rgb - b);
        }
        dv = min(dv, max(dvU, dvD));
        float bl = dot(b, vec3(0.3333));
        vec3 over = dv * smoothstep(0.01 + 0.2 * bl, 0.03 + 0.45 * bl, max(dv.r, max(dv.g, dv.b))) * 1.1;
        float L = depthIsWater || sky ? 1e3 : tScene - tW;
        // 다리·경사로 거품: 화면 둘레 8곳(≈1.5블록)에서 물 밖으로 솟은 불투명 면(수면 근처 높이)이 세계 거리로 가까우면 띠.
        //   두 곳 이상 맞아야 함(빗방울 튐 입자처럼 작은 것 하나에 맞으면 그 둘레로 거품 고리가 생김)
        float edge = 0.0;
        int hits = 0;
        if (tW < 140.0) {
            vec2 isz = 1.0 / vec2(textureSize(MainSampler, 0));
            float rp = clamp(1.5 * proj[1][1] * 0.5 / isz.y / tW, 2.0, 24.0);
            float a0 = srwHash2(vec2(sp)) * 0.785;
            for (int k = 0; k < 8; k++) {
                float a = a0 + float(k) * 0.785398;
                vec2 uv = clamp((vec2(sp) + 0.5 + vec2(cos(a), sin(a)) * rp) * isz, 1.5 * isz, 1.0 - 1.5 * isz); // 데이터 줄 밖
                vec3 Q = toWorld * scenePt(uv, invP);
                float hq = Q.y + cam.y - SRW_SEA_Y;
                if (hq > surfTol(length(Q)) && hq < 4.0) {
                    float e = 1.0 - smoothstep(0.5, 2.0, length(Q.xz - P.xz));
                    hits += e > 0.0 ? 1 : 0;
                    edge = max(edge, e);
                }
            }
            edge *= hits >= 2 ? 1.0 : 0.0;
        }
        col = seaColor(P, dir, L, depthIsWater, edge, b, N, cam, crest, fog, night, t, rot, proj, invP) + over;
    } else {
        N = normalize(cross(dy, dx));
        if (dot(N, dir) > 0.0) {
            N = -N;
        }
        if (length(dx) + length(dy) > tHit * 0.08) {
            N = -dir;
        }
    }
    float haze = srwFogCurve(tHit);
    vec3 alb = water ? vec3(0.015, 0.02, 0.025) : vec3(0.24, 0.26, 0.30);
    if (!water) { // 11/10: 이 픽셀의 색조(밝기로 나눔)를 반사색에 섞음 — 깊이만으로 비추는 조명이라 재질을 모르던 것 보완. 아주 어두운 픽셀은 잡음이라 안 섞음
        float lum = dot(col, vec3(0.3, 0.5, 0.2));
        alb *= mix(vec3(1.0), clamp(col / max(lum, 0.006), 0.0, 2.0), 0.6 * smoothstep(0.006, 0.035, lum));
    }
    vec3 add = vec3(0.0);
    vec3 surfSum = vec3(0.0);
    float jit = 0.25 + 0.5 * srwHash2(vec2(fc)); // 화면 고정 디더(시간 따라 안 바뀌어 자글거림 없음)
    for (int s = 0; s < SRW_LIGHTS; s++) {
        int x0 = 32 + s * 8;
        if (!isCheck(px(x0, row))) {
            continue;
        }
        vec3 L = vec3(decAt(x0 + 1, row, -1024.0, 1024.0), decAt(x0 + 2, row, -1024.0, 1024.0), decAt(x0 + 3, row, -1024.0, 1024.0));
        vec3 D = vec3(decAt(x0 + 4, row, -1024.0, 1024.0), decAt(x0 + 5, row, -1024.0, 1024.0), decAt(x0 + 6, row, -1024.0, 1024.0));
        if (s >= 16 && dot(L, L) > 160000.0) { // 격납고 조명은 400블록 밖이면 안개 속이라 건너뜀
            continue;
        }
        vec3 ld = normalize(D - L);
        vec3 lc;
        float I, r, cIn, cOut, scat;
        lightDef(s, t, lc, I, r, cIn, cOut, scat);
        if (s >= 24) { // 효과 조명: 표식 배율(방향점까지 거리, 기본 0.5블록) = 세기 → 디스플레이 배율을 0 으로 보간하면 서서히 꺼짐
            I *= min(length(D - L) * 2.0, 3.5);
            ld = vec3(0.0, -1.0, 0.0);
        }
        if (I < 1e-3) {
            continue;
        }
        // ① 표면
        if (!sky || water) {
            vec3 toL = L - P;
            float d2 = dot(toL, toL);
            vec3 l = toL * inversesqrt(max(d2, 1e-4));
            float att = I / (1.0 + d2 / (r * r)) * cone(-toL, ld, cIn, cOut);
            float ndl = max(dot(N, l), 0.0);
            vec3 surf = alb * ndl * att;
            if (water) { // ③ 물결 반사(점 조명은 세로 줄무늬로 길게). 낮엔 햇빛에 묻혀 약하게
                vec3 R = reflect(dir, N);
                surf += pow(max(dot(R, l), 0.0), 36.0) * att * (s >= 26 ? 0.2 : 2.2); // 연출 조명은 수면 반짝임 약하게(카메라 앞 바다에 흰 덩어리가 생김)
                surf *= mix(0.3, 1.0, night);
            }
            surfSum += lc * surf * (1.0 - haze);
        }
        // ② 빗속 산란
        float b = dot(L, dir);
        float h2 = max(dot(L, L) - b * b, 0.0);
        if (cOut < -1.0) { // 점 조명: 닫힌 식 ∫ dt / (h² + r0² + (t−b)²)
            float hh = sqrt(h2 + r * r * 0.12);
            float tm = min(tHit, b + r * 40.0);
            float integ = (atan((tm - b) / hh) - atan(-b / hh)) / hh;
            float ext = 1.0 - srwFogGlow(srwFogCurve(max(b, 0.0))); // 조명 후광은 안개를 잘 뚫음
            add += lc * I * scat * 0.045 * integ * ext;
        } else { // 탐조등: 원뿔 안만 밝게, 10걸음 적분
            float t0 = max(0.0, b - 140.0), t1 = min(tHit, b + 140.0);
            if (t1 > t0) {
                float dt = (t1 - t0) / 16.0;
                float acc = 0.0;
                for (int k = 0; k < 16; k++) {
                    float tt = t0 + (float(k) + jit) * dt;
                    vec3 x = dir * tt - L;
                    float d2 = dot(x, x);
                    float c = cone(x, ld, cIn, cOut);
                    acc += c / (1.0 + d2 / 64.0) * (1.0 - srwFogGlow(srwFogCurve(tt))); // 산란은 짧은 반경(광원 근처만 짙게)
                }
                add += lc * I * scat * 0.018 * acc * dt;
            }
        }
    }
    // 표면 빛 합: 밝을수록 눌러(1.2 → 0.6) 탐조등 둘이 겹친 가슴이 통째로 하얗게 날아가지 않게(11/09 시험 '눈부셔')
    surfSum /= 1.0 + 0.8 * max(surfSum.r, max(surfSum.g, surfSum.b));
    fragColor = vec4(col + add + surfSum, 1.0);
}
