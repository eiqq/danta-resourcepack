#version 330
#extension GL_ARB_separate_shader_objects : require

// 최종: 블룸 + 가로 렌즈 줄(아나모픽, 푸른빛) + 밝은 곳 부드러운 어깨(넘침 방지) + 영화식 색보정(어두운 곳 청록·밝은 곳 따뜻하게,
// 약한 채도 낮춤·S 곡선) + 가장자리 색수차 + 비네트 + 필름 그레인
#include <minecraft:globals.glsl>

uniform sampler2D MainSampler;
uniform sampler2D BloomSampler;
uniform sampler2D StreakSampler;

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

void main() {
    vec2 q = texCoord - 0.5;
    vec2 ca = q * 0.0035;
    vec3 c = vec3(texture(MainSampler, texCoord + ca).r, texture(MainSampler, texCoord).g, texture(MainSampler, texCoord - ca).b);
    c += texture(BloomSampler, texCoord).rgb * 0.8; // 11/09 시험 '눈부셔' → 1.05 에서 줄임
    c += texture(StreakSampler, texCoord).rgb * vec3(0.45, 0.62, 1.0) * 0.55; // 0.9 에서 줄임(가로 눈부심)
    // 어깨: 0.7 위는 부드럽게 눌러 1 에 수렴(밝은 청록 + 블룸이 뒤집히던 문제 없음)
    vec3 e = max(c - 0.7, 0.0);
    c = min(c, 0.7) + e / (1.0 + e * 3.3);
    float l = dot(c, vec3(0.299, 0.587, 0.114));
    c = mix(vec3(l), c, 0.9);
    c *= mix(vec3(0.86, 1.0, 1.10), vec3(1.0), smoothstep(0.02, 0.3, l));   // 어두운 곳 청록
    c *= mix(vec3(1.0), vec3(1.07, 1.0, 0.90), smoothstep(0.35, 0.9, l));    // 밝은 곳 따뜻하게
    c = clamp(c, 0.0, 1.0);
    c = c * c * (3.0 - 2.0 * c) * 0.18 + c * 0.82;
    c *= 1.0 - dot(q, q) * 0.55;
    c += (hash12(gl_FragCoord.xy + fract(GameTime * 1200.0) * 517.0) - 0.5) * 0.022;
    fragColor = vec4(c, 1.0);
}
