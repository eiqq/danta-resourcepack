#version 330
#extension GL_ARB_separate_shader_objects : require

// 블룸 원천: 작게 줄이며 밝은 곳만(원자로·바이저·탐조등·번개). 밤이라 문턱을 낮게
uniform sampler2D MainSampler;

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

vec3 bright(vec3 c) {
    float l = max(c.r, max(c.g, c.b));
    float k = smoothstep(0.42, 0.95, l);
    return c * k * k;
}

void main() {
    vec2 o = 1.5 / vec2(textureSize(MainSampler, 0));
    vec3 c = bright(texture(MainSampler, texCoord + vec2(-o.x, -o.y)).rgb);
    c += bright(texture(MainSampler, texCoord + vec2(o.x, -o.y)).rgb);
    c += bright(texture(MainSampler, texCoord + vec2(-o.x, o.y)).rgb);
    c += bright(texture(MainSampler, texCoord + vec2(o.x, o.y)).rgb);
    fragColor = vec4(c * 0.25, 1.0);
}
