#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:light.glsl>
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:sample_lightmap.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
layout(location = 3) in ivec2 UV1;
layout(location = 4) in ivec2 UV2;
#ifdef GLINT_SPECIAL
layout(location = 5) in vec2 UV3;
#endif
layout(location = 6) in vec3 Normal;

#ifndef OIT_ALPHA_ONLY
uniform sampler2D Sampler1;
uniform sampler2D Sampler2;

layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif
layout(location = 2) out vec4 vertexColor;
#ifndef OIT_ALPHA_ONLY
layout(location = 3) out vec4 lightMapColor;
layout(location = 4) out vec4 overlayColor;
#endif

layout(location = 5) out vec2 texCoord0;
#ifdef GLINT
layout(location = 6) out vec2 texCoordGlint;
#endif

#include <minecraft:akbfighter_hud.glsl>
#include <minecraft:casino_cursor.glsl>

void main() {
    // 마우스 커서(캐릭터 고르기 화면): 보조손 표식 아이템이면 커서를 그리고 끝(mouse-cursor-pack 그대로)
    if (casino_cursor(Position, Color, UV0, gl_Position, vertexColor)) {
        #ifndef OIT_ALPHA_ONLY
        lightMapColor = vec4(1.0);
        overlayColor = vec4(1.0);
        sphericalVertexDistance = 0.0;
        cylindricalVertexDistance = 0.0;
        #endif
        texCoord0 = UV0;
        #ifdef GLINT
        texCoordGlint = UV0;
        #endif
        return;
    }

    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    #ifndef OIT_ALPHA_ONLY
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    #endif
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
    #ifndef OIT_ALPHA_ONLY
    lightMapColor = sample_lightmap(Sampler2, UV2);
    overlayColor = texelFetch(Sampler1, UV1, 0);
    #endif

    texCoord0 = UV0;
    #ifdef GLINT
    #ifdef GLINT_SPECIAL
    texCoordGlint = (TextureMat * vec4(UV3, 0.0, 1.0)).xy;
    #else
    texCoordGlint = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
    #endif
    #endif

    // 로비 먼 배경(파노라마 고리, 표식 색 253·254·255): 220블록 밖이라 안개에 묻히지 않게 안개·명암을 뺀다
    if (abs(Color.r * 255.0 - 253.0) < 0.5 && abs(Color.g * 255.0 - 254.0) < 0.5 && Color.b * 255.0 > 254.5) {
        vertexColor = vec4(1.0);
        #ifndef OIT_ALPHA_ONLY
        sphericalVertexDistance = 0.0;
        cylindricalVertexDistance = 0.0;
        lightMapColor = vec4(1.0);
        overlayColor = vec4(1.0);
        #endif
    }

    if (akbfighter_hud()) {
        vertexColor = Color;
        #ifndef OIT_ALPHA_ONLY
        sphericalVertexDistance = 0.0;
        cylindricalVertexDistance = 0.0;
        lightMapColor = vec4(1.0);
        overlayColor = vec4(1.0);
        #endif
    }
}
