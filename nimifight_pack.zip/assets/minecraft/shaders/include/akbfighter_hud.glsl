#ifndef AKBFIGHTER_HUD_GLSL
#define AKBFIGHTER_HUD_GLSL

// 화면 그림: 서버(Screen.java)가 MF_HUD_Y 블록 아래로 보낸 디스플레이 정점을 1920x1080 화면에 바로 찍는다.
// 1px = MF_PX 블록, x·y = 화면 가운데 기준(오른쪽·위가 +), z = 층(0~999, 클수록 앞). 세로는 화면에 꽉 차고 가로는 16:9 비율을 유지한다.
#define MF_PX 100.0
#define MF_HUD_Y 1000000.0

bool akbfighter_hud() {
    if (Position.y > -MF_HUD_Y * 0.5) {
        return false;
    }
    vec3 p = vec3(Position.x, Position.y + MF_HUD_Y, Position.z) / MF_PX;
    float keep = 16.0 / 9.0 * abs(ProjMat[0][0] / ProjMat[1][1]);
    gl_Position = vec4(p.x / 960.0 * keep, p.y / 540.0, 0.99 + p.z * 1.0e-5, 1.0);
    return true;
}

#endif
