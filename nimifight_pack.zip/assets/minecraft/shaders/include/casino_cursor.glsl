#ifndef CASINO_CURSOR_GLSL
#define CASINO_CURSOR_GLSL
// 마우스 커서 (Casino mouse 모듈). item.vsh 에서 dynamictransforms/projection include 뒤에 포함하고
// main() 맨 앞에서 호출한다. true 면 이 꼭짓점은 커서(또는 숨길 표식)이므로 gl_Position/vertexColor 가
// 채워졌다. 호출한 쪽은 lightMapColor = vec4(1), overlayColor = vec4(1), 안개 거리 0 으로 두고 return.
//
// 원리 (kr.casino.mouse.MouseSession 주석 참고):
//   1인칭 손 = Rx(a) * Ry(b) * 팔위치 * 아이템,   a = 0.1 * pitch,  b = 0.1 * (yaw - 기준yaw)
//   카메라가 다른 엔티티면 흔들림 기준이 얼어붙으므로 a, b 는 순수한 시점각이다.
//   왼손(보조손) 표식 아이템의 꼭짓점 v (시점 공간) 로부터 a, b 를 거꾸로 푼다.
//
// 표식: 색조 R=254, G=감도*4, B=128+크기/2 (서버 CursorItems 와 같아야 한다).
// 화면 공식: x = 960 + yaw*S, y = 540 + pitch*S  (1920x1080 기준, 서버 CursorMath 와 같아야 한다).

const float CC_SWAY = 0.1;
const vec2 CC_REF = vec2(1920.0, 1080.0);

const float CC_MAX_ERROR = 0.3;      // 1인칭 손 위치에서 이만큼 넘게 벗어나면 남의 손에 든 표식이다

bool cc_is_marker(vec4 color) {
    vec3 c = color.rgb * 255.0;
    return abs(c.r - 254.0) < 0.5 && c.b > 127.5;
}

// 흔들기 전 위치 후보. 팔 위치(±0.56, -0.52, -0.72) 에 아이템 중심 보정(-0.5) 이 붙었는지에 따라 둘,
// 왼손/오른손잡이(보조손 쪽) 에 따라 둘. 회전은 최대 10도 남짓이라 가장 가까운 후보가 정답이다.
vec3 cc_rest(vec3 v, out float error) {
    vec3 best = vec3(0.0);
    error = 1e9;
    for (int i = 0; i < 4; i++) {
        float side = (i & 1) == 0 ? -1.0 : 1.0;
        vec3 c = vec3(side * 0.56, -0.52, -0.72) + ((i & 2) == 0 ? vec3(0.0) : vec3(0.5));
        // 회전은 길이를 바꾸지 않는다: 길이 차이 + 방향 차이를 함께 본다
        float e = distance(v, c);
        if (e < error) {
            error = e;
            best = c;
        }
    }
    return best;
}

// v = Rx(a) * Ry(b) * c 를 만족하는 (a, b) [라디안]
vec2 cc_solve(vec3 v, vec3 c) {
    float r = length(c.xz);
    float phi = atan(c.z, c.x);                       // c.z < 0 이라 phi 는 음수
    float b = phi + acos(clamp(v.x / r, -1.0, 1.0));  // v.x = r * cos(b - phi)
    float wz = -c.x * sin(b) + c.z * cos(b);          // Ry(b) 를 거친 z
    float a = atan(v.z, v.y) - atan(wz, c.y);         // yz 평면에서 돌아간 각
    a = mod(a + 3.14159265, 6.28318531) - 3.14159265;
    return vec2(a, b);
}

bool casino_cursor(vec3 position, vec4 color, vec2 uv0, inout vec4 glPosition, inout vec4 vertexColor) {
    if (!cc_is_marker(color)) {
        return false;
    }
    vec3 v = (ModelViewMat * vec4(position, 1.0)).xyz;
    float error;
    vec3 c = cc_rest(v, error);
    if (error > CC_MAX_ERROR) {
        // 다른 플레이어 손에 든 표식: 아무것도 그리지 않는다(네 꼭짓점을 한 점으로)
        glPosition = vec4(2.0, 2.0, 2.0, 1.0);
        return true;
    }

    vec2 ab = degrees(cc_solve(v, c)) / CC_SWAY;      // (pitch, yaw) 도
    float sensitivity = color.g * 255.0 / 4.0;
    float cursorSize = (floor(color.b * 255.0 + 0.5) - 128.0) * 2.0;   // 커서 높이(1080 기준 px)
    vec2 cursor = clamp(CC_REF * 0.5 + vec2(ab.y, ab.x) * sensitivity, vec2(0.0), CC_REF);

    // 꼭짓점 순서: 0 좌상, 1 좌하, 2 우하, 3 우상 (FaceBakery/CuboidFace). 커서 끝(좌상)이 좌표점.
    int corner = gl_VertexIndex % 4;
    vec2 offset = vec2(corner >= 2 ? 1.0 : 0.0, (corner == 1 || corner == 2) ? 1.0 : 0.0);
    float aspect = ProjMat[1][1] / ProjMat[0][0];     // 화면 가로/세로
    vec2 size = vec2(cursorSize / aspect, cursorSize) / (CC_REF.y * 0.5);

    // DisplayHud 가운데 정렬과 같은 좌표계: 16:9 영역을 유지하고 가운데에 둔다(HUD 버튼과 커서가 맞도록)
    float keep = (16.0 / 9.0) / aspect;
    vec2 ndc = vec2((cursor.x / (CC_REF.x * 0.5) - 1.0) * keep, 1.0 - cursor.y / (CC_REF.y * 0.5));
    ndc += vec2(offset.x * size.x, -offset.y * size.y);

    // 깊이는 손 투영의 근평면 바로 앞을 쓴다(역Z 여부와 무관하게 맨 앞)
    vec4 nearPoint = ProjMat * vec4(0.0, 0.0, -0.06, 1.0);
    glPosition = vec4(ndc, nearPoint.z / nearPoint.w, 1.0);
    vertexColor = vec4(1.0);
    return true;
}
#endif
