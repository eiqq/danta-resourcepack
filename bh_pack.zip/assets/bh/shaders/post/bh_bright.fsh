#version 330
#extension GL_ARB_separate_shader_objects : require

// 블룸 원천: 작은 해상도로 줄이며 밝은 곳만 남긴다
uniform sampler2D MainSampler;

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

vec3 bright(vec3 c) {
    float l = max(c.r, max(c.g, c.b));
    float k = smoothstep(0.74, 1.0, l);
    return c * k * k;
}

void main() {
    vec2 px = 1.0 / vec2(textureSize(MainSampler, 0));
    vec2 o = px * 1.5;
    vec3 c = bright(texture(MainSampler, texCoord + vec2(-o.x, -o.y)).rgb);
    c += bright(texture(MainSampler, texCoord + vec2(o.x, -o.y)).rgb);
    c += bright(texture(MainSampler, texCoord + vec2(-o.x, o.y)).rgb);
    c += bright(texture(MainSampler, texCoord + vec2(o.x, o.y)).rgb);
    fragColor = vec4(c * 0.25, 1.0);
}
