#version 330
#extension GL_ARB_separate_shader_objects : require

// 최종 합성: 흔들림·워프 시점 왜곡·블랙홀 흡입·글리치·색수차·블룸·렌즈 플레어·손상 효과·섬광·비네트·그레인·암전·레터박스
#include <minecraft:globals.glsl>
#include <bh:bh_common.glsl>
#include <bh:bh_timeline.glsl>
#include <bh:bh_fx.glsl>
#include <bh:bh_annot_data.glsl>
#include <bh:bh_bits_data.glsl>

uniform sampler2D MainSampler;
uniform sampler2D MainDepthSampler;
uniform sampler2D BloomSampler;
uniform sampler2D WideSampler;
uniform sampler2D StateSampler;
uniform sampler2D LabelsSampler;
uniform sampler2D GcbLogoSampler;

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

const float LETTERBOX = 2.35;

vec4 cell(int x) {
    return texelFetch(StateSampler, ivec2(x, 0), 0);
}

float dec16(float hi, float lo) {
    return (floor(hi * 255.0 + 0.5) * 256.0 + floor(lo * 255.0 + 0.5)) / 65535.0;
}

vec2 stateUV(int x) {
    vec4 a = cell(x);
    vec4 b = cell(x + 1);
    return (vec2(dec16(a.r, a.g), dec16(a.b, b.r)) - 0.375) / 0.25;
}

vec2 aspectVec(vec2 d) {
    return vec2(d.x * ScreenSize.x / ScreenSize.y, d.y);
}

float skyVisible(vec2 p) {
    if (any(lessThan(p, vec2(0.0))) || any(greaterThan(p, vec2(1.0)))) {
        return 0.0;
    }
    return texture(MainDepthSampler, p).r <= 0.0 ? 1.0 : 0.0;
}

vec3 lensFlare(vec2 uv, vec2 sun, float strength) {
    vec2 px = 1.0 / ScreenSize;
    float vis = 0.0;
    for (int i = 0; i < 5; i++) {
        vec2 o = vec2(float(i % 3) - 1.0, float(i / 3) - 0.5) * px * 6.0;
        vis += skyVisible(sun + o);
    }
    vis /= 5.0;
    float k = strength * vis;
    if (k <= 0.0) {
        return vec3(0.0);
    }
    vec2 d = aspectVec(uv - sun);
    float r = length(d);
    vec3 col = vec3(1.0, 0.92, 0.8) * exp(-r * 9.0) * 0.35;
    col += vec3(0.6, 0.75, 1.0) * exp(-abs(d.y) * 260.0) * exp(-abs(d.x) * 2.2) * 0.35;
    col += vec3(1.0, 0.85, 0.6) * smoothstep(0.012, 0.0, abs(r - 0.16)) * 0.05;
    vec2 axis = vec2(0.5) - sun;
    const float GH[5] = float[](0.45, 0.8, 1.25, 1.6, 2.1);
    const float GS[5] = float[](0.035, 0.06, 0.025, 0.09, 0.05);
    for (int i = 0; i < 5; i++) {
        vec2 g = sun + axis * GH[i];
        float gr = length(aspectVec(uv - g));
        vec3 tint = i % 2 == 0 ? vec3(0.45, 0.8, 1.0) : vec3(1.0, 0.6, 0.35);
        col += tint * smoothstep(GS[i], GS[i] * 0.6, gr) * 0.05;
    }
    return col * k;
}

// 폭발: 커지는 불덩이 + 충격파 고리 + 사방으로 튀는 파편
vec3 blast(vec2 d, float r, float age, float power, float seed) {
    float a = age / BLAST_LEN;
    float radius = (0.5 + 2.4 * (1.0 - exp(-age * 3.5))) * power;
    vec2 dir = d / max(r, 1e-4);
    float turb = vnoise(vec3(dir * 3.0, age * 2.0 + seed)) * 0.6 + vnoise(vec3(dir * 9.0, age * 4.0)) * 0.3;
    float edge = radius * (0.75 + 0.5 * turb);
    float body = smoothstep(edge, edge * 0.35, r);
    vec3 hot = mix(vec3(1.0, 0.95, 0.8), vec3(1.0, 0.45, 0.12), sat(a * 1.6 + r / max(radius, 1e-3) * 0.5));
    hot = mix(hot, vec3(0.25, 0.08, 0.04), smoothstep(0.45, 1.0, a));
    vec3 col = hot * body * (1.0 - a) * 2.5;
    col += vec3(1.0, 0.9, 0.75) * exp(-r * r / (0.15 + age * 0.6)) * exp(-age * 5.0) * 4.0 * power;
    float ring = exp(-pow((r - age * 6.0 * power) / (0.25 + age * 0.4), 2.0)) * (1.0 - a);
    col += vec3(0.7, 0.85, 1.0) * ring * 0.5;
    for (int i = 0; i < 10; i++) {
        float h = hash11(float(i) * 3.7 + seed);
        float ang = h * TAU;
        float speed = 3.0 + 6.0 * hash11(float(i) * 5.3 + seed);
        vec2 p = vec2(cos(ang), sin(ang)) * speed * age;
        float dd = length(d - p);
        col += vec3(1.0, 0.7, 0.35) * exp(-dd * dd * 40.0) * (1.0 - a) * 1.5;
    }
    return col;
}

// 손상 지점: 틱틱 튀는 불꽃과 새어 나오는 가스
vec3 damage(vec2 d, float r, float t, float strength, float seed) {
    vec3 col = vec3(0.0);
    for (int i = 0; i < 6; i++) {
        float rate = 3.0 + float(i) * 0.7;
        float k = floor(t * rate + float(i) * 0.37);
        float life = fract(t * rate + float(i) * 0.37);
        float h = hash11(k * 1.3 + float(i) * 7.1 + seed);
        if (h < 0.45) {
            continue;
        }
        float ang = hash11(k * 2.1 + seed) * TAU;
        vec2 dir = vec2(cos(ang), sin(ang));
        vec2 head = dir * (0.3 + 3.5 * life);
        vec2 tail = dir * (0.3 + 3.5 * max(life - 0.12, 0.0));
        vec2 pa = d - tail;
        vec2 ba = head - tail;
        float q = sat(dot(pa, ba) / max(dot(ba, ba), 1e-5));
        float dd = length(pa - ba * q);
        col += vec3(1.0, 0.75, 0.35) * exp(-dd * dd * 120.0) * (1.0 - life) * 1.6;
    }
    float flick = step(0.6, hash11(floor(t * 17.0) + seed)) * exp(-r * r * 3.0);
    col += vec3(0.55, 0.75, 1.0) * flick * 0.8;
    vec2 vent = d - vec2(0.0, 1.0) * 0.6;
    float plume = exp(-dot(vent, vent) * 0.9) * (0.5 + 0.5 * vnoise(vec3(d * 2.5 - vec2(0.0, t * 3.0), seed)));
    col += vec3(0.75, 0.82, 0.9) * plume * 0.18;
    return col * strength;
}

vec3 shipEffects(vec2 uv, float t) {
    vec3 col = vec3(0.0);
    float sceneDepth = texture(MainDepthSampler, uv).r;
    for (int s = 0; s < FX_SLOTS; s++) {
        int base = FX_DATA_BASE + s * 3;
        vec4 b = cell(base + 1);
        vec4 c = cell(base + 2);
        float strength = b.g / 0.7;
        if (strength <= 0.0) {
            continue;
        }
        vec2 p = stateUV(base);
        float pxPerBlock = b.b * 1020.0;
        float depth = dec16(c.r, c.g);
        float kind = step(0.5, c.b);
        float age = (c.b - 0.5 * kind) * 4.0;
        vec2 d = aspectVec(uv - p) * ScreenSize.y / max(pxPerBlock, 1.0);
        float r = length(d);
        if (r > 9.0) {
            continue;
        }
        float hidden = sceneDepth > depth * 1.04 + 1e-6 ? 0.25 : 1.0;
        col += hidden * (kind < 0.5 ? blast(d, r, age, strength, float(s)) : damage(d, r, t, strength, float(s) * 9.0));
    }
    return col;
}


// 홀로그램 주석: 원이 그려지며 나타나고, 점선 고리가 돌고, 연결선 끝에 라벨
float lineSeg(vec2 p, vec2 a, vec2 b) {
    vec2 pa = p - a;
    vec2 ba = b - a;
    float h = sat(dot(pa, ba) / max(dot(ba, ba), 1e-8));
    return length(pa - ba * h);
}

vec3 annotation(vec2 uv, int slot, float t, inout float dim) {
    int base = 26 + slot * 3;
    vec4 b = cell(base + 1);
    vec4 c = cell(base + 2);
    float vis = b.b;
    if (vis <= 0.0) {
        return vec3(0.0);
    }
    vec2 p = stateUV(base);
    float r = clamp(b.g * 0.6, 0.028, 0.30);
    int label = int(c.r * 255.0 + 0.5);
    int style = int(c.g * 255.0 + 0.5);
    bool red = style >= 4;
    style = style % 4;
    float age = c.b;
    float flick = age < 0.25 ? step(0.45, hash11(floor(t * 30.0) + float(slot))) : 1.0;
    vec3 tint = red ? vec3(1.0, 0.30, 0.22) : vec3(0.35, 1.0, 0.62);
    float px = 1.0 / ScreenSize.y;
    vec2 d = aspectVec(uv - p);
    float dist = length(d);
    float rr = r * (1.25 - 0.25 * smoothstep(0.0, 0.5, age));
    float ang = atan(d.y, d.x);
    float sweep = smoothstep(0.0, 0.55, age) * TAU;
    float a0 = mod(ang - PI * 0.5 + TAU, TAU);
    float g = 0.0;
    if (style == 1) {
        vec2 q = abs(d) - vec2(rr);
        float box = max(q.x, q.y);
        float corner = step(rr * 0.55, max(abs(d.x), abs(d.y))) * step(rr * 0.6, min(abs(d.x), abs(d.y)) + rr * 0.35);
        g += exp(-pow(box / (1.4 * px), 2.0)) * step(rr * 0.62, max(abs(d.x), abs(d.y)) - 0.0) * corner;
    } else {
        g += exp(-pow((dist - rr) / (1.5 * px), 2.0)) * step(a0, sweep);
        if (style == 2) {
            g += exp(-pow((dist - rr * 1.04) / (1.0 * px), 2.0)) * 0.5 * step(a0, sweep);
        }
    }
    float dash = step(0.55, fract((ang + t * 0.5) * 12.0 / TAU));
    g += exp(-pow((dist - rr * 1.16) / (1.0 * px), 2.0)) * dash * 0.55 * smoothstep(0.3, 0.7, age);
    for (int k = 0; k < 4; k++) {
        float ta = float(k) * PI * 0.5;
        vec2 dir = vec2(cos(ta), sin(ta));
        g += exp(-pow(lineSeg(d, dir * rr * 0.86, dir * rr * 0.97) / (1.2 * px), 2.0)) * 0.9;
    }
    float side = p.x + 0.42 * ScreenSize.y / ScreenSize.x > 0.97 ? -1.0 : 1.0;
    vec2 elbow = vec2(side * rr * 0.72, rr * 0.72);
    vec2 knee = elbow + vec2(side * 0.035, 0.035);
    vec2 foot = knee + vec2(side * 0.05, 0.0);
    float lineVis = smoothstep(0.35, 0.65, age);
    g += exp(-pow(min(lineSeg(d, elbow, knee), lineSeg(d, knee, foot)) / (1.1 * px), 2.0)) * lineVis;
    vec3 col = tint * g * 1.4;
    vec2 boxSize = vec2(0.40, 0.05);
    vec2 boxMin = foot + vec2(side > 0.0 ? 0.008 : -0.008 - boxSize.x, -boxSize.y * 0.5);
    vec2 lp = (d - boxMin) / boxSize;
    if (all(greaterThanEqual(lp, vec2(0.0))) && all(lessThanEqual(lp, vec2(1.0)))) {
        float show = smoothstep(0.5, 0.8, age);
        vec2 tile = vec2(float(label % 2) * 512.0, float(label / 2) * 64.0);
        vec2 tc = (tile + vec2(lp.x, 1.0 - lp.y) * vec2(512.0, 64.0)) / LABELS_SIZE;
        float a = texture(LabelsSampler, tc).a * show;
        float scan = 0.82 + 0.18 * sin(gl_FragCoord.y * 1.7 + t * 6.0);
        col += mix(tint, vec3(1.0), 0.55) * a * scan * 1.2;
        dim = max(dim, 0.45 * show * vis);
        col += tint * 0.05 * show;
    }
    return col * vis * flick;
}

// GCB 낚시: 시작 직전 화면이 하얘지고 로고가 오른쪽에서 미끄러져 들어와 멈췄다가, 시작 순간 왼쪽으로 빠지며 걷힌다(GCB 서버 anim_fade_logo 와 같은 곡선·틱)
vec3 gcbStart(vec3 c, vec2 tc, float t) {
    float e0 = (t - GCB_WHITE) * 20.0;
    float e1 = (t - GCB_START) * 20.0;
    if (e0 < 0.0 || e1 > 26.0) {
        return c;
    }
    bool before = e1 < 0.0;
    float white = before ? smoothstep(0.0, 1.0, sat(e0 / 10.0)) : 1.0 - smoothstep(0.0, 1.0, sat((e1 - 12.0) / 12.0));
    float logo = before ? smoothstep(0.0, 1.0, sat((e0 - 10.0) / 12.0)) : 1.0 - smoothstep(0.0, 1.0, sat((e1 - 8.0) / 8.0));
    float slide = before ? 0.6 : -0.6;
    c = mix(c, vec3(1.0), white);
    vec2 size = vec2(1024.0 / 384.0, 1.0) * 0.3 * ScreenSize.y;
    float away = 1.0 - logo;
    vec2 center = vec2(0.5 + slide * away * away * ScreenSize.y / ScreenSize.x, 0.5);
    vec2 luv = (tc - center) * ScreenSize / size + 0.5;
    if (all(greaterThanEqual(luv, vec2(0.0))) && all(lessThanEqual(luv, vec2(1.0)))) {
        vec4 l = texture(GcbLogoSampler, vec2(luv.x, 1.0 - luv.y));
        c = mix(c, l.rgb, l.a * logo);
    }
    return c;
}

void main() {
    float t = showTime(GameTime);
    vec2 uv = texCoord;
    vec2 center = vec2(0.5);

    float sh = shakeAmount(t);
    float rot = (vnoise(vec3(t * 9.0, 7.0, 1.0)) - 0.5) * sh * 0.012;
    vec2 d = aspectVec(uv - center);
    d = mat2(cos(rot), sin(rot), -sin(rot), cos(rot)) * d;
    uv = center + vec2(d.x * ScreenSize.y / ScreenSize.x, d.y);
    uv += (vec2(vnoise(vec3(t * 18.0, 0.0, 0.0)), vnoise(vec3(0.0, t * 21.0, 3.0))) - 0.5) * sh * 0.014;

    // 워프: 진행 방향 소실점을 중심으로 시야가 늘어나고(광각) 방사형으로 흐른다
    float w = max(warpOut(t), warpIn(t));
    vec2 vp = cell(6).g > 0.5 ? stateUV(5) : center;
    vec2 wd = uv - vp;
    float wr = length(aspectVec(wd));
    if (w > 0.0) {
        uv = vp + wd * (1.0 - w * 0.22 + w * 0.35 * wr * wr);
    }

    vec2 bhUV = stateUV(3);
    float bhStrength = cell(4).g;
    if (bhStrength > 0.0) {
        float k = bhStrength * bhStrength;
        vec2 bd = uv - bhUV;
        float br = length(aspectVec(bd));
        uv = bhUV + bd * (1.0 + k * 0.7 * smoothstep(0.0, 1.1, br));
    }

    float g = glitchAmount(t);
    if (g > 0.0) {
        float row = floor(uv.y * 48.0);
        float h = hash12(vec2(row, floor(t * 24.0)));
        uv.x += step(0.72, h) * (h - 0.86) * 0.18 * g;
    }

    uv.y = max(uv.y, 3.0 / ScreenSize.y);
    vec2 cav = (uv - center) * (0.0012 + sh * 0.004 + g * 0.012 + bhStrength * 0.01 + w * 0.012);
    vec3 col;
    if (w > 0.02) {
        vec3 acc = vec3(0.0);
        float total = 0.0;
        for (int i = 0; i < 10; i++) {
            float k = float(i) / 9.0;
            vec2 su = uv + (vp - uv) * k * w * 0.18;
            float wt = 1.0 - k * 0.6;
            acc.r += texture(MainSampler, su + cav).r * wt;
            acc.g += texture(MainSampler, su).g * wt;
            acc.b += texture(MainSampler, su - cav).b * wt;
            total += wt;
        }
        col = acc / total;
    } else {
        col.r = texture(MainSampler, uv + cav).r;
        col.g = texture(MainSampler, uv).g;
        col.b = texture(MainSampler, uv - cav).b;
    }

    float bloomGain = t >= T_IDLE ? 0.2 : 1.0;
    col += (texture(BloomSampler, uv).rgb * 0.45 + texture(WideSampler, uv).rgb * 0.35) * bloomGain;
    col += shipEffects(uv, t);
    float dim = 0.0;
    vec3 holo = annotation(texCoord, 0, t, dim) + annotation(texCoord, 1, t, dim);
    col = col * (1.0 - dim) + holo;

    float sunOn = cell(2).g;
    if (sunOn > 0.0) {
        col += lensFlare(uv, stateUV(1), sunOn);
    }

    col += vec3(0.9, 0.95, 1.0) * (warpFlash(t) * 0.9 + impactFlash(t));
    if (g > 0.0) {
        float scan = hash12(vec2(floor(gl_FragCoord.y * 0.5), floor(t * 30.0)));
        col = mix(col, vec3(scan) * 0.6 + col * 0.4, g * 0.25 * step(0.85, scan));
    }

    col = pow(max(col, 0.0), vec3(1.04));
    vec2 vd = aspectVec(texCoord - center);
    col *= 1.0 - (0.35 + 0.3 * w) * smoothstep(0.35, 1.05, length(vd));
    col += (hash12(gl_FragCoord.xy + fract(t * 7.0) * 311.0) - 0.5) * 0.025;
    col *= 1.0 - blackout(t);

    float aspect = ScreenSize.x / ScreenSize.y;
    float bar = max(0.5 - 0.5 * aspect / LETTERBOX, 0.0) * (t < T_IDLE ? smoother01(t / 2.5) : 0.0);
    float edge = 1.0 / ScreenSize.y;
    float inside = smoothstep(bar - edge, bar + edge, texCoord.y) * smoothstep(bar - edge, bar + edge, 1.0 - texCoord.y);
    if (gl_FragCoord.y < 1.0) {
        inside = 0.0;
    }
    fragColor = vec4(gcbStart(col * inside, texCoord, t), 1.0);
}
