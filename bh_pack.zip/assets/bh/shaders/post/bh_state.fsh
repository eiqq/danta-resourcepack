#version 330
#extension GL_ARB_separate_shader_objects : require

// 하늘이 화면 맨 아래 줄에 써 둔 프레임 데이터를 확인해 담는다. 우주선 등에 가려 확인색이 깨진 프레임은 지난 값 유지
uniform sampler2D MainSampler;
uniform sampler2D PrevSampler;

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

const ivec3 DATA_CHECK = ivec3(51, 153, 230);

void main() {
    int x = int(gl_FragCoord.x);
    ivec3 check = ivec3(texelFetch(MainSampler, ivec2(0, 0), 0).rgb * 255.0 + 0.5);
    fragColor = all(equal(check, DATA_CHECK)) ? texelFetch(MainSampler, ivec2(x, 0), 0) : texelFetch(PrevSampler, ivec2(x, 0), 0);
}
