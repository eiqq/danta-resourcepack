#ifndef BH_MATERIAL_GLSL
#define BH_MATERIAL_GLSL

// SPEC.md 4장 매직 틴트(251, 3, B)
const int BHM_NONE = 0;
const int BHM_LIT = 1;
const int BHM_EMISSIVE = 2;
const int BHM_BLINK = 3;
const int BHM_ALARM = 4;
const int BHM_SCREEN = 5;
const int BHM_ENGINE = 6;
const int BHM_ROCK = 16;
const int BHM_ICE = 32;

int bhMaterialMode(vec4 color) {
    ivec3 c = ivec3(color.rgb * 255.0 + 0.5);
    if (c.r != 251 || c.g != 3) {
        return BHM_NONE;
    }
    if (c.b >= 1 && c.b <= 6) {
        return c.b;
    }
    if (c.b >= 16 && c.b < 32) {
        return BHM_ROCK;
    }
    if (c.b >= 32 && c.b < 48) {
        return BHM_ICE;
    }
    return BHM_NONE;
}

float bhMaterialSeed(vec4 color) {
    return float(int(color.b * 255.0 + 0.5) % 16);
}

#endif
