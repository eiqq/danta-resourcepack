#ifndef BH_ATLAS_GLSL
#define BH_ATLAS_GLSL

// tools/atlas/build_atlas.py 와 같은 배치 (x, y, w, h)
const ivec2 ATLAS_SIZE = ivec2(8192, 5124);
const ivec4 R_SKY = ivec4(0, 0, 4096, 2048);
const ivec4 R_EARTH = ivec4(4096, 0, 4096, 2048);
const ivec4 R_EARTH_AUX = ivec4(0, 2048, 4096, 2048);
const ivec4 R_JUPITER = ivec4(4096, 2048, 4096, 2048);
const ivec4 R_MOON = ivec4(0, 4096, 2048, 1024);
const ivec4 R_NOISE = ivec4(2048, 4096, 512, 512);
const ivec4 R_SATURN = ivec4(2560, 4096, 512, 4);
const ivec4 R_RINGS = ivec4(2560, 4100, 512, 4);
const ivec4 R_DISK = ivec4(2048, 4608, 1024, 256);
const ivec4 R_EARTH_L2 = ivec4(3072, 4096, 1024, 512);
const ivec4 R_EARTH_AUX_L2 = ivec4(4096, 4096, 1024, 512);
const ivec4 R_JUPITER_L2 = ivec4(5120, 4096, 1024, 512);
const ivec4 R_MOON_L2 = ivec4(6144, 4096, 512, 256);
const ivec4 R_MARS = ivec4(3072, 4608, 1024, 512);
const ivec4 R_MARS_L2 = ivec4(4096, 4608, 256, 128);
const ivec4 R_VENUS = ivec4(4352, 4608, 1024, 512);

bool isUniverseAtlas(sampler2D s) {
    return textureSize(s, 0) == ATLAS_SIZE;
}

// 영역 안 겹선형(가로는 감싸기, 세로는 고정). uv 0~1
vec4 regionSample(sampler2D s, ivec4 r, vec2 uv) {
    vec2 p = uv * vec2(r.zw) - 0.5;
    vec2 f = fract(p);
    ivec2 i0 = ivec2(floor(p));
    int x0 = int(mod(float(i0.x), float(r.z)));
    int x1 = int(mod(float(i0.x + 1), float(r.z)));
    int y0 = clamp(i0.y, 0, r.w - 1);
    int y1 = clamp(i0.y + 1, 0, r.w - 1);
    vec4 a = texelFetch(s, r.xy + ivec2(x0, y0), 0);
    vec4 b = texelFetch(s, r.xy + ivec2(x1, y0), 0);
    vec4 c = texelFetch(s, r.xy + ivec2(x0, y1), 0);
    vec4 d = texelFetch(s, r.xy + ivec2(x1, y1), 0);
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

// 노이즈 타일(가로·세로 모두 감싸기)
vec4 noiseTex(sampler2D s, vec2 uv) {
    vec2 p = uv * 512.0 - 0.5;
    vec2 f = fract(p);
    ivec2 i0 = ivec2(floor(p));
    ivec2 a0 = ivec2(mod(vec2(i0), 512.0));
    ivec2 a1 = ivec2(mod(vec2(i0 + 1), 512.0));
    vec4 a = texelFetch(s, R_NOISE.xy + ivec2(a0.x, a0.y), 0);
    vec4 b = texelFetch(s, R_NOISE.xy + ivec2(a1.x, a0.y), 0);
    vec4 c = texelFetch(s, R_NOISE.xy + ivec2(a0.x, a1.y), 0);
    vec4 d = texelFetch(s, R_NOISE.xy + ivec2(a1.x, a1.y), 0);
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

// 화면에서 텍셀이 얼마나 작게 보이는지에 따라 1/4 해상도 영역과 섞는다
vec4 regionSampleLod(sampler2D s, ivec4 r0, ivec4 r2, vec2 uv, float texelsPerPixel) {
    float k = remap(texelsPerPixel, 1.5, 4.0);
    vec4 a = k < 1.0 ? regionSample(s, r0, uv) : vec4(0.0);
    vec4 b = k > 0.0 ? regionSample(s, r2, uv) : vec4(0.0);
    return mix(a, b, k);
}

#endif
