#ifndef BH_BITS_DATA_GLSL
#define BH_BITS_DATA_GLSL

// tools/audio/build.py 가 만든다(손으로 고치지 말 것)
const float FAKEOUT_T0 = 593.75;
const float FAKEOUT_T1 = 598.53;
const float GCB_START = 344.41;
const float GCB_WHITE = 342.41;
const float HWAL_CUT = 517.15;
const float HWAL_T0 = 510.82;
const float QUIZ_SONG = 620.04;

const int INSET_N = 13;
const int INSET_COLS = 4;
const int INSET_TILES = 13;
const float INSET_T0[13] = float[](184.26, 271.33, 277.38, 285.57, 288.95, 290.54, 292.15, 299.29, 305.42, 318.29, 658.82, 820.34, 855.75);
const float INSET_T1[13] = float[](192.32, 277.30, 284.29, 288.57, 290.36, 292.07, 299.21, 305.34, 318.21, 330.34, 664.91, 825.09, 861.05);
const int INSET_ID[13] = int[](12, 3, 4, 5, 6, 7, 8, 9, 10, 11, 2, 1, 0);
const int INSET_COLOR[13] = int[](1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1);

#endif
