#ifndef BH_BITS_DATA_GLSL
#define BH_BITS_DATA_GLSL

// tools/audio/build.py 가 만든다(손으로 고치지 말 것)
const float GCB_START = 576.89;
const float GCB_WHITE = 574.89;
const float QUIZ_SONG = 660.54;

#endif
