#ifndef BH_BITS_DATA_GLSL
#define BH_BITS_DATA_GLSL

// tools/audio/build.py 가 만든다(손으로 고치지 말 것)
const float FAKEOUT_T0 = 602.65;
const float FAKEOUT_T1 = 607.43;
const float GCB_START = 353.27;
const float GCB_WHITE = 351.27;
const float HWAL_CUT = 526.05;
const float HWAL_T0 = 519.72;
const float QUIZ_SONG = 628.94;

const int INSET_N = 12;
const int INSET_COLS = 4;
const int INSET_TILES = 12;
const float INSET_T0[12] = float[](184.26, 271.33, 290.82, 297.81, 299.40, 301.01, 308.15, 314.28, 327.15, 667.72, 829.24, 864.65);
const float INSET_T1[12] = float[](192.32, 290.74, 297.73, 299.22, 300.93, 308.07, 314.20, 327.07, 339.20, 673.81, 833.99, 869.95);
const int INSET_ID[12] = int[](11, 3, 4, 5, 6, 7, 8, 9, 10, 2, 1, 0);
const int INSET_COLOR[12] = int[](1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1);

#endif
