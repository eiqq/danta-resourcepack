#ifndef BH_BITS_DATA_GLSL
#define BH_BITS_DATA_GLSL

// tools/audio/build.py 가 만든다(손으로 고치지 말 것)
const float FAKEOUT_T0 = 655.75;
const float FAKEOUT_T1 = 660.53;
const float GCB_START = 622.86;
const float GCB_WHITE = 620.86;
const float HWAL_CUT = 492.55;
const float HWAL_T0 = 486.22;
const float QUIZ_SONG = 682.04;

const int INSET_N = 13;
const int INSET_COLS = 4;
const int INSET_TILES = 13;
const float INSET_T0[13] = float[](160.15, 537.34, 543.38, 553.67, 557.01, 558.60, 570.44, 577.57, 583.87, 596.74, 722.82, 884.34, 919.75);
const float INSET_T1[13] = float[](168.21, 543.30, 551.59, 556.63, 558.42, 560.43, 577.49, 583.79, 596.66, 608.79, 728.91, 889.09, 925.05);
const int INSET_ID[13] = int[](12, 3, 4, 5, 6, 7, 8, 9, 10, 11, 2, 1, 0);
const int INSET_COLOR[13] = int[](1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1);

#endif
