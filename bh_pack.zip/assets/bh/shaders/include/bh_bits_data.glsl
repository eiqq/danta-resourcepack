#ifndef BH_BITS_DATA_GLSL
#define BH_BITS_DATA_GLSL

// tools/audio/build.py 가 만든다(손으로 고치지 말 것)
const float FAKEOUT_T0 = 655.95;
const float FAKEOUT_T1 = 660.73;
const float GCB_START = 623.08;
const float GCB_WHITE = 621.08;
const float HWAL_CUT = 484.58;
const float HWAL_T0 = 478.25;
const float QUIZ_SONG = 682.24;

const int INSET_N = 12;
const int INSET_COLS = 4;
const int INSET_TILES = 12;
const float INSET_T0[12] = float[](534.44, 540.48, 550.77, 554.11, 555.70, 570.66, 577.79, 584.09, 596.96, 723.02, 884.53, 919.95);
const float INSET_T1[12] = float[](540.40, 548.69, 553.73, 555.52, 557.53, 577.71, 584.01, 596.88, 609.01, 729.11, 889.29, 925.25);
const int INSET_ID[12] = int[](3, 4, 5, 6, 7, 8, 9, 10, 11, 2, 1, 0);
const int INSET_COLOR[12] = int[](1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1);

#endif
