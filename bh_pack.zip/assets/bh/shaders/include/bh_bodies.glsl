#ifndef BH_BODIES_GLSL
#define BH_BODIES_GLSL

// 모든 천체 함수는 가상 좌표의 광선(ro, rd)을 받는다. 색은 선형 HDR.
// 불투명 천체는 vec4(색, 덮임) 을 돌려주고, 겹치는 순서는 bh_sky.glsl 이 거리로 정한다.

// ---------------------------------------------------------------- 배경 ----

vec3 starLayer(vec3 d, float cells, float pixAngle, float seed, float prob) {
    vec3 cell = floor(d * cells);
    vec3 h = hash33(cell + seed);
    if (h.z < 1.0 - prob) {
        return vec3(0.0);
    }
    vec3 star = normalize((cell + 0.15 + 0.7 * h) / cells);
    float ang = acos(clamp(dot(d, star), -1.0, 1.0));
    float mag = pow(hash13(cell * 1.7 + seed + 3.1), 5.0);
    float size = pixAngle * (0.7 + 0.6 * mag);
    float core = exp(-ang * ang / (size * size));
    float temp = mix(3200.0, 11000.0, pow(hash13(cell + seed + 7.7), 1.4));
    return mix(vec3(1.0), blackbody(temp), 0.55) * core * (0.03 + 2.2 * mag);
}

vec3 starfield(vec3 d, float pixAngle) {
    return starLayer(d, 60.0, pixAngle, 0.0, 0.10) + starLayer(d, 150.0, pixAngle, 17.0, 0.035) * 0.6 + starLayer(d, 380.0, pixAngle, 41.0, 0.012) * 0.35;
}

vec3 milkyWay(sampler2D atlas, vec3 d, mat3 skyRot, float gain) {
    vec2 uv = dirToEquirect(skyRot * d);
    vec3 c = regionSample(atlas, R_SKY, uv).rgb;
    return c * c * gain;
}

vec3 nebulaHaze(vec3 d, vec3 colA, vec3 colB, float scale, float seed) {
    vec3 q = d * scale + seed;
    float n = fbm3(q, 4);
    float m = fbm3(q * 2.3 + 11.0, 3);
    float filament = pow(1.0 - abs(n * 2.0 - 1.0), 6.0);
    float cloud = smoothstep(0.45, 0.85, n);
    return (colA * cloud + colB * filament * smoothstep(0.35, 0.7, m)) ;
}

vec3 background(sampler2D atlas, vec3 d, float pixAngle, int scene) {
    mat3 skyRot = rotY(0.6) * rotX(0.35);
    float gain = 0.55;
    vec3 neb = vec3(0.0);
    if (scene == S_BETEL) {
        skyRot = rotZ(1.1) * rotY(2.0);
        gain = 0.5;
        neb = nebulaHaze(d, vec3(0.020, 0.006, 0.004), vec3(0.03, 0.012, 0.006), 2.0, 3.0);
    } else if (scene == S_PULSAR) {
        skyRot = rotX(1.2) * rotY(-0.7);
        gain = 0.35;
    } else if (scene == S_BH) {
        skyRot = rotZ(-0.4) * rotY(2.6) * rotX(-0.25);
        gain = 0.9;
        neb = nebulaHaze(d, vec3(0.010, 0.012, 0.030), vec3(0.030, 0.010, 0.040), 1.6, 7.0);
    } else if (scene == S_IDLE) {
        skyRot = rotX(-0.5) * rotY(1.3);
        gain = 0.8;
        neb = nebulaHaze(d, vec3(0.018, 0.010, 0.030), vec3(0.035, 0.020, 0.010), 1.8, 5.0);
    }
    return milkyWay(atlas, d, skyRot, gain) + starfield(d, pixAngle) + neb;
}

// 슬립스트림: 진행 방향을 축으로 흐르는 빛의 터널
vec3 slipstream(vec3 d, vec3 fwd, float w, float t) {
    float c = dot(d, fwd);
    vec3 side = d - fwd * c;
    float sl = length(side);
    vec3 e1 = normalize(cross(fwd, abs(fwd.y) < 0.9 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0)));
    vec3 e2 = cross(fwd, e1);
    vec2 ring = vec2(dot(side, e1), dot(side, e2)) / max(sl, 1e-4);
    float depth = c / max(sl, 0.02);
    float flow = depth * 0.35 - t * 9.0;
    float streak = vnoise(vec3(ring * 9.0, flow));
    streak = pow(smoothstep(0.45, 0.95, streak), 2.0);
    float fine = vnoise(vec3(ring * 31.0, flow * 3.0 + 7.0));
    float walls = smoothstep(-0.2, 0.6, c) * (1.0 - smoothstep(0.92, 0.995, c));
    float core = exp(-sl * sl * 40.0) * step(0.0, c);
    vec3 col = mix(vec3(0.10, 0.25, 0.9), vec3(0.75, 0.9, 1.0), streak) * (streak * 2.2 + fine * 0.25) * walls;
    col += vec3(0.8, 0.9, 1.0) * core * 0.9;
    return col * smoothstep(0.25, 0.75, w);
}

// 워프: 진행 방향(fwd) 둘레 별이 늘어난다
vec3 warpStreaks(sampler2D atlas, vec3 d, vec3 fwd, float w, float pixAngle, int scene) {
    vec3 acc = vec3(0.0);
    vec3 side = d - fwd * dot(d, fwd);
    float sl = length(side);
    if (sl < 1e-4) {
        return background(atlas, d, pixAngle, scene);
    }
    side /= sl;
    float a = acos(clamp(dot(d, fwd), -1.0, 1.0));
    const int N = 10;
    for (int i = 0; i < N; i++) {
        float k = float(i) / float(N - 1);
        float ai = a * (1.0 - w * 0.85 * k);
        vec3 di = normalize(fwd * cos(ai) + side * sin(ai));
        acc = max(acc, starLayer(di, 60.0, pixAngle * (1.0 + 3.0 * w), 0.0, 0.10));
    }
    vec3 base = background(atlas, d, pixAngle, scene) * (1.0 - w);
    return base + acc * (1.0 + 2.0 * w);
}

// --------------------------------------------------------- 지구·달 -------

const float ATM_TOP = 1.026;
const float ATM_HR = 0.0030;
const float ATM_HM = 0.0011;
const vec3 ATM_BR = vec3(16.8, 39.1, 95.9);
const float ATM_BM = 22.0;

vec2 atmDensity(vec3 p) {
    float h = max(length(p) - 1.0, 0.0);
    return vec2(exp(-h / ATM_HR), exp(-h / ATM_HM));
}

vec2 lightDepth(vec3 p, vec3 s) {
    vec2 hit = raySphere(p, s, vec3(0.0), ATM_TOP);
    float len = hit.y;
    const int M = 5;
    float ds = len / float(M);
    vec2 od = vec2(0.0);
    for (int j = 0; j < M; j++) {
        od += atmDensity(p + s * ds * (float(j) + 0.5));
    }
    return od * ds;
}

// 대기 산란: 들어오는 빛(rgb)과 투과율(a)
vec4 atmosphere(vec3 ro, vec3 rd, vec3 s, float tMax) {
    vec2 hit = raySphere(ro, rd, vec3(0.0), ATM_TOP);
    if (hit.x > hit.y || hit.y < 0.0) {
        return vec4(0.0, 0.0, 0.0, 1.0);
    }
    float t0 = max(hit.x, 0.0);
    float t1 = min(hit.y, tMax);
    const int N = 14;
    float ds = (t1 - t0) / float(N);
    vec2 odView = vec2(0.0);
    vec3 sumR = vec3(0.0);
    vec3 sumM = vec3(0.0);
    for (int i = 0; i < N; i++) {
        vec3 p = ro + rd * (t0 + ds * (float(i) + 0.5));
        vec2 dens = atmDensity(p) * ds;
        odView += dens;
        vec2 shadow = raySphere(p, s, vec3(0.0), 0.999);
        if (shadow.x < shadow.y && shadow.y > 0.0) {
            continue;
        }
        vec2 odLight = lightDepth(p, s);
        vec3 tau = ATM_BR * (odView.x + odLight.x) + ATM_BM * 1.1 * (odView.y + odLight.y);
        vec3 att = exp(-tau);
        sumR += dens.x * att;
        sumM += dens.y * att;
    }
    float mu = dot(rd, s);
    float phaseR = 3.0 / (16.0 * PI) * (1.0 + mu * mu);
    const float g = 0.76;
    float phaseM = 3.0 / (8.0 * PI) * ((1.0 - g * g) * (1.0 + mu * mu)) / ((2.0 + g * g) * pow(1.0 + g * g - 2.0 * g * mu, 1.5));
    vec3 inscatter = 14.0 * (sumR * ATM_BR * phaseR + sumM * ATM_BM * phaseM);
    float trans = exp(-dot(ATM_BR * odView.x + ATM_BM * odView.y, vec3(0.3333)));
    return vec4(inscatter, trans);
}

mat3 earthFrame(float t) {
    float lat0 = radians(41.0);
    float lon0 = radians(28.0) + t * 0.0004;
    vec3 n = vec3(cos(lat0) * sin(lon0), sin(lat0), cos(lat0) * cos(lon0));
    vec3 e = vec3(cos(lon0), 0.0, -sin(lon0));
    return mat3(e, n, cross(e, n));
}

vec2 sphereUV(vec3 n) {
    return vec2(atan(n.x, n.z) / TAU + 0.5, acos(clamp(n.y, -1.0, 1.0)) / PI);
}

vec4 earth(sampler2D atlas, vec3 ro, vec3 rd, vec3 s, float t, float pixAngle, out float hitT) {
    vec2 hit = raySphere(ro, rd, vec3(0.0), 1.0);
    bool ground = hit.x < hit.y && hit.x > 0.0;
    hitT = ground ? hit.x : 1e30;
    vec4 atm = atmosphere(ro, rd, s, ground ? hit.x : 1e30);
    if (!ground) {
        return vec4(0.0);
    }
    vec3 p = ro + rd * hit.x;
    vec3 n = normalize(p);
    mat3 frame = earthFrame(t);
    vec3 ne = frame * n;
    vec2 uv = sphereUV(ne);
    float tpp = pixAngle * hit.x / (TAU / 4096.0) / max(dot(n, -rd), 0.15);
    vec4 alb = regionSampleLod(atlas, R_EARTH, R_EARTH_L2, uv, tpp);
    vec4 aux = regionSampleLod(atlas, R_EARTH_AUX, R_EARTH_AUX_L2, uv + vec2(t * 0.00002, 0.0), tpp);
    vec3 sl = frame * s;
    vec2 uvShadow = sphereUV(normalize(ne + sl * 0.012));
    float cloudShadow = regionSample(atlas, R_EARTH_AUX_L2, uvShadow + vec2(t * 0.00002, 0.0)).r;
    vec3 albedo = alb.rgb * alb.rgb * 0.9;
    float ocean = alb.a;
    albedo = mix(albedo, vec3(0.010, 0.025, 0.060), ocean * 0.55);
    float clouds = smoothstep(0.08, 0.85, aux.r);
    float ndl = dot(n, s);
    float day = smoothstep(-0.06, 0.12, ndl);
    vec3 h = normalize(s - rd);
    float glint = pow(max(dot(n, h), 0.0), 180.0) * ocean * (1.0 - clouds) * 6.0;
    vec3 ground_c = albedo * max(ndl, 0.0) * (1.0 - 0.55 * smoothstep(0.2, 0.9, cloudShadow));
    vec3 cloud_c = vec3(0.95, 0.96, 1.0) * max(ndl + 0.05, 0.0) * 1.1;
    vec3 surf = mix(ground_c, cloud_c * 0.8, clouds) * 2.3 + vec3(1.0, 0.92, 0.8) * glint * day;
    float night = 1.0 - smoothstep(-0.18, 0.06, ndl);
    vec3 lights = vec3(1.0, 0.62, 0.28) * aux.g * aux.g * 0.9 * night * (1.0 - 0.75 * clouds);
    vec3 col = surf + lights;
    col = col * atm.a + atm.rgb;
    return vec4(col, 1.0);
}

// 지구 밖 대기 빛(지구에 안 맞는 광선)
vec3 earthLimb(vec3 ro, vec3 rd, vec3 s) {
    vec2 hit = raySphere(ro, rd, vec3(0.0), 1.0);
    if (hit.x < hit.y && hit.x > 0.0) {
        return vec3(0.0);
    }
    return atmosphere(ro, rd, s, 1e30).rgb;
}

mat3 moonFrame() {
    vec3 z = normalize(-MOON_POS);
    vec3 x = normalize(cross(vec3(0.0, 1.0, 0.0), z));
    vec3 y = cross(z, x);
    return mat3(x, y, z);
}

vec4 moon(sampler2D atlas, vec3 ro, vec3 rd, vec3 s, float pixAngle, out float hitT) {
    vec2 hit = raySphere(ro, rd, MOON_POS, MOON_R);
    hitT = 1e30;
    if (hit.x > hit.y || hit.x < 0.0) {
        return vec4(0.0);
    }
    hitT = hit.x;
    vec3 p = ro + rd * hit.x;
    vec3 n = normalize(p - MOON_POS);
    mat3 f = moonFrame();
    vec3 nm = transpose(f) * n;
    vec2 uv = sphereUV(nm);
    float tpp = pixAngle * hit.x / (TAU * MOON_R / 2048.0) * MOON_R / max(dot(n, -rd), 0.15);
    vec4 a = regionSampleLod(atlas, R_MOON, R_MOON_L2, uv, tpp);
    float e = 1.0 / 2048.0;
    float hx = regionSample(atlas, R_MOON, uv + vec2(e, 0.0)).a - a.a;
    float hy = regionSample(atlas, R_MOON, uv + vec2(0.0, e)).a - a.a;
    vec3 tx = normalize(cross(vec3(0.0, 1.0, 0.0), n) + 1e-4);
    vec3 ty = cross(n, tx);
    vec3 nb = normalize(n - (tx * hx + ty * hy) * 3.0 * smoothstep(0.0, 0.25, dot(n, -rd)));
    float mu0 = max(dot(nb, s), 0.0);
    float mu = max(dot(n, -rd), 0.05);
    vec3 albedo = a.rgb * a.rgb;
    vec3 col = albedo * 1.5 * mu0 / (mu0 + mu);
    col += albedo * vec3(0.10, 0.16, 0.30) * 0.08 * sat(dot(n, normalize(-MOON_POS)));
    return vec4(col, 1.0);
}

// --------------------------------------------------------- 가스 행성 ------

const float JUP_U0 = -0.242;
const float JUP_OBL = 0.935;

float jupiterShear(float lat, float t) {
    return 0.0004 * t * sin(lat * 11.0) + 0.0010 * t;
}

// 대적점(지도 u 0.366, 남위 18도)의 현재 위치(목성 반지름 1)
vec3 jupiterGRS(float t) {
    float lat = radians(-18.0);
    float phi = TAU * (0.366 - 0.5 - jupiterShear(lat, t) - JUP_U0);
    vec3 nl = vec3(cos(lat) * sin(phi), sin(lat), cos(lat) * cos(phi));
    return vec3(nl.x, nl.y * JUP_OBL, nl.z);
}

vec4 jupiter(sampler2D atlas, vec3 ro, vec3 rd, vec3 s, float t, float pixAngle, out float hitT) {
    const float OBL = 0.935;
    vec3 sc = vec3(1.0, 1.0 / OBL, 1.0);
    vec3 ros = ro * sc;
    vec3 rds = normalize(rd * sc);
    vec2 hit = raySphere(ros, rds, vec3(0.0), 1.0);
    hitT = 1e30;
    float limbB = length(cross(ros, rds));
    vec3 limbN = normalize(ros + rds * max(-dot(ros, rds), 0.0));
    vec3 haze = vec3(0.75, 0.70, 0.62) * exp(-max(limbB - 1.0, 0.0) * 90.0) * sat(dot(limbN, s) + 0.1) * 0.35;
    if (hit.x > hit.y || hit.x < 0.0) {
        return vec4(haze, 0.0);
    }
    vec3 ps = ros + rds * hit.x;
    hitT = length(ps / sc - ro);
    vec3 n = normalize(ps * sc);
    vec3 nl = normalize(ps);
    float lat = asin(clamp(nl.y, -1.0, 1.0));
    vec2 uv = vec2(atan(nl.x, nl.z) / TAU + 0.5 + jupiterShear(lat, t) + JUP_U0, acos(clamp(nl.y, -1.0, 1.0)) / PI);
    float tpp = pixAngle * hitT / (TAU / 4096.0) / max(dot(n, -rd), 0.15);
    vec3 albedo = regionSampleLod(atlas, R_JUPITER, R_JUPITER_L2, uv, tpp).rgb;
    float swirl = noiseTex(atlas, uv * vec2(8.0, 4.0) + vec2(t * 0.002, 0.0)).g;
    albedo = albedo * albedo * (0.92 + 0.16 * swirl);
    albedo = max(mix(vec3(luma(albedo)), albedo, 1.2), 0.0) * vec3(1.0, 0.96, 0.88);
    float ndl = dot(n, s);
    float mu = max(dot(n, -rd), 0.0);
    float limb = pow(mu, 0.35);
    vec3 col = albedo * smoothstep(-0.08, 0.35, ndl) * max(ndl + 0.08, 0.0) * 1.6 * limb;
    vec3 ioRel = IO_POS;
    vec2 ioShadow = raySphere(ps / sc, s, ioRel, IO_R * 1.25);
    if (ioShadow.x < ioShadow.y && ioShadow.y > 0.0) {
        col *= 0.04;
    }
    vec2 cuv = uv * vec2(90.0, 45.0);
    vec2 cellId = floor(cuv);
    float tick = floor(t * 3.0);
    vec2 spot = vec2(hash12(cellId + tick * 1.7), hash12(cellId.yx + tick * 2.3)) * 0.6 + 0.2;
    float glow = exp(-dot(fract(cuv) - spot, fract(cuv) - spot) * 40.0);
    float flash = step(0.985, hash12(cellId + tick)) * glow * (1.0 - smoothstep(-0.1, 0.05, ndl));
    col += vec3(0.6, 0.7, 1.0) * flash * 0.9;
    col += haze * pow(1.0 - mu, 3.0) * 1.5;
    return vec4(col, 1.0);
}

vec4 io(vec3 ro, vec3 rd, vec3 s, out float hitT) {
    vec2 hit = raySphere(ro, rd, IO_POS, IO_R);
    hitT = 1e30;
    if (hit.x > hit.y || hit.x < 0.0) {
        return vec4(0.0);
    }
    hitT = hit.x;
    vec3 n = normalize(ro + rd * hit.x - IO_POS);
    float v = fbm3(n * 6.0, 4);
    vec3 albedo = mix(vec3(0.85, 0.75, 0.30), vec3(0.55, 0.30, 0.12), smoothstep(0.45, 0.7, v));
    albedo = mix(albedo, vec3(0.15, 0.10, 0.08), smoothstep(0.72, 0.8, v));
    return vec4(albedo * max(dot(n, s), 0.0) * 2.4, 1.0);
}

vec4 ringSample(sampler2D atlas, float r) {
    float u = (r - 1.11) / (2.35 - 1.11);
    if (u < 0.0 || u > 1.0) {
        return vec4(0.0);
    }
    return regionSample(atlas, R_RINGS, vec2(u, 0.5));
}

vec4 saturn(sampler2D atlas, vec3 ro, vec3 rd, vec3 s, float t, float pixAngle, out float hitT) {
    const float OBL = 0.902;
    vec3 sc = vec3(1.0, 1.0 / OBL, 1.0);
    vec3 ros = ro * sc;
    vec3 rds = normalize(rd * sc);
    vec2 hit = raySphere(ros, rds, vec3(0.0), 1.0);
    float tPlanet = 1e30;
    vec4 planet = vec4(0.0);
    if (hit.x < hit.y && hit.x > 0.0) {
        vec3 ps = ros + rds * hit.x;
        vec3 p = ps / sc;
        tPlanet = length(p - ro);
        vec3 n = normalize(ps * sc);
        vec3 nl = normalize(ps);
        float lat = nl.y;
        vec3 band = regionSample(atlas, R_SATURN, vec2(lat * 0.5 + 0.5, 0.5)).rgb;
        float fine = noiseTex(atlas, vec2(atan(nl.x, nl.z) / TAU * 3.0 + t * 0.001, lat * 18.0)).r;
        vec3 albedo = band * band * (0.93 + 0.1 * fine);
        float ndl = dot(n, s);
        float mu = max(dot(n, -rd), 0.0);
        vec3 col = albedo * max(ndl, 0.0) * 2.5 * pow(mu, 0.3);
        float tr = -p.y / s.y;
        if (tr > 0.0) {
            vec3 q = p + s * tr;
            col *= 1.0 - ringSample(atlas, length(q.xz)).a * 0.9;
        }
        col += albedo * vec3(0.9, 0.8, 0.6) * 0.06 * sat(-ndl + 0.3);
        planet = vec4(col, 1.0);
    }
    float tRing = -ro.y / rd.y;
    vec4 ring = vec4(0.0);
    if (tRing > 0.0) {
        vec3 q = ro + rd * tRing;
        float r = length(q.xz);
        vec4 rs = ringSample(atlas, r);
        if (rs.a > 0.0) {
            vec2 sh = raySphere(q * sc, normalize(s * sc), vec3(0.0), 1.0);
            float lit = (sh.x < sh.y && sh.y > 0.0) ? 0.03 : 1.0;
            bool sameSide = sign(ro.y) == sign(s.y);
            float mu0 = abs(s.y);
            float fwd = pow(sat(dot(rd, s)), 6.0);
            float bright = sameSide ? mu0 * 2.2 : (0.08 + 2.0 * fwd) * (1.0 - rs.a) * 1.2;
            float grain = 0.85 + 0.3 * hash12(vec2(floor(r * 2000.0), 1.0));
            ring = vec4(rs.rgb * rs.rgb * bright * lit * grain * 2.0, rs.a);
        }
    }
    bool ringFront = tRing > 0.0 && tRing < tPlanet;
    hitT = min(tPlanet, ring.a > 0.0 ? tRing : 1e30);
    if (ringFront) {
        return vec4(ring.rgb * ring.a + planet.rgb * (1.0 - ring.a), max(ring.a, planet.a));
    }
    return planet.a > 0.0 ? planet : ring;
}

// ------------------------------------------------------------ 항성 -------

float granulationPhase(sampler2D atlas, vec3 n, float scale, float t, float phase) {
    vec3 w = abs(n);
    w = pow(w, vec3(4.0));
    w /= w.x + w.y + w.z;
    vec2 o = vec2(hash11(phase) * 17.3, hash11(phase + 5.1) * 11.9);
    vec3 q = n * scale;
    vec3 flow = 0.18 * vec3(sin(q.y * 0.7 + t * 0.35), sin(q.z * 0.6 + t * 0.29), sin(q.x * 0.8 + t * 0.31));
    q += flow;
    float gx = noiseTex(atlas, q.yz + o).b;
    float gy = noiseTex(atlas, q.zx + o.yx).b;
    float gz = noiseTex(atlas, q.xy - o).b;
    return gx * w.x + gy * w.y + gz * w.z;
}

// 셀이 생겼다 사라지는 끓음: 3초마다 다른 위상으로 넘어간다
float granulation(sampler2D atlas, vec3 n, float scale, float t) {
    float ph = t / 3.0;
    float k = floor(ph);
    float f = smoothstep(0.15, 0.85, fract(ph));
    return mix(granulationPhase(atlas, n, scale, t, k), granulationPhase(atlas, n, scale, t, k + 1.0), f);
}

const vec3 FLARE_N = normalize(vec3(-0.55, 0.45, 0.70));
// 플레어 터지는 태양 장면 시각(초) — 태양 장면 앞쪽에 대사를 끼워 넣으면 같이 민다(build.py MINOR 'flare' = 장면 시작 + 이 값)
const float SUN_FLARE = 86.5;
const vec3 SPOT_N = normalize(vec3(0.35, 0.18, 0.92));

vec4 sun(sampler2D atlas, vec3 ro, vec3 rd, float t, out float hitT) {
    vec2 hit = raySphere(ro, rd, vec3(0.0), 1.0);
    hitT = 1e30;
    float b = length(cross(ro, rd));
    vec3 cdir = normalize(ro + rd * max(-dot(ro, rd), 0.0));
    float streamer = fbm3(cdir * 3.0 + vec3(0.0, t * 0.05, t * 0.02), 4);
    float corona = pow(max(b, 1.0), -4.0) * (0.25 + 1.2 * smoothstep(0.45, 0.78, streamer));
    vec3 glow = vec3(1.0, 0.70, 0.40) * corona * 4.0;
    if (hit.x > hit.y || hit.x < 0.0) {
        float behind = step(dot(ro, rd), 0.0);
        float shell = 0.0;
        for (int i = 0; i < 10; i++) {
            float tt = -dot(ro, rd) + (float(i) - 4.5) * 0.05;
            vec3 p = ro + rd * tt;
            float r = length(p);
            if (r > 1.0 && r < 1.3) {
                vec3 pn = normalize(p);
                float loop = fbm3(pn * 7.0 + vec3(t * 0.08, t * 0.03, 0.0), 4);
                float mask = smoothstep(0.58, 0.75, fbm3(pn * 2.5 + 3.0, 2));
                shell += smoothstep(0.55, 0.70, loop) * mask * exp(-(r - 1.0) * 10.0);
            }
        }
        vec3 prom = vec3(1.0, 0.28, 0.12) * shell * 7.0 * behind;
        float chromo = exp(-max(b - 1.0, 0.0) * 80.0) * behind;
        return vec4(glow * behind + prom + vec3(1.0, 0.32, 0.15) * chromo * 9.0, 0.0);
    }
    hitT = hit.x;
    vec3 n = normalize(ro + rd * hit.x);
    float mu = max(dot(n, -rd), 0.0);
    float limb = 1.0 - 0.6 * (1.0 - mu) - 0.25 * (1.0 - mu) * (1.0 - mu);
    float g = granulation(atlas, n, 22.0, t);
    float cells = smoothstep(0.03, 0.42, g);
    float super = granulation(atlas, n, 4.0, t * 0.3);
    vec3 hotC = vec3(1.0, 0.66, 0.24);
    vec3 coolC = vec3(0.75, 0.24, 0.04);
    vec3 col = mix(coolC, hotC, cells) * 8.0 * limb * (0.85 + 0.3 * super);
    col *= mix(vec3(0.85, 0.55, 0.30), vec3(1.0), pow(mu, 0.5));
    float spotN = fbm3(n * 4.0 + 20.0, 3);
    float band = 1.0 - smoothstep(0.15, 0.45, abs(abs(n.y) - 0.28));
    float pen = smoothstep(0.66, 0.70, spotN) * band;
    float umbra = smoothstep(0.71, 0.74, spotN) * band;
    col *= 1.0 - pen * 0.55 - umbra * 0.4;
    float sd = acos(clamp(dot(n, SPOT_N), -1.0, 1.0));
    float spotEdge = 0.045 * (0.85 + 0.3 * vnoise(n * 40.0));
    col *= 1.0 - 0.55 * smoothstep(spotEdge, spotEdge * 0.6, sd) - 0.35 * smoothstep(spotEdge * 0.45, spotEdge * 0.25, sd);
    col += vec3(1.0, 0.85, 0.6) * smoothstep(0.60, 0.66, spotN) * band * (1.0 - mu) * 2.0;
    float fd = acos(clamp(dot(n, FLARE_N), -1.0, 1.0));
    float flare = exp(-fd * fd / 0.003) * (pulse(t, SUN_FLARE, 0.22) * 1.0 + 0.12);
    col += vec3(1.0, 0.92, 0.8) * flare * 30.0;
    return vec4(col, 1.0);
}

// 질량 방출 껍질: 플레어 순간 그 자리에서 출발해 13초 뒤 카메라를 지남(build.py MAJOR 'cme')
vec3 cmeShell(vec3 ro, vec3 rd, float lt) {
    float age = lt - SUN_FLARE;
    if (age < 0.0 || age > 20.0) {
        return vec3(0.0);
    }
    vec3 origin = FLARE_N * 1.02;
    float radius = 0.05 + age * 0.17;
    vec2 hit = raySphere(ro, rd, origin + FLARE_N * radius * 0.9, radius);
    if (hit.x > hit.y) {
        return vec3(0.0);
    }
    float thick = (hit.y - max(hit.x, 0.0)) / (2.0 * radius);
    float edge = pow(1.0 - sat(thick), 3.0);
    float tex = fbm3(normalize(ro + rd * max(hit.x, 0.0) - origin) * 6.0 + age * 0.3, 4);
    float fade = 1.0 - remap(age, 12.0, 20.0);
    return vec3(1.0, 0.36, 0.10) * edge * edge * edge * (0.2 + 1.0 * tex) * 7.0 * fade;
}

vec4 betelgeuse(sampler2D atlas, vec3 ro, vec3 rd, float t, out float hitT) {
    float R = 1.0 + 0.02 * sin(t * 0.3);
    vec2 hit = raySphere(ro, rd, vec3(0.0), R);
    hitT = 1e30;
    float b = length(cross(ro, rd));
    vec3 cdir = normalize(ro + rd * max(-dot(ro, rd), 0.0));
    float plume = fbm3(cdir * 2.2 + vec3(t * 0.004), 5);
    float envelope = exp(-max(b - R, 0.0) * 1.6) * (0.25 + 1.6 * smoothstep(0.45, 0.8, plume));
    vec3 env = vec3(1.0, 0.28, 0.08) * envelope * 3.5 + vec3(0.6, 0.16, 0.05) * exp(-max(b - R, 0.0) * 0.35) * 0.4;
    float behind = step(dot(ro, rd), 0.0);
    if (hit.x > hit.y || hit.x < 0.0) {
        return vec4(env * behind, 0.0);
    }
    hitT = hit.x;
    vec3 n = normalize(ro + rd * hit.x);
    float mu = max(dot(n, -rd), 0.0);
    float limb = pow(mu, 0.9);
    vec3 q = n * 1.6 + vec3(0.0, t * 0.02, t * 0.015);
    float big = fbm3(q + fbm3(q * 2.0 + 7.0 + vec3(t * 0.05, 0.0, 0.0), 3) * 1.2, 5);
    float cells = smoothstep(0.35, 0.68, big);
    float lanes = 1.0 - smoothstep(0.0, 0.12, abs(big - 0.5));
    vec3 col = mix(vec3(0.55, 0.12, 0.03), vec3(1.0, 0.55, 0.18), cells) * 8.0 * limb * (1.0 - 0.35 * lanes);
    col += env * (1.0 - mu) * 0.5;
    return vec4(col, 1.0);
}

// ------------------------------------------------------------ 펄사 -------

const vec3 PULSAR_SPIN = normalize(vec3(0.25, 1.0, -0.15));
const float PULSAR_TILT = 0.62;
const float PULSAR_HZ = 1.4;
const float PULSAR_R = 0.02;

vec3 pulsarAxis(float t) {
    vec3 e1 = normalize(cross(PULSAR_SPIN, vec3(0.0, 0.0, 1.0)));
    vec3 e2 = cross(PULSAR_SPIN, e1);
    float ph = TAU * PULSAR_HZ * t;
    return normalize(cos(PULSAR_TILT) * PULSAR_SPIN + sin(PULSAR_TILT) * (cos(ph) * e1 + sin(ph) * e2));
}

// 광선과 반직선(원점에서 dir 쪽) 사이 최단 거리와 반직선 위 위치
vec2 rayRayDist(vec3 ro, vec3 rd, vec3 dir) {
    vec3 w = ro;
    float b = dot(rd, dir);
    float d = dot(rd, w);
    float e = dot(dir, w);
    float denom = 1.0 - b * b;
    float sc = denom > 1e-5 ? (b * e - d) / denom : 0.0;
    float tc = denom > 1e-5 ? (e - b * d) / denom : e;
    sc = max(sc, 0.0);
    tc = max(tc, 0.0);
    vec3 diff = (ro + rd * sc) - dir * tc;
    return vec2(length(diff), tc);
}

vec3 pulsar(vec3 ro, vec3 rd, float t, float pixAngle) {
    vec3 m = pulsarAxis(t);
    vec3 col = vec3(0.0);
    for (int k = 0; k < 2; k++) {
        vec3 dir = k == 0 ? m : -m;
        vec2 dd = rayRayDist(ro, rd, dir);
        float w = 0.01 + dd.y * 0.07;
        float core = exp(-dd.x * dd.x / (w * w));
        float fall = exp(-dd.y * 0.12);
        float sparkle = 0.7 + 0.6 * vnoise(vec3(dd.y * 8.0 - t * 30.0, dd.x * 40.0, float(k)));
        col += vec3(0.55, 0.75, 1.0) * core * fall * sparkle * 3.5;
        col += vec3(0.4, 0.5, 1.0) * exp(-dd.x / (w * 3.0)) * fall * 0.25;
    }
    float d = rayPointDist(ro, rd, vec3(0.0));
    float ang = d / max(length(ro), 1e-3);
    float star = PULSAR_R / max(length(ro), 1e-3);
    col += vec3(0.75, 0.85, 1.0) * (exp(-ang * ang / (star * star + pixAngle * pixAngle)) * 60.0 + 0.0008 / (ang * ang + 1e-5) * 0.02);
    float field = 0.0;
    float t0 = max(-dot(ro, rd) - 1.6, 0.0);
    for (int i = 0; i < 20; i++) {
        vec3 p = ro + rd * (t0 + float(i) * 0.16);
        float r = length(p);
        if (r < 0.05 || r > 1.7) {
            continue;
        }
        vec3 pn = p / r;
        float c = dot(pn, m);
        float s2 = max(1.0 - c * c, 1e-3);
        float L = r / s2;
        vec3 perp = normalize(pn - m * c + 1e-5);
        vec3 ref = normalize(cross(m, vec3(0.3, 1.0, 0.1)));
        float phi = atan(dot(perp, cross(m, ref)), dot(perp, ref));
        float shell = exp(-pow(fract(L * 1.6) - 0.5, 2.0) * 180.0);
        float spoke = exp(-pow(fract(phi * 6.0 / TAU) - 0.5, 2.0) * 60.0);
        field += shell * spoke * exp(-r * 1.4) * step(L, 2.6);
    }
    col += vec3(0.35, 0.55, 1.0) * field * 0.06;
    return col;
}

vec3 pulsarNebula(vec3 ro, vec3 rd, float t) {
    vec3 d = rd;
    float body = fbm3(d * 1.7 + 5.0, 5);
    float rid = 1.0 - abs(fbm3(d * 3.4 + 1.3, 5) * 2.0 - 1.0);
    float fil = pow(rid, 7.0) * smoothstep(0.38, 0.62, body);
    float glowRegion = smoothstep(0.35, 0.7, body);
    float core = exp(-pow(rayPointDist(ro, rd, vec3(0.0)) / 2.5, 2.0));
    vec3 col = vec3(1.0, 0.30, 0.12) * fil * 0.22;
    col += vec3(0.9, 0.55, 0.25) * pow(rid, 16.0) * 0.08 * glowRegion;
    col += vec3(0.15, 0.25, 0.65) * glowRegion * 0.035;
    col += vec3(0.35, 0.45, 1.0) * core * 0.14 * (0.6 + 0.4 * body);
    return col;
}

// -------------------------------------------------------------- 블랙홀 ----

const float BH_RS = 2.0;
const float DISK_IN = 6.0;
const float DISK_OUT = 26.0;

vec3 diskPalette(float x) {
    vec3 outer = vec3(0.55, 0.16, 0.04);
    vec3 mid = vec3(1.0, 0.55, 0.18);
    vec3 inner = vec3(1.0, 0.92, 0.80);
    return x < 0.5 ? mix(outer, mid, x * 2.0) : mix(mid, inner, x * 2.0 - 1.0);
}

// near = 카메라가 원반 바로 위를 스칠 때 1(잘게 부서진 덩어리가 빠르게 흘러가 보이게)
vec3 diskEmission(sampler2D atlas, vec3 p, vec3 photonDir, float t, float near) {
    float r = length(p.xz);
    float phi = atan(p.z, p.x);
    float omega = 9.0 * pow(r, -1.5);
    float a = (phi - omega * t) / TAU;
    float lr = log(r);
    float clumps = noiseTex(atlas, vec2(a * 3.0, lr * 2.2)).r;
    float streaks = noiseTex(atlas, vec2(a * 1.0, lr * 9.0)).a;
    float rr = (r - DISK_IN) / (DISK_OUT - DISK_IN);
    float dens = (0.25 + 0.9 * clumps * clumps) * (0.55 + 0.7 * streaks) * smoothstep(0.0, 0.025, rr) * (1.0 - smoothstep(0.45, 1.0, rr));
    if (near > 0.0) {
        float fine = noiseTex(atlas, vec2(a * 24.0, lr * 30.0)).a;
        dens *= mix(1.0, 0.3 + 1.4 * fine * fine, near);
    }
    float heat = pow(max(1.0 - rr, 0.0), 1.6);
    vec3 vel = normalize(vec3(-p.z, 0.0, p.x));
    float beta = clamp(1.0 / sqrt(max(r - 2.0, 0.5)), 0.0, 0.72);
    float gamma = 1.0 / sqrt(1.0 - beta * beta);
    float dop = 1.0 / (gamma * (1.0 - beta * dot(vel, -photonDir)));
    float grav = sqrt(max(1.0 - BH_RS / r, 0.0));
    float g = dop * grav;
    vec3 c = diskPalette(sat(heat * 0.85 + (g - 1.0) * 0.35));
    c = mix(c, vec3(0.75, 0.85, 1.0), sat((g - 1.25) * 0.8));
    return c * pow(g, 4.0) * dens * (0.6 + 3.0 * heat) * 2.2;
}

vec4 blackHole(sampler2D atlas, vec3 ro, vec3 rd, float t, float pixAngle, out vec3 outDir) {
    vec3 p = ro;
    vec3 v = rd;
    vec3 col = vec3(0.0);
    float trans = 1.0;
    float h2 = dot(cross(p, v), cross(p, v));
    outDir = v;
    float bImpact = sqrt(h2);
    if (bImpact > 60.0 && dot(p, v) > 0.0) {
        return vec4(0.0, 0.0, 0.0, 1.0);
    }
    for (int i = 0; i < 180; i++) {
        float r = length(p);
        if (r < BH_RS * 1.001) {
            trans = 0.0;
            break;
        }
        if (r > 140.0 && dot(p, v) > 0.0) {
            break;
        }
        float dl = clamp(0.07 * r, 0.03, 4.0);
        vec3 acc = -1.5 * BH_RS * h2 * p / pow(r, 5.0);
        vec3 pn = p + v * dl + 0.5 * acc * dl * dl;
        float rn = length(pn);
        vec3 accn = -1.5 * BH_RS * h2 * pn / pow(rn, 5.0);
        vec3 vn = normalize(v + 0.5 * (acc + accn) * dl);
        if (p.y * pn.y < 0.0) {
            float f = p.y / (p.y - pn.y);
            vec3 q = mix(p, pn, f);
            float rq = length(q.xz);
            if (rq > DISK_IN && rq < DISK_OUT) {
                float dist = length(q - ro);
                vec3 e = diskEmission(atlas, q, v, t, 1.0 - smoothstep(3.0, 14.0, dist));
                float a = sat(luma(e) * 0.9 + 0.35) * smoothstep(DISK_IN, DISK_IN + 0.6, rq);
                col += e * trans;
                // 가까이서 스칠 땐 원반이 불투명(뒤로 비치는 광자 고리가 금처럼 보이지 않게)
                trans *= 1.0 - mix(a * 0.85, 1.0, 1.0 - smoothstep(4.0, 22.0, dist));
            }
        }
        p = pn;
        v = vn;
        if (trans < 0.02) {
            break;
        }
    }
    outDir = v;
    float jet = 0.0;
    vec2 jd = rayRayDist(ro, rd, vec3(0.0, 1.0, 0.0));
    vec2 jd2 = rayRayDist(ro, rd, vec3(0.0, -1.0, 0.0));
    float jw = 0.8 + jd.y * 0.09;
    jet += exp(-jd.x * jd.x / (jw * jw)) * exp(-jd.y * 0.025) * smoothstep(3.0, 8.0, jd.y);
    jw = 0.8 + jd2.y * 0.09;
    jet += exp(-jd2.x * jd2.x / (jw * jw)) * exp(-jd2.y * 0.025) * smoothstep(3.0, 8.0, jd2.y) * trans;
    col += vec3(0.45, 0.6, 1.0) * jet * 0.06 * (0.8 + 0.4 * vnoise(vec3(jd.y * 0.3 - t * 2.0, 0.0, 0.0)));
    return vec4(col, trans);
}


// ------------------------------------------------------ 블랙홀 내부 ------

// 격자선 위 기둥(세 축) + 칸마다 가끔 판. 공간은 z 를 따라 비틀리고 숨 쉰다
float insideSdf(vec3 p, out float glowId) {
    vec3 g = mod(p + INSIDE_CELL * 0.5, INSIDE_CELL) - INSIDE_CELL * 0.5;
    float rx = length(g.yz) - 0.09;
    float ry = length(g.xz) - 0.09;
    float rz = length(g.xy) - 0.09;
    float d = min(rx, min(ry, rz));
    vec3 cell = floor(p / INSIDE_CELL);
    float h = hash13(cell);
    float panel = h > 0.82 ? abs(g.x) - 0.04 : 1e3;
    panel = max(panel, max(abs(g.y), abs(g.z)) - INSIDE_CELL * 0.42);
    glowId = h;
    return min(d, panel);
}

vec3 insideSpace(vec3 ro, vec3 rd, float t, float lt) {
    vec3 col = vec3(0.0);
    float tt = 0.2;
    float glowId = 0.0;
    vec3 sphere = INSIDE_SPHERE;
    float sphereR = 26.0;
    vec2 sh = raySphere(ro, rd, sphere, sphereR);
    if (sh.x < 0.0 && sh.y > 0.0) {
        return vec3(0.0);
    }
    float sphereT = sh.x < sh.y && sh.x > 0.0 ? sh.x : 1e30;
    float open = smoothstep(48.0, 58.0, lt);
    for (int i = 0; i < 72; i++) {
        vec3 p = ro + rd * tt;
        float d = insideSdf(p, glowId);
        float fade = exp(-tt * 0.03) * (1.0 - open * smoothstep(sphereR + 30.0, sphereR, length(p - sphere)));
        float flow = 0.5 + 0.5 * sin(dot(p, vec3(0.13, 0.17, 0.21)) * 2.0 - t * 6.0);
        vec3 hue = mix(vec3(1.0, 0.62, 0.25), vec3(0.35, 0.8, 1.0), step(0.6, fract(glowId * 7.0)));
        col += hue * exp(-max(d, 0.0) * 9.0) * 0.03 * (0.4 + 1.2 * flow * flow) * fade;
        if (d < 0.02) {
            col += hue * (0.25 + 1.6 * pow(flow, 4.0)) * fade * 0.35;
            break;
        }
        tt += max(d * 0.85, 0.05);
        if (tt > 160.0 || tt > sphereT) {
            break;
        }
    }
    float rim = sh.x < sh.y ? 0.0 : exp(-max(length(cross(sphere - ro, rd)) - sphereR, 0.0) * 0.35);
    col *= sphereT < 1e29 ? 0.0 : 1.0;
    col += vec3(1.0, 0.85, 0.6) * rim * open * 1.5;
    col += vec3(0.05, 0.035, 0.02) * (1.0 - open);
    return col;
}

// ------------------------------------------------- 소행성·얼음 알갱이 층 ---

// 가상 z 축에 수직인 판 여러 장에 바위를 흩뿌린다(카메라는 -z 로 전진)
vec4 rockLayers(vec3 ro, vec3 rd, vec3 s, float spacing, float cell, float density, float rMin, float rMax, vec3 tint, float icy, float sheetHalf, float pixAngle, out float hitT) {
    hitT = 1e30;
    if (abs(rd.z) < 1e-3) {
        return vec4(0.0);
    }
    float dir = sign(rd.z);
    float k0 = dir < 0.0 ? floor(ro.z / spacing) : ceil(ro.z / spacing);
    for (int i = 0; i < 22; i++) {
        float k = k0 + dir * float(i);
        float tz = (k * spacing - ro.z) / rd.z;
        if (tz <= 0.0) {
            continue;
        }
        vec3 pz = ro + rd * tz;
        vec2 c = floor(pz.xy / cell);
        vec3 h = hash33(vec3(c, k));
        float layerDensity = sheetHalf > 0.0 ? density * exp(-pow(k * spacing / sheetHalf, 2.0)) : density;
        if (h.x > layerDensity) {
            continue;
        }
        float rad = mix(rMin, rMax, h.y * h.y * h.y) * cell * 0.4;
        vec3 center = vec3((c + 0.5 + (h.zx - 0.5) * 0.3) * cell, k * spacing);
        vec2 hit = raySphere(ro, rd, center, rad * 1.15);
        if (hit.x > hit.y || hit.x <= 0.0) {
            continue;
        }
        vec3 toC = center - ro;
        float along = dot(toC, rd);
        vec3 closest = ro + rd * along - center;
        float dc = length(closest);
        vec3 cn = normalize(closest + 1e-5);
        float edge = rad * (0.78 + 0.32 * vnoise(cn * 2.5 + h * 10.0));
        if (dc > edge) {
            continue;
        }
        float depth = sqrt(max(edge * edge - dc * dc, 0.0));
        vec3 p = ro + rd * (along - depth);
        vec3 n = normalize(p - center);
        float bump = fbm3(n * 4.0 + h * 7.0, 3);
        n = normalize(n + (vec3(vnoise(n * 6.0 + 1.0), vnoise(n * 6.0 + 2.0), vnoise(n * 6.0 + 3.0)) - 0.5) * 0.9);
        vec3 albedo = mix(vec3(0.07, 0.065, 0.06), vec3(0.17, 0.155, 0.14), bump) * mix(vec3(1.0), tint, h.z);
        albedo = mix(albedo, vec3(0.75, 0.82, 0.9), icy);
        float ndl = max(dot(n, s), 0.0);
        float spec = icy * pow(max(dot(reflect(-s, n), -rd), 0.0), 24.0) * 2.0;
        vec3 col = albedo * (ndl * 2.6 + 0.015) + spec;
        float size = rad / max(tz, 1e-3);
        float fade = smoothstep(pixAngle * 0.6, pixAngle * 2.5, size);
        hitT = tz;
        return vec4(col, fade);
    }
    return vec4(0.0);
}

// 거대 소행성(울퉁불퉁한 구를 거리장으로 따라감)
const vec3 BIG_ROCK_POS = vec3(-62.0, 12.0, -1104.0);
const float BIG_ROCK_R = 34.0;

float bigRockSdf(vec3 p, vec3 c, float r) {
    vec3 q = p - c;
    vec3 n = normalize(q);
    float disp = 0.20 * fbm3(n * 2.2, 4) + 0.06 * fbm3(n * 9.0, 3) - 0.12;
    return length(q * vec3(1.0, 0.8, 1.3)) - r * (1.0 + disp);
}

vec4 bigAsteroid(vec3 ro, vec3 rd, vec3 s, vec3 c, float r, float t, out float hitT) {
    hitT = 1e30;
    vec2 b = raySphere(ro, rd, c, r * 1.6);
    if (b.x > b.y || b.y < 0.0) {
        return vec4(0.0);
    }
    float tt = max(b.x, 0.0);
    bool hit = false;
    for (int i = 0; i < 48; i++) {
        float d = bigRockSdf(ro + rd * tt, c, r);
        if (d < 0.02 * tt * 0.01 + 0.03) {
            hit = true;
            break;
        }
        tt += d * 0.8;
        if (tt > b.y) {
            break;
        }
    }
    if (!hit) {
        return vec4(0.0);
    }
    vec3 p = ro + rd * tt;
    const vec2 e = vec2(0.25, -0.25);
    vec3 n = normalize(e.xyy * bigRockSdf(p + e.xyy, c, r) + e.yyx * bigRockSdf(p + e.yyx, c, r) + e.yxy * bigRockSdf(p + e.yxy, c, r) + e.xxx * bigRockSdf(p + e.xxx, c, r));
    vec3 ln = normalize(p - c);
    float crater = smoothstep(0.55, 0.8, vnoise(ln * 5.0));
    vec3 albedo = mix(vec3(0.11, 0.10, 0.09), vec3(0.21, 0.19, 0.17), fbm3(ln * 14.0, 3)) * (1.0 - crater * 0.35);
    float ndl = max(dot(n, s), 0.0);
    hitT = tt;
    return vec4(albedo * (ndl * 2.8 + 0.01), 1.0);
}

// 가까운 우주 먼지: 진행 방향 반대로 흐르는 가는 줄
vec3 spaceDust(vec3 ro, vec3 rd, vec3 vel, float pixAngle) {
    vec3 col = vec3(0.0);
    float speed = length(vel);
    if (speed < 1e-3) {
        return col;
    }
    for (int i = 1; i <= 6; i++) {
        float dist = float(i) * 3.0;
        vec3 p = ro + rd * dist;
        vec3 cell = floor(p / 2.5);
        vec3 h = hash33(cell);
        vec3 dp = (cell + h) * 2.5;
        float d = rayPointDist(ro, rd, dp);
        float streak = exp(-d * d / (0.0004 + pixAngle * pixAngle * dist * dist));
        col += vec3(0.6, 0.7, 0.8) * streak * step(0.7, h.x) * 0.25 / float(i);
    }
    return col * sat(speed * 0.05);
}

#endif
