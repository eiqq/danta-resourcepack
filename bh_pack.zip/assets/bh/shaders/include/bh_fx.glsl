#ifndef BH_FX_GLSL
#define BH_FX_GLSL

// 우주선 손상 효과(바닐라 파티클 대신): 하늘 셰이더가 지점을 화면에 투영해 데이터 칸에 쓰고, 후처리가 그린다.
// 지점 = show/ship_layout.json points(무대 원점 기준 블록), 우주선 기동 자세를 따라간다.
const int FX_SLOTS = 6;
const int FX_DATA_BASE = 8;

const vec3 P_NOSE = vec3(0.0, 0.05, -5.15);
const vec3 P_COCKPIT = vec3(0.0, 0.85, -3.0);
const vec3 P_WING_L = vec3(-3.1, -0.2, 2.1);
const vec3 P_WING_R = vec3(3.1, -0.2, 2.1);
const vec3 P_ANTENNA = vec3(0.35, 1.3, 0.92);
const vec3 P_ENGINE_L = vec3(-1.55, 0.12, 5.15);
const vec3 P_DORSAL = vec3(0.0, 0.98, 0.0);

const float BLAST_T[6] = float[](235.6, 248.6, 258.6, 550.9, 709.1, 847.1);
const float BLAST_POWER[6] = float[](0.6, 1.0, 0.5, 0.7, 1.0, 1.4);
const float BLAST_LEN = 1.8;

vec3 blastPoint(int i) {
    if (i == 0) {
        return P_WING_L;
    }
    if (i == 1) {
        return P_NOSE;
    }
    if (i == 2) {
        return P_WING_R;
    }
    if (i == 3) {
        return P_ENGINE_L;
    }
    if (i == 4) {
        return P_COCKPIT;
    }
    return P_DORSAL;
}

// 칸 0 = 가장 최근 폭발, 1~5 = 손상 지점 불꽃·가스(시작 이후 계속)
// 돌려줌: 지점(무대 기준), x = 세기, y = 나이(초), z = 종류(0 폭발, 1 불꽃+가스)
vec3 fxSlot(int slot, float t, out vec3 point) {
    point = vec3(0.0);
    if (t >= 900.8 || t < 0.0) {
        return vec3(0.0);
    }
    if (slot == 0) {
        for (int i = 5; i >= 0; i--) {
            float age = t - BLAST_T[i];
            if (age >= 0.0 && age < BLAST_LEN) {
                point = blastPoint(i);
                return vec3(BLAST_POWER[i], age, 0.0);
            }
        }
        return vec3(0.0);
    }
    vec3 starts = vec3(0.0);
    float begin = 1e9;
    float end = 900.8;
    if (slot == 1) {
        point = P_NOSE;
        begin = 249.0;
    } else if (slot == 2) {
        point = P_ANTENNA;
        begin = 1e9;   // 토성(고리 얼음에 안테나 손상) 장면을 뺐다
    } else if (slot == 3) {
        point = P_ENGINE_L;
        begin = 551.4;
    } else if (slot == 4) {
        point = P_COCKPIT;
        begin = 709.5;
    } else {
        point = P_WING_R;
        begin = 258.9;
        end = 299.6;   // 날개 불: 스친 뒤(234.8+24.1) 약 41초
    }
    if (t < begin || t > end) {
        return vec3(0.0);
    }
    float fade = remap(t, begin, begin + 0.5) * (1.0 - remap(t, end - 2.0, end));
    return vec3(fade, t - begin, 1.0);
}

#endif
