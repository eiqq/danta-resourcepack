#ifndef BH_TIMELINE_GLSL
#define BH_TIMELINE_GLSL

// 상영 시계 = 월드 gameTime(서버가 상영 시작 때 0 으로). 초 단위.
// 장면·사건 시각은 SPEC.md 2·3장과 같아야 한다. 낚시 조각·허탕 카운트다운 시각은 tools/audio/build.py 가 만든 bh_bits_data.

#include <bh:bh_bits_data.glsl>

const int S_IDLE = 0;
const int S_EARTH = 1;
const int S_MARS = 2;
const int S_BELT = 3;
const int S_JUPITER = 4;
const int S_SATURN = 5;
const int S_SUN = 6;
const int S_BETEL = 7;
const int S_PULSAR = 8;
const int S_BH = 9;
const int S_INSIDE = 10;
const int S_END = 11;

const float T_IDLE = 1060.0;
const float SCENE_START[12] = float[](1060.0, 0.0, 130.0, 197.6, 351.8, 447.7, 447.7, 568.2, 638.2, 728.2, 891.9, 957.9);
const float SCENE_END[12] = float[](1200.0, 130.0, 197.6, 351.8, 447.7, 447.7, 568.2, 638.2, 728.2, 891.9, 957.9, 1060.0);

float showTime(float gameTime) {
    return gameTime * 1200.0;
}

int sceneAt(float t) {
    if (t >= T_IDLE) {
        return S_IDLE;
    }
    int s = S_EARTH;
    for (int i = S_MARS; i <= S_END; i++) {
        if (t >= SCENE_START[i]) {
            s = i;
        }
    }
    return s;
}

float pulse(float t, float t0, float decay) {
    return t < t0 ? 0.0 : exp(-(t - t0) * decay);
}

float warpOut(float t) {
    float w = 0.0;
    for (int i = S_MARS; i <= S_BH; i++) {
        float b = SCENE_START[i];
        w = max(w, remap(t, b - 6.0, b) * step(t, b));
    }
    return w * w;
}

float warpIn(float t) {
    float w = 0.0;
    for (int i = S_MARS; i <= S_BH; i++) {
        float b = SCENE_START[i];
        w = max(w, (1.0 - remap(t, b, b + 1.2)) * step(b, t));
    }
    return w * w;
}

float warpFlash(float t) {
    float f = 0.0;
    for (int i = S_MARS; i <= S_BH; i++) {
        float d = (t - SCENE_START[i]) / 0.45;
        f = max(f, exp(-d * d));
    }
    return f;
}

float impactFlash(float t) {
    return 0.45 * pulse(t, 248.6, 6.0) + 0.3 * pulse(t, 542.0, 3.0) + 1.2 * pulse(t, 700.2, 1.6) + 0.5 * pulse(t, 838.2, 3.0);
}

// 허탕 카운트다운(n044): 5·4·3·2·1 동안 흔들림·경보가 커지다 침묵(611.38~613.18)에서 뚝 멈춘다
float fakeout(float t) {
    return remap(t, FAKEOUT_T0, FAKEOUT_T1) * step(t, FAKEOUT_T1);
}

float shakeAmount(float t) {
    float s = 0.35 * pulse(t, 235.6, 3.0) + 1.0 * pulse(t, 248.6, 1.8) + 0.5 * pulse(t, 258.6, 3.0)
            + 0.8 * pulse(t, 542.0, 1.2) + 1.0 * pulse(t, 700.2, 1.5) + 1.0 * pulse(t, 838.2, 1.0);
    s += 0.35 * window(t, 542.0, 552.0, 0.5, 2.0);
    s += 0.6 * remap(t, 778.2, 889.9) * step(t, 891.9);
    s += 0.14 * window(t, 895.9, 953.9, 2.0, 1.0) + 0.5 * window(t, 947.9, 954.9, 5.0, 0.5);
    s += 0.12 * max(warpOut(t), warpIn(t));
    s += 0.55 * pow(fakeout(t), 1.6);
    return s;
}

float alarmOn(float t) {
    float a = max(window(t, 248.6, 263.6, 0.1, 1.0), max(window(t, 542.0, 556.0, 0.1, 1.0), window(t, 778.2, 891.9, 0.5, 0.5)));
    return max(a, step(0.001, fakeout(t)));
}

// 1 = 정상, 0 = 꺼짐. 622 이후 비상 전원
float powerLevel(float t) {
    float p = 1.0;
    p -= window(t, 542.0, 552.0, 0.1, 1.0) * step(0.55, hash11(floor(t * 14.0)));
    p = t >= 700.2 && t < 891.9 ? 0.0 : p;
    return sat(p);
}

float emergencyOn(float t) {
    return step(700.2, t) * step(t, 891.9);
}

float glitchAmount(float t) {
    float g = window(t, 542.0, 552.0, 0.2, 2.0) * (0.4 + 0.6 * step(0.6, hash11(floor(t * 9.0))));
    g += pulse(t, 700.2, 2.5);
    g += window(t, 838.2, 891.9, 1.0, 0.5) * step(0.7, hash11(floor(t * 6.0)));
    return sat(g);
}

// 검정으로 덮는 양(1 = 완전 검정)
float blackout(float t) {
    if (t >= T_IDLE) {
        return 0.0;
    }
    float b = 1.0 - remap(t, 3.0, 10.0);
    b = max(b, remap(t, 887.9, 891.9) * (1.0 - remap(t, 892.9, 896.4)));
    return max(b, remap(t, 952.9, 957.4));
}

float engineLevel(float t) {
    float e = 1.0 + 1.6 * max(warpOut(t), warpIn(t));
    e = t >= 700.2 ? e * (0.6 + 0.4 * step(0.25, hash11(floor(t * 8.0)))) : e;
    e = t >= 778.2 ? 2.2 : e;
    e = t >= 838.2 ? 0.0 : e;
    e = t >= 891.9 ? 1.4 + 0.3 * sin(t * 2.3) : e;
    return e;
}

vec3 bez3(vec3 a, vec3 b, vec3 c, vec3 d, float s) {
    float u = 1.0 - s;
    return u * u * u * a + 3.0 * u * u * s * b + 3.0 * u * s * s * c + s * s * s * d;
}

struct Rig {
    int scene;
    float t;
    float lt;
    vec3 pos;
    mat3 basis;
    vec3 sunDir;
    float zoom;
};

// 장면 2~8 은 워프 직후 7.5초 도입 샷: 천체 가까이 빠르게 돌다 줌아웃하며 우주선 뒤 시점으로 돌아온다.
// 우주선은 6초까지 숨었다가 뒤에서 날아들어 7.5초에 자리 잡는다(아이템 셰이더).
const float INTRO_LEN = 7.5;
const float SHIP_FLYIN = 6.0;
const float BH_INTRO_LEN = 16.0;

float introLen(int scene) {
    return scene == S_BH ? BH_INTRO_LEN : INTRO_LEN;
}

bool hasIntro(int scene) {
    return scene >= S_MARS && scene <= S_BH;
}

// --- 장면별 카메라 ---------------------------------------------------------

const float EARTH_R_ORBIT = 1.07;
const float EARTH_OMEGA = 0.020;

vec3 earthOrbit(float t) {
    float th = EARTH_OMEGA * t;
    return EARTH_R_ORBIT * vec3(sin(th), cos(th), 0.0);
}

vec3 earthSunDir() {
    return normalize(vec3(cos(0.862), -sin(0.862), 0.30));
}

// 55초부터 지구를 바라본 채 해 쪽으로 물러나며 상승, 달이 앞을 스쳐 지나간다
vec3 earthUp55() {
    return normalize(earthOrbit(55.0));
}

vec3 earthSide() {
    return normalize(cross(earthSunDir(), earthUp55()));
}

const float MOON_R = 0.273;
#define MOON_POS (earthUp55() * 2.05 + earthSunDir() * 3.1 + earthSide() * 0.62)

vec3 earthDepart(float lt) {
    float k = smoother01(remap(lt, 55.0, 124.0));
    float d = 7.0 * k * k * (1.6 - 0.6 * k);
    float r = mix(1.07, 2.5, smoother01(remap(lt, 55.0, 100.0)));
    return earthUp55() * r + earthSunDir() * d;
}

void rigEarth(float lt, inout Rig rig) {
    vec3 pos = lt < 55.0 ? earthOrbit(lt) : earthDepart(lt);
    float th = EARTH_OMEGA * min(lt, 55.0);
    vec3 orbitFwd = normalize(vec3(cos(th), -sin(th), 0.0) - 0.20 * normalize(earthOrbit(lt)));
    vec3 toEarth = normalize(-pos);
    vec3 toMoon = normalize(MOON_POS - pos);
    toEarth = normalize(mix(toEarth, toMoon, 0.55 * window(lt, 80.0, 104.0, 8.0, 8.0)));
    vec3 deep = normalize(earthSide() * 0.8 + earthSunDir() * 0.6 + earthUp55() * 0.3);
    vec3 fwd = normalize(mix(orbitFwd, toEarth, smoother01(remap(lt, 56.0, 72.0))));
    fwd = normalize(mix(fwd, deep, smoother01(remap(lt, 108.0, 122.0))));
    vec3 upHint = normalize(mix(normalize(pos), earthUp55(), smoother01(remap(lt, 55.0, 70.0))));
    upHint = normalize(upHint - fwd * dot(upHint, fwd) + 1e-4);
    rig.pos = pos;
    rig.basis = basisFrom(fwd, upHint);
    rig.sunDir = earthSunDir();
}

// 화성: 반지름 1, 원점. 낮 쪽에서 비스듬히 다가가며 천천히 돌고, 화성은 화면 왼쪽에(오른쪽 패널 자리 비움)
const vec3 MARS_SUN = normalize(vec3(-0.3, 0.3, 0.9));
void rigMars(float lt, inout Rig rig) {
    float s = smoother01(lt / 67.6);
    float a = mix(0.35, 0.95, s);
    float r = mix(3.4, 2.6, s);
    vec3 pos = vec3(r * sin(a), 0.35 - 0.15 * s, r * cos(a));
    vec3 toMars = normalize(-pos);
    vec3 side = normalize(cross(toMars, vec3(0.0, 1.0, 0.0)));
    rig.pos = pos;
    rig.basis = basisFrom(normalize(toMars + side * 0.45), vec3(0.0, 1.0, 0.0));
    rig.sunDir = MARS_SUN;
}

// 소행성대: 가상 z 축을 따라 전진(초당 28)
const vec3 BELT_SUN = normalize(vec3(-0.55, 0.25, 0.80));
void rigBelt(float lt, inout Rig rig) {
    float la = min(lt, 80.0);
    float z = -28.0 * lt - 4.0 * la * la / 80.0 - 8.0 * max(lt - 80.0, 0.0);
    vec3 pos = vec3(6.0 * sin(lt * 0.05), 3.0 * sin(lt * 0.031), z);
    vec3 fwd = normalize(vec3(0.20 * cos(lt * 0.05), 0.08 * cos(lt * 0.031), -1.0));
    float roll = 0.12 * sin(lt * 0.07);
    rig.pos = pos;
    rig.basis = basisFrom(fwd, normalize(vec3(sin(roll), cos(roll), 0.0)));
    rig.sunDir = BELT_SUN;
}

// 목성: 반지름 1, 중심 원점
const vec3 JUP_SUN = normalize(vec3(1.0, 0.18, 0.35));
const vec3 IO_POS = vec3(2.3, 0.25, 1.4);
const float IO_R = 0.026;
void rigJupiter(float lt, inout Rig rig) {
    float s = smoother01(lt / 90.0) + 0.002 * max(lt - 84.0, 0.0);
    vec3 pos = bez3(vec3(-2.2, 0.2, 4.6), vec3(-0.6, -0.4, 3.4), vec3(1.0, -0.5, 2.3), vec3(1.25, -0.1, 0.75), s);
    vec3 look = mix(vec3(0.0, -0.2, 0.0), vec3(-0.3, -0.25, -0.5), smoother01(remap(lt, 44.0, 88.0)));
    vec3 fwd = normalize(look - pos);
    rig.pos = pos;
    rig.basis = basisFrom(fwd, normalize(vec3(0.15, 1.0, 0.0)));
    rig.sunDir = JUP_SUN;
}

// 토성: 반지름 1, 고리 평면 = y 0. 352~366 고리면 통과
const vec3 SAT_SUN = normalize(vec3(-0.75, 0.32, 0.55));
void rigSaturn(float lt0, inout Rig rig) {
    // 대사를 줄여 고리 통과(원래 장면 60초)를 49초로 앞당김 → 경로 전체를 같은 비율로 압축
    float lt = lt0 * (60.0 / 49.0);
    float a = mix(-0.9, 0.55, smoother01(lt / 90.0));
    float r = mix(5.0, 2.45, smoother01(lt / 70.0));
    float y = mix(1.1, 0.30, smoother01(lt / 52.0));
    y = mix(y, -0.55, smoother01(remap(lt, 50.0, 70.0)));
    vec3 pos = vec3(r * sin(a), y, r * cos(a));
    vec3 look = vec3(0.0, mix(0.0, 0.2, smoother01(remap(lt, 55.0, 80.0))), 0.0);
    vec3 fwd = normalize(normalize(look - pos) + vec3(0.0, 0.0, 0.0));
    fwd = normalize(mix(fwd, normalize(vec3(-cos(a), 0.05, sin(a))), 0.35 * window(lt, 46.0, 70.0, 4.0, 4.0)));
    rig.pos = pos;
    rig.basis = basisFrom(fwd, vec3(0.0, 1.0, 0.0));
    rig.sunDir = SAT_SUN;
}

// 태양: 반지름 1
const vec3 SUN_VIEW_DIR = normalize(vec3(0.0, 0.0, -1.0));
void rigSun(float lt, inout Rig rig) {
    float s = smoother01(lt / 105.0) + 0.0012 * max(lt - 98.0, 0.0);
    vec3 pos = bez3(vec3(-0.9, 0.7, 3.8), vec3(-0.3, 0.5, 2.9), vec3(0.6, 0.35, 2.2), vec3(1.2, 0.2, 1.6), s);
    vec3 look = mix(vec3(0.0), vec3(-0.85, 0.35, 0.0), smoother01(remap(lt, 30.0, 70.0)));
    rig.pos = pos;
    rig.basis = basisFrom(normalize(look - pos), vec3(0.0, 1.0, 0.0));
    rig.sunDir = normalize(-pos);
}

// 베텔게우스: 반지름 1
void rigBetel(float lt, inout Rig rig) {
    float s = smoother01(lt / 70.0);
    vec3 pos = bez3(vec3(1.5, 0.5, 4.2), vec3(0.7, 0.4, 3.6), vec3(-0.5, 0.25, 3.0), vec3(-1.2, 0.12, 2.5), s);
    rig.pos = pos;
    rig.basis = basisFrom(normalize(vec3(0.25, 0.0, 0.0) - pos), vec3(0.0, 1.0, 0.0));
    rig.sunDir = normalize(-pos);
}

// 펄사: 중성자별 반지름 0.02, 원점
void rigPulsar(float lt, inout Rig rig) {
    float a = 0.6 + lt * 0.006;
    float r = mix(7.0, 2.4, smoother01(lt / 60.0));
    vec3 pos = vec3(r * sin(a), 0.8 - lt * 0.004, r * cos(a));
    rig.pos = pos;
    rig.basis = basisFrom(normalize(vec3(0.12, 0.0, 0.0) - pos), vec3(0.0, 1.0, 0.0));
    rig.sunDir = normalize(-pos);
}

// 블랙홀: 질량 1(슈바르츠실트 반지름 2), 원반 평면 y 0
float bhRadius(float lt) {
    float r = mix(110.0, 34.0, smoother01(lt / 50.0));
    r = mix(r, 13.0, smoother01(remap(lt, 50.0, 110.0)));
    r = mix(r, 2.6, smoother01(remap(lt, 110.0, 181.5)));
    return r;
}

void rigBlackHole(float lt, inout Rig rig) {
    float r = bhRadius(lt);
    float a = 0.4 + lt * 0.010 + 0.8 * smoother01(remap(lt, 90.0, 181.5));
    float elev = mix(0.16, 0.08, smoother01(lt / 120.0));
    vec3 pos = r * vec3(sin(a) * cos(elev), sin(elev), cos(a) * cos(elev));
    vec3 fwd = normalize(-pos + vec3(0.0, -0.02 * r, 0.0));
    float roll = 0.15 * sin(lt * 0.05) + 0.4 * smoother01(remap(lt, 100.0, 183.5));
    vec3 up = normalize(vec3(sin(roll), cos(roll), 0.0));
    rig.pos = pos;
    rig.basis = basisFrom(fwd, up);
    rig.sunDir = normalize(-pos);
}

// 블랙홀 내부: 격자 간격 INSIDE_CELL, 기둥은 격자선 위. 카메라는 칸 가운데를 잇는 경로(tools/paths)를 따라 꺾으며 난다
const float INSIDE_CELL = 8.0;

#include <bh:bh_inside_path.glsl>

void insidePath(float lt, out vec3 pos, out vec3 fwd, out vec3 up, out float roll) {
    int lo = 0;
    int hi = INSIDE_N - 2;
    for (int k = 0; k < 9; k++) {
        int mid = (lo + hi + 1) / 2;
        if (INSIDE_WP[mid].w <= lt) {
            lo = mid;
        } else {
            hi = mid - 1;
        }
    }
    int i = clamp(lo, 0, INSIDE_N - 2);
    vec3 p0 = INSIDE_WP[max(i - 1, 0)].xyz;
    vec3 p1 = INSIDE_WP[i].xyz;
    vec3 p2 = INSIDE_WP[i + 1].xyz;
    vec3 p3 = INSIDE_WP[min(i + 2, INSIDE_N - 1)].xyz;
    float span = INSIDE_WP[i + 1].w - INSIDE_WP[i].w;
    float over = max(lt - INSIDE_WP[INSIDE_N - 1].w, 0.0);
    float u = clamp((lt - INSIDE_WP[i].w) / span, 0.0, 1.0);
    vec3 a = -p0 + p2;
    vec3 b = 2.0 * p0 - 5.0 * p1 + 4.0 * p2 - p3;
    vec3 c = -p0 + 3.0 * p1 - 3.0 * p2 + p3;
    pos = 0.5 * (2.0 * p1 + a * u + b * u * u + c * u * u * u);
    fwd = normalize(0.5 * (a + 2.0 * b * u + 3.0 * c * u * u));
    pos += fwd * over * 11.0;
    up = normalize(mix(INSIDE_UP[i].xyz, INSIDE_UP[i + 1].xyz, u));
    roll = mix(INSIDE_UP[i].w, INSIDE_UP[i + 1].w, u);
}

void rigInside(float lt, inout Rig rig) {
    vec3 pos;
    vec3 fwd;
    vec3 up;
    float roll;
    insidePath(lt, pos, fwd, up, roll);
    rig.pos = pos;
    rig.basis = basisFrom(fwd, rotAxis(fwd, roll) * up);
    rig.sunDir = normalize(vec3(0.3, 0.8, -0.4));
}

void rigIdle(float lt, inout Rig rig) {
    rig.pos = vec3(0.0);
    rig.basis = basisFrom(normalize(vec3(sin(lt * 0.004), 0.05, -1.0)), vec3(0.0, 1.0, 0.0));
    rig.sunDir = normalize(vec3(0.3, 0.9, 0.25));   // 로비(한낮 야외): 해는 위에서
}

// 도입 샷 궤도: (반지름, 높이, 시작 각, 끝 각)
vec4 introOrbit(int scene) {
    if (scene == S_MARS) {
        return vec4(1.9, 0.22, -0.9, 0.35);
    }
    if (scene == S_JUPITER) {
        return vec4(1.45, 0.25, 1.4, -0.3);
    }
    if (scene == S_SATURN) {
        return vec4(2.6, 0.45, -2.2, -0.6);
    }
    if (scene == S_SUN) {
        return vec4(1.35, 0.2, 2.2, 0.8);
    }
    if (scene == S_BETEL) {
        return vec4(1.6, 0.3, -0.4, 1.2);
    }
    if (scene == S_PULSAR) {
        return vec4(0.9, 0.25, 0.0, 1.8);
    }
    return vec4(18.0, 2.2, 2.3, 5.6);
}

void applyIntro(inout Rig rig) {
    float lt = rig.lt;
    float len = introLen(rig.scene);
    float s = sat(lt / len);
    float e = smoother01(remap(lt, len - 4.0, len));
    vec3 pos;
    vec3 fwd;
    vec3 up = vec3(0.0, 1.0, 0.0);
    if (rig.scene == S_BH) {
        // 위에서 내려다보다 원반 바로 위로 내려와 스치듯 돌고(원반 흐름과 반대 방향), 본 경로와 같은 방향에서 끝난다(이후엔 뒤로 물러나기만)
        float aEnd = atan(rig.pos.x, rig.pos.z) + TAU;
        float a = mix(aEnd - 4.5, aEnd, smoother01(s));
        float dive = smoother01(min(s * 2.6, 1.0));
        float el = mix(0.72, 0.028, dive);
        float r = mix(26.0, 18.0, dive);
        pos = r * vec3(sin(a) * cos(el), sin(el), cos(a) * cos(el));
        fwd = normalize(-pos + vec3(cos(a), 0.0, -sin(a)) * mix(4.0, 8.0, dive) - vec3(0.0, 1.6 * dive, 0.0));
    } else if (rig.scene == S_BELT) {
        pos = rig.pos + vec3(0.0, 6.0 * (1.0 - s), 190.0 * (1.0 - s) * (1.0 - s));
        fwd = rig.basis * vec3(0.0, 0.0, -1.0);
        float roll = TAU * (1.0 - smoother01(s));
        up = rotAxis(fwd, roll) * (rig.basis * vec3(0.0, 1.0, 0.0));
    } else {
        vec4 o = introOrbit(rig.scene);
        float a = mix(o.z, o.w, rig.scene == S_BH ? smoother01(s) : 1.0 - (1.0 - s) * (1.0 - s));
        pos = vec3(o.x * sin(a), o.y, o.x * cos(a));
        vec3 lead = vec3(cos(a), 0.0, -sin(a)) * sign(o.w - o.z) * o.x * 0.35;
        fwd = normalize(lead - pos);
    }
    vec3 nf = rig.basis * vec3(0.0, 0.0, -1.0);
    vec3 nu = rig.basis * vec3(0.0, 1.0, 0.0);
    rig.pos = mix(pos, rig.pos, e);
    rig.basis = basisFrom(normalize(mix(fwd, nf, e)), normalize(mix(up, nu, e)));
    rig.zoom = mix(rig.scene == S_BH ? 0.85 : 1.25, 1.0, smoother01(remap(lt, len - 5.0, len)));
}

Rig rigAt(float t) {
    Rig rig;
    rig.t = t;
    rig.scene = sceneAt(t);
    rig.lt = t - SCENE_START[rig.scene];
    rig.pos = vec3(0.0);
    rig.basis = mat3(1.0);
    rig.sunDir = vec3(0.0, 1.0, 0.0);
    rig.zoom = 1.0;
    if (rig.scene == S_EARTH) {
        rigEarth(rig.lt, rig);
    } else if (rig.scene == S_MARS) {
        rigMars(rig.lt, rig);
    } else if (rig.scene == S_BELT) {
        rigBelt(rig.lt, rig);
    } else if (rig.scene == S_JUPITER) {
        rigJupiter(rig.lt, rig);
    } else if (rig.scene == S_SATURN) {
        rigSaturn(rig.lt, rig);
    } else if (rig.scene == S_SUN) {
        rigSun(rig.lt, rig);
    } else if (rig.scene == S_BETEL) {
        rigBetel(rig.lt, rig);
    } else if (rig.scene == S_PULSAR) {
        rigPulsar(rig.lt, rig);
    } else if (rig.scene == S_BH) {
        rigBlackHole(rig.lt, rig);
    } else if (rig.scene == S_INSIDE) {
        rigInside(rig.lt, rig);
    } else {
        rigIdle(rig.lt, rig);
    }
    if (hasIntro(rig.scene) && rig.lt < introLen(rig.scene)) {
        applyIntro(rig);
    }
    return rig;
}

// 1 = 우주선 숨김
float shipHidden(float t) {
    int scene = sceneAt(t);
    float lt = t - SCENE_START[scene];
    return hasIntro(scene) && lt < introLen(scene) - 1.5 ? 1.0 : 0.0;
}

// 우주선이 뒤(+Z)에서 날아드는 위치 오프셋(블록)
vec3 shipFlyOffset(float t) {
    int scene = sceneAt(t);
    float lt = t - SCENE_START[scene];
    float len = introLen(scene);
    if (!hasIntro(scene) || lt >= len) {
        return vec3(0.0);
    }
    float k = 1.0 - smoother01(remap(lt, len - 1.5, len));
    return vec3(0.0, 2.5 * k, 55.0 * k * k);
}

// 태양 장면 처음 15.5초는 일부러 눈부시게, 나레이터가 '조정'하면 2초 동안 내려간다
float sunGlare(float lt) {
    return 1.0 - smoother01(remap(lt, 15.5, 17.5));
}


// --- 우주선 기동(3인칭: 우주선이 화면 안에서 움직임, 1인칭: 우주가 대신 기울어짐) -----------

const vec3 STAGE_ORIGIN = vec3(0.5, 100.0, 0.5);
const vec3 SHIP_PIVOT = vec3(0.5, 100.3, 0.5);
const vec3 SEAT_EYE = vec3(0.5, 100.8, -2.12);

struct ShipPose {
    vec3 offset;
    vec3 euler;
};

const int MV_JUKE = 0;
const int MV_ROLL = 1;
const int MV_SURGE = 2;
const int MV_JOLT = 3;
const int MV_TUMBLE = 4;
const int MV_BANK = 5;

// (시작 초, 길이, 종류, 값: 방향·거리·세기·바퀴)
const vec4 MANEUVERS[58] = vec4[](
    vec4(36.0, 6.0, 5.0, 0.5), vec4(47.0, 5.0, 2.0, 8.0), vec4(96.0, 6.0, 5.0, -0.5), vec4(112.0, 6.0, 2.0, 10.0),
    vec4(208.6, 1.8, 0.0, -1.0), vec4(212.6, 1.5, 1.0, 1.0), vec4(217.6, 1.8, 0.0, 1.0), vec4(221.6, 4.0, 2.0, 14.0),
    vec4(225.6, 1.5, 1.0, -1.0), vec4(230.6, 1.8, 0.0, -1.0), vec4(235.6, 3.0, 3.0, 0.5), vec4(239.6, 1.4, 1.0, 1.0),
    vec4(243.6, 1.8, 0.0, 1.0), vec4(248.6, 4.0, 3.0, 1.0), vec4(248.6, 6.0, 4.0, 1.0), vec4(254.6, 5.0, 5.0, -0.5),
    vec4(258.6, 3.0, 3.0, 0.6), vec4(258.6, 1.5, 0.0, 1.0), vec4(263.6, 3.5, 2.0, 10.0), vec4(268.6, 1.5, 1.0, -1.0),
    vec4(363.8, 7.0, 2.0, 26.0), vec4(379.8, 7.0, 5.0, 0.5), vec4(393.8, 2.2, -1.0, 0.0), vec4(407.8, 6.0, 2.0, 18.0),
    vec4(423.8, 2.2, 0.0, -1.0), vec4(467.7, 8.0, 5.0, 0.5), vec4(485.7, 7.0, 2.0, 22.0), vec4(524.2, 2.0, 0.0, -1.0),
    vec4(534.2, 1.6, 1.0, 1.0), vec4(542.0, 4.0, 3.0, 1.0), vec4(542.0, 6.0, 4.0, -0.9), vec4(550.0, 6.0, 5.0, -0.5),
    vec4(580.2, 9.0, 5.0, -0.4), vec4(595.2, 8.0, 2.0, 12.0), vec4(614.2, 6.0, 5.0, 0.4), vec4(653.2, 1.6, 1.0, 1.0),
    vec4(660.2, 5.0, 2.0, 14.0), vec4(668.2, 1.8, 0.0, -1.0), vec4(678.2, 1.6, 1.0, -1.0), vec4(688.2, 1.8, 0.0, 1.0),
    vec4(694.2, 1.4, 1.0, 1.0), vec4(700.2, 4.0, 3.0, 1.0), vec4(700.2, 6.0, 4.0, 1.0), vec4(710.2, 7.0, 5.0, -0.5),
    vec4(750.2, 8.0, 2.0, 16.0), vec4(766.2, 9.0, 5.0, 0.4), vec4(838.2, 4.0, 3.0, 1.0), vec4(838.2, 6.0, 4.0, 1.3),
    vec4(901.9, 1.4, 1.0, -1.0), vec4(907.9, 1.6, 0.0, 1.0), vec4(913.9, 1.4, 1.0, 1.0), vec4(919.9, 1.6, 0.0, -1.0),
    vec4(925.9, 1.4, 1.0, -1.0), vec4(931.9, 1.6, 0.0, 1.0), vec4(937.9, 1.4, 1.0, 1.0), vec4(942.9, 1.6, 0.0, -1.0),
    vec4(916.9, 5.0, 2.0, 12.0), vec4(0.0, 0.0, -1.0, 0.0)
);

// 0→1→0, 시작·끝 속도 0
float arc(float s) {
    float a = s <= 0.0 || s >= 1.0 ? 0.0 : sin(PI * s);
    return a * a;
}

void maneuver(inout ShipPose p, vec4 m, float t) {
    int kind = int(m.z + 0.5);
    float d = t - m.x;
    float s = d / max(m.y, 1e-3);
    if (m.z < 0.0 || d < 0.0 || s > 1.0) {
        return;
    }
    float v = m.w;
    if (kind == MV_JUKE) {
        float sw = s <= 0.0 || s >= 1.0 ? 0.0 : sin(TAU * s) * sin(PI * s);
        p.offset += vec3(v * 4.5, -0.8, 0.0) * arc(s);
        p.euler.z += -v * 0.55 * sw;
        p.euler.y += -v * 0.15 * sw;
    } else if (kind == MV_ROLL) {
        p.euler.z += v * TAU * smoother01(s);
        p.offset += vec3(v * 2.2, 0.6, 0.0) * arc(s);
    } else if (kind == MV_SURGE) {
        float out_ = smoother01(min(s / 0.35, 1.0));
        float back = smoother01(max((s - 0.35) / 0.65, 0.0));
        p.offset.z -= v * out_ * (1.0 - back);
        p.euler.x += 0.08 * arc(s);
    } else if (kind == MV_JOLT) {
        float e = exp(-d * 2.2) * v;
        p.euler += e * vec3(0.35 * sin(d * 19.0), 0.2 * sin(d * 17.0 + 2.0), 0.6 * sin(d * 13.0 + 1.0));
        p.offset += e * 0.5 * vec3(sin(d * 23.0), sin(d * 29.0 + 1.0), sin(d * 31.0 + 2.0));
    } else if (kind == MV_TUMBLE) {
        // 충격으로 빠르게 기울었다가 자동조종이 천천히 바로잡는다(끝까지 연속, 값 = 기울기 라디안)
        float k = (1.0 - exp(-d * 6.0)) * exp(-d * 0.9);
        p.euler += vec3(0.30 * abs(v), 0.12 * v, v) * k;
    } else {
        p.offset += vec3(v * 4.0, 0.0, 0.0) * arc(s);
        p.euler.z += v * 0.5 * arc(s);
        p.euler.y += v * 0.12 * arc(s);
    }
}

ShipPose shipPose(float t) {
    ShipPose p;
    p.offset = vec3(0.0);
    p.euler = vec3(0.0);
    if (t >= T_IDLE || t >= 954.9 || (t >= 889.9 && t < 892.9)) {
        return p;
    }
    p.offset = vec3(0.5 * sin(t * 0.31), 0.3 * sin(t * 0.47 + 1.0), 0.6 * sin(t * 0.23 + 2.0));
    p.euler = vec3(0.02 * sin(t * 0.37), 0.02 * sin(t * 0.29), 0.035 * sin(t * 0.21));
    for (int i = 0; i < 58; i++) {
        maneuver(p, MANEUVERS[i], t);
    }
    for (int i = S_MARS; i <= S_BH; i++) {
        float b = SCENE_START[i];
        float lead = smoother01(remap(t, b - 6.0, b - 0.6));
        float shoot = remap(t, b - 0.6, b);
        if (t > b - 6.0 && t < b) {
            p.offset.z -= 8.0 * lead + 320.0 * shoot * shoot * shoot;
        }
    }
    float pull = t < 891.9 ? smoother01(remap(t, 778.2, 818.2)) * 22.0 + smoother01(remap(t, 843.2, 891.9)) * 40.0 : 0.0;
    p.offset.z -= pull;
    float sh = shakeAmount(t);
    p.offset += sh * 0.12 * (vec3(vnoise(vec3(t * 31.0, 0.0, 0.0)), vnoise(vec3(0.0, t * 37.0, 0.0)), vnoise(vec3(0.0, 0.0, t * 29.0))) - 0.5);
    return p;
}

mat3 poseRotation(ShipPose p) {
    return rotY(p.euler.y) * rotX(p.euler.x) * rotZ(p.euler.z);
}

// 카메라(장면 회전)보다 우주선이 0.45초 늦게 돈다
mat3 shipLag(float t) {
    if (t >= T_IDLE) {
        return mat3(1.0);
    }
    float tl = t - 0.45;
    if (sceneAt(tl) != sceneAt(t) || tl < 0.0) {
        return mat3(1.0);
    }
    mat3 m = transpose(rigAt(t).basis) * rigAt(tl).basis;
    float angle = acos(clamp((m[0][0] + m[1][1] + m[2][2] - 1.0) * 0.5, -1.0, 1.0));
    float k = angle > 0.35 ? 0.35 / angle : 1.0;
    return basisFrom(normalize(mix(vec3(0.0, 0.0, -1.0), m * vec3(0.0, 0.0, -1.0), k)), normalize(mix(vec3(0.0, 1.0, 0.0), m * vec3(0.0, 1.0, 0.0), k)));
}

mat3 shipRotation(float t, ShipPose p) {
    return shipLag(t) * poseRotation(p);
}

// 회전을 일부만(k) 적용: 1인칭에선 배경 기울기를 약하게
mat3 dampRotation(mat3 m, float k) {
    return basisFrom(normalize(mix(vec3(0.0, 0.0, -1.0), m * vec3(0.0, 0.0, -1.0), k)), normalize(mix(vec3(0.0, 1.0, 0.0), m * vec3(0.0, 1.0, 0.0), k)));
}

bool isFirstPerson(vec3 camWorld) {
    return length(camWorld - SEAT_EYE) < 3.0;
}

// --- 우주선 조명(아이템 셰이더가 씀) -----------------------------------------

struct ShipLight {
    vec3 keyDir;
    vec3 keyColor;
    vec3 fill;
    vec3 rimDir;
    vec3 rimColor;
};

// 가상 좌표의 광원 방향 → 실제(월드) 방향은 transpose(basis)
ShipLight shipLight(Rig rig) {
    ShipLight l;
    mat3 toReal = transpose(rig.basis);
    l.keyDir = normalize(toReal * rig.sunDir);
    l.keyColor = vec3(1.0, 0.97, 0.92) * 2.2;
    l.fill = vec3(0.020, 0.024, 0.032);
    l.rimDir = -l.keyDir;
    l.rimColor = vec3(0.0);
    float lt = rig.lt;
    if (rig.scene == S_EARTH) {
        vec3 p = rig.pos;
        vec3 s = rig.sunDir;
        float b = dot(p, s);
        float shadow = (b < 0.0 && length(p - b * s) < 1.0) ? 1.0 : 0.0;
        float lit = 1.0 - shadow * (1.0 - remap(length(p - b * s), 0.985, 1.02));
        l.keyColor *= lit;
        vec3 down = normalize(-p);
        l.rimDir = normalize(toReal * down);
        l.rimColor = vec3(0.10, 0.20, 0.42) * (0.25 + 0.75 * sat(dot(-down, s) + 0.3)) * remap(length(p), 9.0, 1.05);
        l.fill = vec3(0.012, 0.016, 0.026);
    } else if (rig.scene == S_BELT) {
        l.keyColor = vec3(1.0, 0.96, 0.90) * 1.7;
    } else if (rig.scene == S_JUPITER) {
        l.keyColor = vec3(1.0, 0.95, 0.88) * 1.2;
        l.rimDir = normalize(toReal * normalize(-rig.pos));
        l.rimColor = vec3(0.30, 0.22, 0.14) * 0.6;
    } else if (rig.scene == S_MARS) {
        l.keyColor = vec3(1.0, 0.95, 0.88) * 1.7;
        l.rimDir = normalize(toReal * normalize(-rig.pos));
        l.rimColor = vec3(0.45, 0.20, 0.10) * 0.4;
    } else if (rig.scene == S_SATURN) {
        l.keyColor = vec3(1.0, 0.96, 0.88) * 1.1;
        l.rimDir = normalize(toReal * normalize(-rig.pos));
        l.rimColor = vec3(0.30, 0.27, 0.20) * 0.5;
    } else if (rig.scene == S_SUN) {
        l.keyColor = vec3(1.0, 0.86, 0.62) * (4.5 + 12.0 * sunGlare(lt));
        l.fill = vec3(0.18, 0.08, 0.02);
    } else if (rig.scene == S_BETEL) {
        l.keyColor = vec3(1.0, 0.42, 0.16) * 2.6;
        l.fill = vec3(0.10, 0.02, 0.005);
    } else if (rig.scene == S_PULSAR) {
        float beat = pow(0.5 + 0.5 * cos(TAU * 1.4 * rig.t), 24.0);
        l.keyColor = vec3(0.55, 0.75, 1.0) * (0.6 + 4.0 * beat);
        l.fill = vec3(0.04, 0.03, 0.08);
    } else if (rig.scene == S_BH) {
        vec3 diskUp = normalize(toReal * vec3(0.0, 1.0, 0.0));
        l.keyDir = normalize(toReal * normalize(-rig.pos + vec3(0.0, -0.2 * length(rig.pos), 0.0)));
        l.keyColor = vec3(1.0, 0.62, 0.30) * 2.0 * (1.0 - remap(lt, 125.0, 183.5));
        l.rimDir = -diskUp;
        l.rimColor = vec3(1.0, 0.5, 0.2) * 0.4;
        l.fill = vec3(0.02, 0.012, 0.008);
    } else if (rig.scene == S_INSIDE) {
        float pulse = 0.75 + 0.25 * sin(rig.t * 3.0);
        l.keyDir = normalize(toReal * normalize(vec3(0.3, 1.0, 0.2)));
        l.keyColor = vec3(1.0, 0.72, 0.38) * 1.6 * pulse;
        l.rimDir = normalize(toReal * normalize(vec3(-0.5, -0.4, 0.6)));
        l.rimColor = vec3(0.3, 0.75, 1.0) * 0.9;
        l.fill = vec3(0.06, 0.04, 0.03);
    } else if (rig.scene == S_IDLE) {
        // 로비 = 한낮 야외: 하늘 주변광이 커서 어느 쪽에서 봐도 하얀 배(나레이션 '크고 하얀 물체')
        // 세운 로켓: 스폰(남남서)에서 보이는 옆면을 왼쪽 위에서 비춘다(대기 카메라 회전과 무관하게 월드에 고정)
        l.keyDir = normalize(vec3(-0.66, 0.64, 0.39));
        l.keyColor = vec3(1.0, 0.97, 0.92) * 0.9;
        l.fill = vec3(0.46, 0.50, 0.56);
    } else {
        l.keyColor = vec3(0.0);
        l.fill = vec3(0.0);
    }
    float wf = warpFlash(rig.t) + impactFlash(rig.t);
    l.fill += vec3(0.8, 0.9, 1.0) * wf;
    return l;
}

#endif
