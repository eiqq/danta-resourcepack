#ifndef BH_COMMON_GLSL
#define BH_COMMON_GLSL

const float PI = 3.14159265359;
const float TAU = 6.28318530718;

float sat(float x) { return clamp(x, 0.0, 1.0); }
vec3 sat(vec3 x) { return clamp(x, 0.0, 1.0); }
float remap(float x, float a, float b) { return sat((x - a) / (b - a)); }
float smooth01(float x) { x = sat(x); return x * x * (3.0 - 2.0 * x); }
float smoother01(float x) { x = sat(x); return x * x * x * (x * (x * 6.0 - 15.0) + 10.0); }
float window(float t, float a, float b, float fadeIn, float fadeOut) {
    return remap(t, a, a + fadeIn) * (1.0 - remap(t, b - fadeOut, b));
}

float hash11(float p) { p = fract(p * 0.1031); p *= p + 33.33; p *= p + p; return fract(p); }
float hash12(vec2 p) { vec3 q = fract(vec3(p.xyx) * 0.1031); q += dot(q, q.yzx + 33.33); return fract((q.x + q.y) * q.z); }
float hash13(vec3 p) { p = fract(p * 0.1031); p += dot(p, p.zyx + 31.32); return fract((p.x + p.y) * p.z); }
vec3 hash33(vec3 p) {
    p = fract(p * vec3(0.1031, 0.1030, 0.0973));
    p += dot(p, p.yxz + 33.33);
    return fract((p.xxy + p.yxx) * p.zyx);
}

float vnoise(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(mix(hash13(i), hash13(i + vec3(1, 0, 0)), f.x),
                   mix(hash13(i + vec3(0, 1, 0)), hash13(i + vec3(1, 1, 0)), f.x), f.y),
               mix(mix(hash13(i + vec3(0, 0, 1)), hash13(i + vec3(1, 0, 1)), f.x),
                   mix(hash13(i + vec3(0, 1, 1)), hash13(i + vec3(1, 1, 1)), f.x), f.y), f.z);
}

float fbm3(vec3 p, int octaves) {
    float sum = 0.0;
    float amp = 0.5;
    for (int i = 0; i < octaves; i++) {
        sum += amp * vnoise(p);
        p = p * 2.03 + vec3(1.7, 9.2, 3.1);
        amp *= 0.5;
    }
    return sum;
}

mat3 rotX(float a) { float c = cos(a), s = sin(a); return mat3(1, 0, 0, 0, c, s, 0, -s, c); }
mat3 rotY(float a) { float c = cos(a), s = sin(a); return mat3(c, 0, -s, 0, 1, 0, s, 0, c); }
mat3 rotZ(float a) { float c = cos(a), s = sin(a); return mat3(c, s, 0, -s, c, 0, 0, 0, 1); }
mat3 rotAxis(vec3 axis, float a) {
    float c = cos(a), s = sin(a);
    vec3 k = axis * (1.0 - c);
    return mat3(k.x * axis + vec3(c, axis.z * s, -axis.y * s),
                k.y * axis + vec3(-axis.z * s, c, axis.x * s),
                k.z * axis + vec3(axis.y * s, -axis.x * s, c));
}

// 앞(forward)·위(up)를 받아 실제 방향(앞 = -Z) → 가상 방향 변환 행렬
mat3 basisFrom(vec3 forward, vec3 upHint) {
    vec3 f = normalize(forward);
    vec3 r = normalize(cross(f, upHint));
    vec3 u = cross(r, f);
    return mat3(r, u, -f);
}

// 광선-구: (가까운 t, 먼 t), 안 맞으면 x > y
vec2 raySphere(vec3 ro, vec3 rd, vec3 c, float r) {
    vec3 oc = ro - c;
    float b = dot(oc, rd);
    float h = b * b - dot(oc, oc) + r * r;
    if (h < 0.0) {
        return vec2(1e30, -1e30);
    }
    h = sqrt(h);
    return vec2(-b - h, -b + h);
}

// 광선이 점에 가장 가까이 가는 거리
float rayPointDist(vec3 ro, vec3 rd, vec3 p) {
    vec3 op = p - ro;
    float t = max(dot(op, rd), 0.0);
    return length(op - rd * t);
}

vec2 dirToEquirect(vec3 d) {
    return vec2(atan(d.x, -d.z) / TAU + 0.5, acos(clamp(d.y, -1.0, 1.0)) / PI);
}

vec3 blackbody(float kelvin) {
    float t = kelvin / 100.0;
    vec3 c;
    c.r = t <= 66.0 ? 1.0 : sat(1.29293618 * pow(t - 60.0, -0.1332047592));
    c.g = t <= 66.0 ? sat(0.39008157 * log(t) - 0.63184144) : sat(1.12989086 * pow(t - 60.0, -0.0755148492));
    c.b = t >= 66.0 ? 1.0 : (t <= 19.0 ? 0.0 : sat(0.54320678 * log(t - 10.0) - 1.19625408));
    return c * c;
}

vec3 tonemap(vec3 x) {
    x = max(x, 0.0);
    vec3 a = x * (2.51 * x + 0.03);
    vec3 b = x * (2.43 * x + 0.59) + 0.14;
    return pow(sat(a / b), vec3(1.0 / 2.2));
}

float luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }

#endif
