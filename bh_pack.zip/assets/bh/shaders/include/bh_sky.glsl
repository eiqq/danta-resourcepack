#ifndef BH_SKY_GLSL
#define BH_SKY_GLSL

#include <bh:bh_fx.glsl>
#include <bh:bh_annot_data.glsl>

// 우주 합성: 장면마다 배경 → 먼 것 → 가까운 것 순으로 덮는다. 결과는 선형 HDR.


vec3 sunDisk(vec3 rd, vec3 s, float radius, float intensity) {
    float a = acos(clamp(dot(rd, s), -1.0, 1.0));
    float disk = smoothstep(radius * 1.05, radius * 0.95, a);
    float glare = exp(-a / (radius * 2.5)) * 0.35 + exp(-a / (radius * 12.0)) * 0.06;
    return vec3(1.0, 0.96, 0.9) * (disk * intensity + glare * intensity * 0.12);
}

// 먼 것부터 부르면 가까운 것이 덮는다
void over(inout vec3 col, vec4 layer) {
    col = mix(col, layer.rgb, layer.a);
}

float sceneExposure(int scene, float lt) {
    if (scene == S_SUN) {
        return mix(0.085, 0.75, sunGlare(lt));
    }
    if (scene == S_BETEL) {
        return 0.17;
    }
    if (scene == S_MARS) {
        return 1.15;
    }
    if (scene == S_JUPITER || scene == S_SATURN) {
        return 0.95;
    }
    if (scene == S_BH) {
        return mix(0.55, 0.26, smoothstep(60.0, 115.0, lt));
    }
    return 1.0;
}

void over2(inout vec3 col, vec4 a, float ta, vec4 b, float tb) {
    if (ta > tb) {
        over(col, a);
        over(col, b);
    } else {
        over(col, b);
        over(col, a);
    }
}

vec3 universe(sampler2D atlas, vec3 dirReal, Rig rig, vec3 camOffReal, float pixAngle) {
    vec3 rd = normalize(rig.basis * dirReal);
    vec3 fwd = rig.basis * vec3(0.0, 0.0, -1.0);
    int scene = rig.scene;
    float lt = rig.lt;
    float t = rig.t;
    vec3 s = rig.sunDir;
    vec3 ro = rig.pos;
    float warp = max(warpOut(t), warpIn(t));
    vec3 col = warp > 0.002 ? warpStreaks(atlas, rd, fwd, warp, pixAngle, scene) + slipstream(rd, fwd, warp, t) : background(atlas, rd, pixAngle, scene);
    float tA;
    float tB;

    if (scene == S_EARTH) {
        vec2 occ = raySphere(ro, s, vec3(0.0), 1.0);
        float sunVis = (occ.x < occ.y && occ.y > 0.0) ? 0.0 : 1.0;
        col += sunDisk(rd, s, 0.0047, 140.0) * sunVis;
        col += earthLimb(ro, rd, s);
        vec4 m = moon(atlas, ro, rd, s, pixAngle, tA);
        vec4 e = earth(atlas, ro, rd, s, t, pixAngle, tB);
        over2(col, m, tA, e, tB);
    } else if (scene == S_MARS) {
        col += sunDisk(rd, s, 0.0031, 130.0);
        vec4 m = mars(atlas, ro, rd, s, t, pixAngle, tA);
        col += m.a > 0.0 ? vec3(0.0) : m.rgb;
        over(col, m);
    } else if (scene == S_BELT) {
        col += sunDisk(rd, s, 0.0018, 120.0);
        col += vec3(0.20, 0.17, 0.12) * pow(sat(dot(rd, s) * 0.5 + 0.5), 6.0) * 0.05;
        vec4 far = rockLayers(ro * 0.25 + vec3(0.0, 40.0, 0.0), rd, s, 20.0, 18.0, 0.06, 0.3, 1.0, vec3(1.0, 0.9, 0.8), 0.0, 0.0, pixAngle, tB);
        over(col, vec4(far.rgb * 0.7, far.a));
        vec4 rocks = rockLayers(ro + camOffReal * 0.15, rd, s, 16.0, 10.0, 0.045 * mix(1.0, 0.45, smoothstep(76.0, 92.0, lt)), 0.2, 1.0, vec3(1.1, 0.95, 0.8), 0.0, 0.0, pixAngle, tA);
        vec4 big = bigAsteroid(ro, rd, s, BIG_ROCK_POS, BIG_ROCK_R, lt, tB);
        over2(col, rocks, tA, big, tB);
        col += spaceDust(ro, rd, vec3(0.0, 0.0, -28.0), pixAngle);
    } else if (scene == S_JUPITER) {
        col += sunDisk(rd, s, 0.0009, 100.0);
        vec4 j = jupiter(atlas, ro, rd, s, lt, pixAngle, tB);
        col += j.a > 0.0 ? vec3(0.0) : j.rgb;
        vec4 i = io(ro, rd, s, tA);
        over2(col, i, tA, j, tB);
    } else if (scene == S_SATURN) {
        col += sunDisk(rd, s, 0.0005, 100.0);
        over(col, saturn(atlas, ro, rd, s, lt, pixAngle, tA));
        float crossing = window(lt * (60.0 / 49.0), 50.0, 68.0, 2.0, 2.0);   // 토성 경로와 같은 압축(rigSaturn)
        if (crossing > 0.0) {
            const float K = 2400.0;
            vec3 lro = vec3(ro.x * K, ro.z * K, ro.y * K);
            vec3 lrd = vec3(rd.x, rd.z, rd.y);
            vec4 ice = rockLayers(lro, lrd, s.xzy, 7.0, 6.0, 0.10 * crossing, 0.05, 0.35, vec3(1.0), 1.0, 260.0, pixAngle, tB);
            over(col, ice);
        }
    } else if (scene == S_SUN) {
        vec4 su = sun(atlas, ro, rd, lt, tA);
        col += su.a > 0.0 ? vec3(0.0) : su.rgb;
        over(col, su);
        col += cmeShell(ro, rd, lt);
    } else if (scene == S_BETEL) {
        vec4 b = betelgeuse(atlas, ro, rd, lt, tA);
        col += b.a > 0.0 ? vec3(0.0) : b.rgb;
        over(col, b);
    } else if (scene == S_PULSAR) {
        col += pulsarNebula(ro, rd, t);
        col += pulsar(ro, rd, t, pixAngle);
    } else if (scene == S_BH) {
        vec3 outDir;
        vec4 bh = blackHole(atlas, ro, rd, lt, pixAngle, outDir);
        vec3 bg = warp > 0.002 ? col : background(atlas, normalize(outDir), pixAngle, scene);
        col = bh.rgb + bg * bh.a;
    } else if (scene == S_INSIDE) {
        col = insideSpace(ro, rd, t, lt);
    } else if (scene == S_END) {
        col = vec3(0.0);
    }

    col *= sceneExposure(scene, lt);
    return col;
}

// 화면 맨 아래 줄 왼쪽 칸에 후처리용 데이터(주 광원 화면 위치 등)
const vec3 DATA_CHECK = vec3(51.0, 153.0, 230.0) / 255.0;

vec3 encode16(float v) {
    float x = floor(sat(v) * 65535.0 + 0.5);
    return vec3(floor(x / 256.0), mod(x, 256.0), 0.0) / 255.0;
}

vec4 mainLight(Rig rig) {
    vec3 s = rig.sunDir;
    float intensity = 0.0;
    float size = 0.0;
    if (rig.scene == S_EARTH) {
        vec2 occ = raySphere(rig.pos, s, vec3(0.0), 1.01);
        intensity = (occ.x < occ.y && occ.y > 0.0) ? 0.0 : 1.0;
        size = 0.12;
    } else if (rig.scene == S_BELT) {
        intensity = 0.8;
        size = 0.06;
    } else if (rig.scene == S_JUPITER || rig.scene == S_SATURN) {
        vec2 occ = raySphere(rig.pos, s, vec3(0.0), 1.0);
        intensity = (occ.x < occ.y && occ.y > 0.0) ? 0.0 : 0.6;
        size = 0.04;
    } else if (rig.scene == S_PULSAR) {
        s = normalize(-rig.pos);
        intensity = 0.5 + 0.5 * pow(0.5 + 0.5 * cos(TAU * 1.4 * rig.t), 16.0);
        size = 0.05;
    } else if (rig.scene == S_IDLE) {
        intensity = 0.0;
    }
    return vec4(s, intensity * (1.0 - warpOut(rig.t)) * (1.0 - warpIn(rig.t)) + 0.0 * size);
}

vec2 screenUV(vec3 virtualDir, Rig rig, mat4 modelView, mat4 proj, out float front) {
    vec3 dirReal = transpose(rig.basis) * virtualDir;
    vec4 clip = proj * (modelView * vec4(dirReal, 0.0));
    front = step(1e-4, clip.w);
    return front > 0.0 ? clip.xy / clip.w * 0.5 + 0.5 : vec2(-1.0);
}

// 0 = 확인색, 1·2 = 주 광원(화면 uv 16비트·세기·장면), 3·4 = 블랙홀(화면 uv·세기·그림자 반지름)
float deviceDepth(vec4 clip) {
    float z = clip.z / clip.w;
    #ifdef RENDERPEARL_DEPTH_IS_ZERO_TO_ONE
    return z;
    #else
    return z * 0.5 + 0.5;
    #endif
}


// --- 홀로그램 주석 대상 -------------------------------------------------------

// 대상의 가상 중심과 반지름(blocks 아님, 장면 단위). 표면 지점은 보이는 면일 때만
bool annotTarget(int id, Rig rig, out vec3 center, out float radius) {
    center = vec3(0.0);
    radius = 1.0;
    float lt = rig.lt;
    if (id == 0) {
        center = rig.pos + rig.sunDir * 200.0;
        radius = 2.0;
    } else if (id == 2) {
        radius = 1.035;
    } else if (id == 3) {
        center = MOON_POS;
        radius = MOON_R;
    } else if (id == 4) {
        center = BIG_ROCK_POS;
        radius = BIG_ROCK_R;
    } else if (id == 6) {
        center = jupiterGRS(lt);
        radius = 0.12;
    } else if (id == 7) {
        vec3 sc = vec3(1.0, 1.0 / JUP_OBL, 1.0);
        vec2 h = raySphere(IO_POS * sc, normalize(-JUP_SUN * sc), vec3(0.0), 1.0);
        if (h.x > h.y) {
            return false;
        }
        center = (IO_POS * sc + normalize(-JUP_SUN * sc) * h.x) / sc;
        radius = 0.06;
    } else if (id == 9) {
        radius = 2.3;
    } else if (id == 11) {
        center = normalize(normalize(rig.pos) + vec3(0.12, -0.18, 0.0));
        radius = 0.06;
    } else if (id == 12) {
        center = SPOT_N;
        radius = 0.07;
    } else if (id == 13) {
        radius = 1.35;
    } else if (id == 14) {
        center = FLARE_N;
        radius = 0.1;
    } else if (id == 16) {
        radius = 0.05;
    } else if (id == 17 || id == 18) {
        radius = 5.2;
    } else if (id == 19) {
        radius = 26.0;
    } else if (id == 20) {
        center = vec3(0.0, 7.5, 0.0);
        radius = 2.5;
    } else if (id == 21) {
        center = INSIDE_SPHERE;
        radius = 26.0;
    }
    bool surface = id == 6 || id == 7 || id == 11 || id == 12 || id == 14;
    return !surface || dot(normalize(center), normalize(rig.pos - center)) > -0.02;
}

// 칸 3개: (u 16비트, v 상위) · (v 하위, 반지름, 보임) · (라벨 번호, 모양, 나타난 지 경과)
vec4 annotPixel(int slot, int part, Rig rig, mat4 modelView, mat4 proj) {
    int found = -1;
    int seen = 0;
    for (int i = 0; i < ANN_COUNT; i++) {
        if (rig.t >= ANN_T0[i] - 0.2 && rig.t < ANN_T1[i] + 0.6) {
            if (seen == slot) {
                found = i;
                break;
            }
            seen++;
        }
    }
    vec3 center;
    float radius;
    bool ok = found >= 0 && annotTarget(ANN_TARGET[found], rig, center, radius);
    float front = 0.0;
    vec2 uv = vec2(-1.0);
    float r = 0.0;
    if (ok) {
        vec3 to = center - rig.pos;
        float dist = length(to);
        uv = screenUV(to / dist, rig, modelView, proj, front);
        r = tan(asin(min(radius / dist, 0.999))) * proj[1][1] * 0.5;
    }
    float vis = found >= 0 && ok ? front * remap(rig.t, ANN_T0[found], ANN_T0[found] + 0.3) * (1.0 - remap(rig.t, ANN_T1[found], ANN_T1[found] + 0.6)) : 0.0;
    if (part == 0) {
        return vec4(encode16(uv.x * 0.25 + 0.375).xy, encode16(uv.y * 0.25 + 0.375).x, 1.0);
    }
    if (part == 1) {
        return vec4(encode16(uv.y * 0.25 + 0.375).y, sat(r / 0.6), vis, 1.0);
    }
    float age = found >= 0 ? sat((rig.t - ANN_T0[found]) / 1.2) : 0.0;
    return vec4(float(max(found, 0)) / 255.0, float(found >= 0 ? ANN_STYLE[found] : 0) / 255.0, age, 1.0);
}

// 효과 칸: 0 = 화면 uv(16비트 x, y 상위), 1 = (y 하위, 세기, 블록당 픽셀/4), 2 = (깊이 16비트, 나이·종류)
vec4 fxPixel(int slot, int part, Rig rig, mat4 modelView, mat4 proj, vec3 camWorld) {
    float t = rig.t;
    vec3 local;
    vec3 fx = fxSlot(slot, t, local);
    vec3 world = STAGE_ORIGIN + local;
    if (!isFirstPerson(camWorld) && t < T_IDLE) {
        ShipPose sp = shipPose(t);
        world = SHIP_PIVOT + shipRotation(t, sp) * (world - SHIP_PIVOT) + sp.offset + shipFlyOffset(t);
    }
    vec4 view = modelView * vec4(world - camWorld, 1.0);
    vec4 clip = proj * view;
    bool front = clip.w > 0.05 && fx.x > 0.0 && shipHidden(t) < 0.5;
    vec2 uv = front ? clip.xy / clip.w * 0.5 + 0.5 : vec2(-1.0);
    float px = front ? proj[1][1] / clip.w * ScreenSize.y * 0.5 : 0.0;
    if (part == 0) {
        return vec4(encode16(uv.x * 0.25 + 0.375).xy, encode16(uv.y * 0.25 + 0.375).x, 1.0);
    }
    if (part == 1) {
        return vec4(encode16(uv.y * 0.25 + 0.375).y, front ? sat(fx.x * 0.7) : 0.0, sat(px / 1020.0), 1.0);
    }
    return vec4(encode16(front ? deviceDepth(clip) : 0.0).xy, sat(fx.y / 2.0) * 0.5 + fx.z * 0.5 + 0.001, 1.0);
}

vec4 dataPixel(int x, Rig rig, mat4 modelView, mat4 proj, vec3 camWorld) {
    if (x == 0) {
        return vec4(DATA_CHECK, 1.0);
    }
    if (x >= 26 && x < 32) {
        return annotPixel((x - 26) / 3, (x - 26) % 3, rig, modelView, proj);
    }
    if (x >= FX_DATA_BASE && x < FX_DATA_BASE + FX_SLOTS * 3) {
        int i = x - FX_DATA_BASE;
        return fxPixel(i / 3, i % 3, rig, modelView, proj, camWorld);
    }
    float front;
    if (x == 5 || x == 6) {
        vec2 uv = screenUV(rig.basis * vec3(0.0, 0.0, -1.0), rig, modelView, proj, front);
        return x == 5 ? vec4(encode16(uv.x * 0.25 + 0.375).xy, encode16(uv.y * 0.25 + 0.375).x, 1.0)
                      : vec4(encode16(uv.y * 0.25 + 0.375).y, front, 0.0, 1.0);
    }
    if (x <= 2) {
        vec4 light = mainLight(rig);
        vec2 uv = screenUV(light.xyz, rig, modelView, proj, front);
        float on = front * light.w;
        return x == 1 ? vec4(encode16(uv.x * 0.25 + 0.375).xy, encode16(uv.y * 0.25 + 0.375).x, 1.0)
                      : vec4(encode16(uv.y * 0.25 + 0.375).y, on, float(rig.scene) / 255.0, 1.0);
    }
    if (x <= 4 && rig.scene == S_BH) {
        float r = length(rig.pos);
        vec2 uv = screenUV(normalize(-rig.pos), rig, modelView, proj, front);
        float strength = front * remap(rig.lt, 60.0, 140.0);
        float shadow = tan(asin(min(5.2 / r, 0.999))) * proj[1][1] * 0.5;
        return x == 3 ? vec4(encode16(uv.x * 0.25 + 0.375).xy, encode16(uv.y * 0.25 + 0.375).x, 1.0)
                      : vec4(encode16(uv.y * 0.25 + 0.375).y, strength, sat(shadow), 1.0);
    }
    return vec4(0.0, 0.0, 0.0, 1.0);
}

#endif
