#version 330
#extension GL_ARB_separate_shader_objects : require

#ifdef GLINT
#include <minecraft:globals.glsl>
#endif
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>
#ifndef OIT
#include <minecraft:projection.glsl>
#include <bh:bh_common.glsl>
#include <bh:bh_timeline.glsl>
#include <bh:bh_material.glsl>
#endif

uniform sampler2D Sampler0;

#ifdef GLINT
uniform sampler2D GlintSampler;
#endif

#ifndef OIT_ALPHA_ONLY
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#endif
layout(location = 2) in vec4 vertexColor;
#ifndef OIT_ALPHA_ONLY
layout(location = 3) in vec4 lightMapColor;
layout(location = 4) in vec4 overlayColor;
#endif
layout(location = 5) in vec2 texCoord0;
#ifdef GLINT
layout(location = 6) in vec2 texCoordGlint;
#endif

#ifndef OIT
layout(location = 7) flat in vec4 bhA;
layout(location = 8) in vec3 bhLight;
layout(location = 9) in vec3 bhSpec;
layout(location = 10) in vec3 bhView;
layout(location = 11) in vec2 bhCorner;
layout(location = 12) flat in vec4 bhKey;
layout(location = 13) flat in vec4 bhKeyColor;
#endif

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

#ifndef OIT_ALPHA_ONLY
vec4 calculateFinalColor(vec4 color) {
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
    color *= lightMapColor;

    #ifdef GLINT
    vec4 glintColor = GlintAlpha * texture(GlintSampler, texCoordGlint);// Glint color modulator?
    // Matches BlendFuntion.GLINT
    color.rgb += glintColor.rgb * glintColor.rgb;
    #endif

    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    return apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
}
#endif

#ifndef OIT
float viewDepth(vec3 viewPos) {
    vec4 clip = ProjMat * vec4(viewPos, 1.0);
    float z = clip.z / clip.w;
    #ifdef RENDERPEARL_DEPTH_IS_ZERO_TO_ONE
    return z;
    #else
    return z * 0.5 + 0.5;
    #endif
}

// 정사각형 면(빌보드) 위에 울퉁불퉁한 구를 광선 추적. 면의 중심·크기는 화면 미분으로 되찾는다
void impostor(bool ice) {
    vec3 p = bhView;
    vec2 c = bhCorner;
    vec3 dpx = dFdx(p);
    vec3 dpy = dFdy(p);
    vec2 dcx = dFdx(c);
    vec2 dcy = dFdy(c);
    float det = dcx.x * dcy.y - dcx.y * dcy.x;
    if (abs(det) < 1e-10) {
        discard;
    }
    mat2 inv = mat2(dcy.y, -dcx.y, -dcy.x, dcx.x) / det;
    vec3 ax = dpx * inv[0][0] + dpy * inv[0][1];
    vec3 ay = dpx * inv[1][0] + dpy * inv[1][1];
    vec3 center = p - ax * c.x - ay * c.y;
    float radius = 0.46 * min(length(ax), length(ay));
    vec3 rd = normalize(p);
    float along = dot(center, rd);
    vec3 closest = rd * along - center;
    float dc = length(closest);
    float seed = bhA.y;
    float t = bhA.z;
    vec3 axis = normalize(hash33(vec3(seed, 3.1, 7.7)) - 0.5);
    mat3 tumble = rotAxis(axis, t * (0.25 + 0.05 * seed));
    vec3 cn = tumble * normalize(closest + 1e-6);
    float edge = radius * (ice ? 0.80 + 0.22 * vnoise(cn * 3.0 + seed * 9.1) : 0.74 + 0.30 * vnoise(cn * 2.4 + seed * 9.1));
    if (dc > edge) {
        discard;
    }
    float depth = sqrt(max(edge * edge - dc * dc, 0.0));
    vec3 hit = rd * (along - depth);
    vec3 n = normalize(hit - center);
    vec3 ln = tumble * n;
    vec3 bump = vec3(vnoise(ln * 5.0 + 1.0), vnoise(ln * 5.0 + 2.0), vnoise(ln * 5.0 + 3.0)) - 0.5;
    n = normalize(n + transpose(tumble) * bump * (ice ? 0.35 : 0.9));
    vec3 l = normalize(bhKey.xyz);
    float ndl = max(dot(n, l), 0.0);
    float tone = fbm3(ln * 4.0 + seed, 3);
    vec3 albedo = ice ? mix(vec3(0.55, 0.65, 0.75), vec3(0.85, 0.92, 1.0), tone) : mix(vec3(0.06, 0.055, 0.05), vec3(0.17, 0.155, 0.14), tone);
    vec3 col = albedo * (bhKeyColor.rgb * ndl + vec3(0.015, 0.016, 0.02));
    if (ice) {
        col += bhKeyColor.rgb * pow(max(dot(reflect(-l, n), -rd), 0.0), 30.0) * 0.6;
        col += vec3(0.2, 0.3, 0.45) * pow(1.0 - max(dot(n, -rd), 0.0), 3.0) * 0.3;
    }
    fragColor = vec4(tonemap(col), 1.0);
    gl_FragDepth = viewDepth(hit);
}

vec3 shipMaterial(int mode, vec3 albedo) {
    float t = bhA.z;
    float power = powerLevel(t);
    if (mode == BHM_LIT) {
        return albedo * bhLight + bhSpec;
    }
    if (mode == BHM_EMISSIVE) {
        return albedo * (0.4 + 2.2 * power) + albedo * bhLight * 0.3;
    }
    if (mode == BHM_BLINK) {
        float on = step(fract(t * 0.8 + bhA.w), 0.10);
        return albedo * (0.08 + 7.0 * on);
    }
    if (mode == BHM_ALARM) {
        float a = max(alarmOn(t), emergencyOn(t) * 0.6);
        float beat = pow(0.5 + 0.5 * sin(t * TAU * 1.2), 2.0);
        return albedo * (0.05 + 7.0 * a * beat);
    }
    if (mode == BHM_SCREEN) {
        float glitch = glitchAmount(t) * step(0.5, hash11(floor(t * 20.0) + bhA.w * 13.0));
        return albedo * 2.6 * power * (1.0 - glitch * 0.8);
    }
    float e = engineLevel(t);
    return albedo * vec3(0.7, 0.85, 1.0) * e * (1.1 + 0.15 * sin(t * 37.0 + bhA.w * 6.0));
}
#endif

void main() {
    #ifndef OIT
    gl_FragDepth = gl_FragCoord.z;
    int mode = int(bhA.x + 0.5);
    if (mode == BHM_ROCK || mode == BHM_ICE) {
        impostor(mode == BHM_ICE);
        return;
    }
    if (mode != BHM_NONE) {
        if (bhKey.w > 0.5) {
            discard;
        }
        vec4 tex = texture(Sampler0, texCoord0);
        if (tex.a < 0.1) {
            discard;
        }
        fragColor = vec4(tonemap(shipMaterial(mode, tex.rgb * tex.rgb)), 1.0);
        return;
    }
    #endif

    vec4 color = texture(Sampler0, texCoord0);
    #ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
    #endif

    color *= vertexColor * ColorModulator;

    #ifdef GLINT
    color.a = max(color.a, GlintAlpha);
    #endif

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}
