#version 330
#extension GL_ARB_separate_shader_objects : require

layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    mat4 TextureMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};
#ifndef MINECRAFT_GLOBALS_GLSL
#define MINECRAFT_GLOBALS_GLSL

layout(std140) uniform Globals {
    ivec3 CameraBlockPos;
    float GlintAlpha;
    vec3 CameraOffset;
    float GameTime;
    vec2 ScreenSize;
    int MenuBlurRadius;
    int UseRgss;
};

#endif

#ifndef BH_COMMON_GLSL
#define BH_COMMON_GLSL

const float PI = 3.14159265359;
const float TAU = 6.28318530718;

float sat(float x) { return clamp(x, 0.0, 1.0); }
vec3 sat(vec3 x) { return clamp(x, 0.0, 1.0); }
float remap(float x, float a, float b) { return sat((x - a) / (b - a)); }
float smooth01(float x) { x = sat(x); return x * x * (3.0 - 2.0 * x); }
float smoother01(float x) { x = sat(x); return x * x * x * (x * (x * 6.0 - 15.0) + 10.0); }
float window(float t, float a, float b, float fadeIn, float fadeOut) {
    return remap(t, a, a + fadeIn) * (1.0 - remap(t, b - fadeOut, b));
}

float hash11(float p) { p = fract(p * 0.1031); p *= p + 33.33; p *= p + p; return fract(p); }
float hash12(vec2 p) { vec3 q = fract(vec3(p.xyx) * 0.1031); q += dot(q, q.yzx + 33.33); return fract((q.x + q.y) * q.z); }
float hash13(vec3 p) { p = fract(p * 0.1031); p += dot(p, p.zyx + 31.32); return fract((p.x + p.y) * p.z); }
vec3 hash33(vec3 p) {
    p = fract(p * vec3(0.1031, 0.1030, 0.0973));
    p += dot(p, p.yxz + 33.33);
    return fract((p.xxy + p.yxx) * p.zyx);
}

float vnoise(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(mix(hash13(i), hash13(i + vec3(1, 0, 0)), f.x),
                   mix(hash13(i + vec3(0, 1, 0)), hash13(i + vec3(1, 1, 0)), f.x), f.y),
               mix(mix(hash13(i + vec3(0, 0, 1)), hash13(i + vec3(1, 0, 1)), f.x),
                   mix(hash13(i + vec3(0, 1, 1)), hash13(i + vec3(1, 1, 1)), f.x), f.y), f.z);
}

float fbm3(vec3 p, int octaves) {
    float sum = 0.0;
    float amp = 0.5;
    for (int i = 0; i < octaves; i++) {
        sum += amp * vnoise(p);
        p = p * 2.03 + vec3(1.7, 9.2, 3.1);
        amp *= 0.5;
    }
    return sum;
}

mat3 rotX(float a) { float c = cos(a), s = sin(a); return mat3(1, 0, 0, 0, c, s, 0, -s, c); }
mat3 rotY(float a) { float c = cos(a), s = sin(a); return mat3(c, 0, -s, 0, 1, 0, s, 0, c); }
mat3 rotZ(float a) { float c = cos(a), s = sin(a); return mat3(c, s, 0, -s, c, 0, 0, 0, 1); }
mat3 rotAxis(vec3 axis, float a) {
    float c = cos(a), s = sin(a);
    vec3 k = axis * (1.0 - c);
    return mat3(k.x * axis + vec3(c, axis.z * s, -axis.y * s),
                k.y * axis + vec3(-axis.z * s, c, axis.x * s),
                k.z * axis + vec3(axis.y * s, -axis.x * s, c));
}

// 앞(forward)·위(up)를 받아 실제 방향(앞 = -Z) → 가상 방향 변환 행렬
mat3 basisFrom(vec3 forward, vec3 upHint) {
    vec3 f = normalize(forward);
    vec3 r = normalize(cross(f, upHint));
    vec3 u = cross(r, f);
    return mat3(r, u, -f);
}

// 광선-구: (가까운 t, 먼 t), 안 맞으면 x > y
vec2 raySphere(vec3 ro, vec3 rd, vec3 c, float r) {
    vec3 oc = ro - c;
    float b = dot(oc, rd);
    float h = b * b - dot(oc, oc) + r * r;
    if (h < 0.0) {
        return vec2(1e30, -1e30);
    }
    h = sqrt(h);
    return vec2(-b - h, -b + h);
}

// 광선이 점에 가장 가까이 가는 거리
float rayPointDist(vec3 ro, vec3 rd, vec3 p) {
    vec3 op = p - ro;
    float t = max(dot(op, rd), 0.0);
    return length(op - rd * t);
}

vec2 dirToEquirect(vec3 d) {
    return vec2(atan(d.x, -d.z) / TAU + 0.5, acos(clamp(d.y, -1.0, 1.0)) / PI);
}

vec3 blackbody(float kelvin) {
    float t = kelvin / 100.0;
    vec3 c;
    c.r = t <= 66.0 ? 1.0 : sat(1.29293618 * pow(t - 60.0, -0.1332047592));
    c.g = t <= 66.0 ? sat(0.39008157 * log(t) - 0.63184144) : sat(1.12989086 * pow(t - 60.0, -0.0755148492));
    c.b = t >= 66.0 ? 1.0 : (t <= 19.0 ? 0.0 : sat(0.54320678 * log(t - 10.0) - 1.19625408));
    return c * c;
}

vec3 tonemap(vec3 x) {
    x = max(x, 0.0);
    vec3 a = x * (2.51 * x + 0.03);
    vec3 b = x * (2.43 * x + 0.59) + 0.14;
    return pow(sat(a / b), vec3(1.0 / 2.2));
}

float luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }

#endif

#ifndef BH_ATLAS_GLSL
#define BH_ATLAS_GLSL

// tools/atlas/build_atlas.py 와 같은 배치 (x, y, w, h)
const ivec2 ATLAS_SIZE = ivec2(8192, 5124);
const ivec4 R_SKY = ivec4(0, 0, 4096, 2048);
const ivec4 R_EARTH = ivec4(4096, 0, 4096, 2048);
const ivec4 R_EARTH_AUX = ivec4(0, 2048, 4096, 2048);
const ivec4 R_JUPITER = ivec4(4096, 2048, 4096, 2048);
const ivec4 R_MOON = ivec4(0, 4096, 2048, 1024);
const ivec4 R_NOISE = ivec4(2048, 4096, 512, 512);
const ivec4 R_SATURN = ivec4(2560, 4096, 512, 4);
const ivec4 R_RINGS = ivec4(2560, 4100, 512, 4);
const ivec4 R_DISK = ivec4(2048, 4608, 1024, 256);
const ivec4 R_EARTH_L2 = ivec4(3072, 4096, 1024, 512);
const ivec4 R_EARTH_AUX_L2 = ivec4(4096, 4096, 1024, 512);
const ivec4 R_JUPITER_L2 = ivec4(5120, 4096, 1024, 512);
const ivec4 R_MOON_L2 = ivec4(6144, 4096, 512, 256);
const ivec4 R_MARS = ivec4(3072, 4608, 1024, 512);
const ivec4 R_MARS_L2 = ivec4(4096, 4608, 256, 128);
const ivec4 R_VENUS = ivec4(4352, 4608, 1024, 512);

bool isUniverseAtlas(sampler2D s) {
    return textureSize(s, 0) == ATLAS_SIZE;
}

// 영역 안 겹선형(가로는 감싸기, 세로는 고정). uv 0~1
vec4 regionSample(sampler2D s, ivec4 r, vec2 uv) {
    vec2 p = uv * vec2(r.zw) - 0.5;
    vec2 f = fract(p);
    ivec2 i0 = ivec2(floor(p));
    int x0 = int(mod(float(i0.x), float(r.z)));
    int x1 = int(mod(float(i0.x + 1), float(r.z)));
    int y0 = clamp(i0.y, 0, r.w - 1);
    int y1 = clamp(i0.y + 1, 0, r.w - 1);
    vec4 a = texelFetch(s, r.xy + ivec2(x0, y0), 0);
    vec4 b = texelFetch(s, r.xy + ivec2(x1, y0), 0);
    vec4 c = texelFetch(s, r.xy + ivec2(x0, y1), 0);
    vec4 d = texelFetch(s, r.xy + ivec2(x1, y1), 0);
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

// 노이즈 타일(가로·세로 모두 감싸기)
vec4 noiseTex(sampler2D s, vec2 uv) {
    vec2 p = uv * 512.0 - 0.5;
    vec2 f = fract(p);
    ivec2 i0 = ivec2(floor(p));
    ivec2 a0 = ivec2(mod(vec2(i0), 512.0));
    ivec2 a1 = ivec2(mod(vec2(i0 + 1), 512.0));
    vec4 a = texelFetch(s, R_NOISE.xy + ivec2(a0.x, a0.y), 0);
    vec4 b = texelFetch(s, R_NOISE.xy + ivec2(a1.x, a0.y), 0);
    vec4 c = texelFetch(s, R_NOISE.xy + ivec2(a0.x, a1.y), 0);
    vec4 d = texelFetch(s, R_NOISE.xy + ivec2(a1.x, a1.y), 0);
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

// 화면에서 텍셀이 얼마나 작게 보이는지에 따라 1/4 해상도 영역과 섞는다
vec4 regionSampleLod(sampler2D s, ivec4 r0, ivec4 r2, vec2 uv, float texelsPerPixel) {
    float k = remap(texelsPerPixel, 1.5, 4.0);
    vec4 a = k < 1.0 ? regionSample(s, r0, uv) : vec4(0.0);
    vec4 b = k > 0.0 ? regionSample(s, r2, uv) : vec4(0.0);
    return mix(a, b, k);
}

#endif

#ifndef BH_TIMELINE_GLSL
#define BH_TIMELINE_GLSL

// 상영 시계 = 월드 gameTime(서버가 상영 시작 때 0 으로). 초 단위.
// 장면·사건 시각은 SPEC.md 2·3장과 같아야 한다. 낚시 조각·허탕 카운트다운 시각은 tools/audio/build.py 가 만든 bh_bits_data.
#ifndef BH_BITS_DATA_GLSL
#define BH_BITS_DATA_GLSL

// tools/audio/build.py 가 만든다(손으로 고치지 말 것)
const float FAKEOUT_T0 = 655.75;
const float FAKEOUT_T1 = 660.53;
const float GCB_START = 622.86;
const float GCB_WHITE = 620.86;
const float HWAL_CUT = 492.55;
const float HWAL_T0 = 486.22;
const float QUIZ_SONG = 682.04;

const int INSET_N = 13;
const int INSET_COLS = 4;
const int INSET_TILES = 13;
const float INSET_T0[13] = float[](160.15, 537.34, 543.38, 553.67, 557.01, 558.60, 570.44, 577.57, 583.87, 596.74, 722.82, 884.34, 919.75);
const float INSET_T1[13] = float[](168.21, 543.30, 551.59, 556.63, 558.42, 560.43, 577.49, 583.79, 596.66, 608.79, 728.91, 889.09, 925.05);
const int INSET_ID[13] = int[](12, 3, 4, 5, 6, 7, 8, 9, 10, 11, 2, 1, 0);
const int INSET_COLOR[13] = int[](1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1);

#endif

const int S_IDLE = 0;
const int S_EARTH = 1;
const int S_MARS = 2;
const int S_BELT = 3;
const int S_JUPITER = 4;
const int S_SATURN = 5;
const int S_SUN = 6;
const int S_BETEL = 7;
const int S_PULSAR = 8;
const int S_BH = 9;
const int S_INSIDE = 10;
const int S_END = 11;

const float T_IDLE = 1060.0;
const float SCENE_START[12] = float[](1060.0, 0.0, 130.0, 173.5, 253.5, 349.4, 423.1, 630.2, 702.2, 792.2, 955.9, 1021.9);
const float SCENE_END[12] = float[](1200.0, 130.0, 173.5, 253.5, 349.4, 423.1, 630.2, 702.2, 792.2, 955.9, 1021.9, 1060.0);

float showTime(float gameTime) {
    return gameTime * 1200.0;
}

int sceneAt(float t) {
    if (t >= T_IDLE) {
        return S_IDLE;
    }
    int s = S_EARTH;
    for (int i = S_MARS; i <= S_END; i++) {
        if (t >= SCENE_START[i]) {
            s = i;
        }
    }
    return s;
}

float pulse(float t, float t0, float decay) {
    return t < t0 ? 0.0 : exp(-(t - t0) * decay);
}

float warpOut(float t) {
    float w = 0.0;
    for (int i = S_MARS; i <= S_BH; i++) {
        float b = SCENE_START[i];
        w = max(w, remap(t, b - 6.0, b) * step(t, b));
    }
    return w * w;
}

float warpIn(float t) {
    float w = 0.0;
    for (int i = S_MARS; i <= S_BH; i++) {
        float b = SCENE_START[i];
        w = max(w, (1.0 - remap(t, b, b + 1.2)) * step(b, t));
    }
    return w * w;
}

float warpFlash(float t) {
    float f = 0.0;
    for (int i = S_MARS; i <= S_BH; i++) {
        float d = (t - SCENE_START[i]) / 0.45;
        f = max(f, exp(-d * d));
    }
    return f;
}

float impactFlash(float t) {
    return 0.45 * pulse(t, 224.5, 6.0) + 0.25 * pulse(t, 398.4, 6.0) + 0.3 * pulse(t, 517.4, 3.0) + 1.2 * pulse(t, 764.2, 1.6) + 0.5 * pulse(t, 902.2, 3.0);
}

// 허탕 카운트다운(n044): 5·4·3·2·1 동안 흔들림·경보가 커지다 침묵(673.38~675.18)에서 뚝 멈춘다
float fakeout(float t) {
    return remap(t, FAKEOUT_T0, FAKEOUT_T1) * step(t, FAKEOUT_T1);
}

float shakeAmount(float t) {
    float s = 0.35 * pulse(t, 211.5, 3.0) + 1.0 * pulse(t, 224.5, 1.8) + 0.5 * pulse(t, 234.5, 3.0)
            + 0.9 * pulse(t, 398.4, 2.0) + 0.8 * pulse(t, 517.4, 1.2) + 1.0 * pulse(t, 764.2, 1.5) + 1.0 * pulse(t, 902.2, 1.0);
    s += 0.22 * window(t, 390.4, 404.4, 1.0, 1.5);
    s += 0.35 * window(t, 517.4, 527.4, 0.5, 2.0);
    s += 0.6 * remap(t, 842.2, 953.9) * step(t, 955.9);
    s += 0.14 * window(t, 959.9, 1017.9, 2.0, 1.0) + 0.5 * window(t, 1011.9, 1018.9, 5.0, 0.5);
    s += 0.12 * max(warpOut(t), warpIn(t));
    s += 0.55 * pow(fakeout(t), 1.6);
    return s;
}

float alarmOn(float t) {
    float a = max(max(window(t, 224.5, 239.5, 0.1, 1.0), window(t, 398.4, 410.4, 0.1, 1.0)),
                  max(window(t, 517.4, 531.4, 0.1, 1.0), window(t, 842.2, 955.9, 0.5, 0.5)));
    return max(a, step(0.001, fakeout(t)));
}

// 1 = 정상, 0 = 꺼짐. 622 이후 비상 전원
float powerLevel(float t) {
    float p = 1.0;
    p -= window(t, 517.4, 527.4, 0.1, 1.0) * step(0.55, hash11(floor(t * 14.0)));
    p = t >= 764.2 && t < 955.9 ? 0.0 : p;
    return sat(p);
}

float emergencyOn(float t) {
    return step(764.2, t) * step(t, 955.9);
}

float glitchAmount(float t) {
    float g = window(t, 517.4, 527.4, 0.2, 2.0) * (0.4 + 0.6 * step(0.6, hash11(floor(t * 9.0))));
    g += pulse(t, 764.2, 2.5);
    g += window(t, 902.2, 955.9, 1.0, 0.5) * step(0.7, hash11(floor(t * 6.0)));
    return sat(g);
}

// 검정으로 덮는 양(1 = 완전 검정)
float blackout(float t) {
    if (t >= T_IDLE) {
        return 0.0;
    }
    float b = 1.0 - remap(t, 3.0, 10.0);
    b = max(b, remap(t, 951.9, 955.9) * (1.0 - remap(t, 956.9, 960.4)));
    return max(b, remap(t, 1016.9, 1021.4));
}

float engineLevel(float t) {
    float e = 1.0 + 1.6 * max(warpOut(t), warpIn(t));
    e = t >= 764.2 ? e * (0.6 + 0.4 * step(0.25, hash11(floor(t * 8.0)))) : e;
    e = t >= 842.2 ? 2.2 : e;
    e = t >= 902.2 ? 0.0 : e;
    e = t >= 955.9 ? 1.4 + 0.3 * sin(t * 2.3) : e;
    return e;
}

vec3 bez3(vec3 a, vec3 b, vec3 c, vec3 d, float s) {
    float u = 1.0 - s;
    return u * u * u * a + 3.0 * u * u * s * b + 3.0 * u * s * s * c + s * s * s * d;
}

struct Rig {
    int scene;
    float t;
    float lt;
    vec3 pos;
    mat3 basis;
    vec3 sunDir;
    float zoom;
};

// 장면 2~8 은 워프 직후 7.5초 도입 샷: 천체 가까이 빠르게 돌다 줌아웃하며 우주선 뒤 시점으로 돌아온다.
// 우주선은 6초까지 숨었다가 뒤에서 날아들어 7.5초에 자리 잡는다(아이템 셰이더).
const float INTRO_LEN = 7.5;
const float SHIP_FLYIN = 6.0;
const float BH_INTRO_LEN = 16.0;

float introLen(int scene) {
    return scene == S_BH ? BH_INTRO_LEN : INTRO_LEN;
}

bool hasIntro(int scene) {
    return scene >= S_MARS && scene <= S_BH;
}

// --- 장면별 카메라 ---------------------------------------------------------

const float EARTH_R_ORBIT = 1.07;
const float EARTH_OMEGA = 0.020;

vec3 earthOrbit(float t) {
    float th = EARTH_OMEGA * t;
    return EARTH_R_ORBIT * vec3(sin(th), cos(th), 0.0);
}

vec3 earthSunDir() {
    return normalize(vec3(cos(0.862), -sin(0.862), 0.30));
}

// 55초부터 지구를 바라본 채 해 쪽으로 물러나며 상승, 달이 앞을 스쳐 지나간다
vec3 earthUp55() {
    return normalize(earthOrbit(55.0));
}

vec3 earthSide() {
    return normalize(cross(earthSunDir(), earthUp55()));
}

const float MOON_R = 0.273;
#define MOON_POS (earthUp55() * 2.05 + earthSunDir() * 3.1 + earthSide() * 0.62)

vec3 earthDepart(float lt) {
    float k = smoother01(remap(lt, 55.0, 124.0));
    float d = 7.0 * k * k * (1.6 - 0.6 * k);
    float r = mix(1.07, 2.5, smoother01(remap(lt, 55.0, 100.0)));
    return earthUp55() * r + earthSunDir() * d;
}

void rigEarth(float lt, inout Rig rig) {
    vec3 pos = lt < 55.0 ? earthOrbit(lt) : earthDepart(lt);
    float th = EARTH_OMEGA * min(lt, 55.0);
    vec3 orbitFwd = normalize(vec3(cos(th), -sin(th), 0.0) - 0.20 * normalize(earthOrbit(lt)));
    vec3 toEarth = normalize(-pos);
    vec3 toMoon = normalize(MOON_POS - pos);
    toEarth = normalize(mix(toEarth, toMoon, 0.55 * window(lt, 80.0, 104.0, 8.0, 8.0)));
    vec3 deep = normalize(earthSide() * 0.8 + earthSunDir() * 0.6 + earthUp55() * 0.3);
    vec3 fwd = normalize(mix(orbitFwd, toEarth, smoother01(remap(lt, 56.0, 72.0))));
    fwd = normalize(mix(fwd, deep, smoother01(remap(lt, 108.0, 122.0))));
    vec3 upHint = normalize(mix(normalize(pos), earthUp55(), smoother01(remap(lt, 55.0, 70.0))));
    upHint = normalize(upHint - fwd * dot(upHint, fwd) + 1e-4);
    rig.pos = pos;
    rig.basis = basisFrom(fwd, upHint);
    rig.sunDir = earthSunDir();
}

// 화성: 반지름 1, 원점. 낮 쪽에서 비스듬히 다가가며 천천히 돌고, 화성은 화면 왼쪽에(오른쪽 패널 자리 비움)
const vec3 MARS_SUN = normalize(vec3(-0.3, 0.3, 0.9));
void rigMars(float lt, inout Rig rig) {
    float s = smoother01(lt / 43.5);
    float a = mix(0.35, 0.95, s);
    float r = mix(3.4, 2.6, s);
    vec3 pos = vec3(r * sin(a), 0.35 - 0.15 * s, r * cos(a));
    vec3 toMars = normalize(-pos);
    vec3 side = normalize(cross(toMars, vec3(0.0, 1.0, 0.0)));
    rig.pos = pos;
    rig.basis = basisFrom(normalize(toMars + side * 0.45), vec3(0.0, 1.0, 0.0));
    rig.sunDir = MARS_SUN;
}

// 소행성대: 가상 z 축을 따라 전진(초당 28)
const vec3 BELT_SUN = normalize(vec3(-0.55, 0.25, 0.80));
void rigBelt(float lt, inout Rig rig) {
    float z = -28.0 * lt - 4.0 * lt * lt / 80.0;
    vec3 pos = vec3(6.0 * sin(lt * 0.05), 3.0 * sin(lt * 0.031), z);
    vec3 fwd = normalize(vec3(0.20 * cos(lt * 0.05), 0.08 * cos(lt * 0.031), -1.0));
    float roll = 0.12 * sin(lt * 0.07);
    rig.pos = pos;
    rig.basis = basisFrom(fwd, normalize(vec3(sin(roll), cos(roll), 0.0)));
    rig.sunDir = BELT_SUN;
}

// 목성: 반지름 1, 중심 원점
const vec3 JUP_SUN = normalize(vec3(1.0, 0.18, 0.35));
const vec3 IO_POS = vec3(2.3, 0.25, 1.4);
const float IO_R = 0.026;
void rigJupiter(float lt, inout Rig rig) {
    float s = smoother01(lt / 90.0) + 0.002 * max(lt - 84.0, 0.0);
    vec3 pos = bez3(vec3(-2.2, 0.2, 4.6), vec3(-0.6, -0.4, 3.4), vec3(1.0, -0.5, 2.3), vec3(1.25, -0.1, 0.75), s);
    vec3 look = mix(vec3(0.0, -0.2, 0.0), vec3(-0.3, -0.25, -0.5), smoother01(remap(lt, 44.0, 88.0)));
    vec3 fwd = normalize(look - pos);
    rig.pos = pos;
    rig.basis = basisFrom(fwd, normalize(vec3(0.15, 1.0, 0.0)));
    rig.sunDir = JUP_SUN;
}

// 토성: 반지름 1, 고리 평면 = y 0. 352~366 고리면 통과
const vec3 SAT_SUN = normalize(vec3(-0.75, 0.32, 0.55));
void rigSaturn(float lt0, inout Rig rig) {
    // 대사를 줄여 고리 통과(원래 장면 60초)를 49초로 앞당김 → 경로 전체를 같은 비율로 압축
    float lt = lt0 * (60.0 / 49.0);
    float a = mix(-0.9, 0.55, smoother01(lt / 90.0));
    float r = mix(5.0, 2.45, smoother01(lt / 70.0));
    float y = mix(1.1, 0.30, smoother01(lt / 52.0));
    y = mix(y, -0.55, smoother01(remap(lt, 50.0, 70.0)));
    vec3 pos = vec3(r * sin(a), y, r * cos(a));
    vec3 look = vec3(0.0, mix(0.0, 0.2, smoother01(remap(lt, 55.0, 80.0))), 0.0);
    vec3 fwd = normalize(normalize(look - pos) + vec3(0.0, 0.0, 0.0));
    fwd = normalize(mix(fwd, normalize(vec3(-cos(a), 0.05, sin(a))), 0.35 * window(lt, 46.0, 70.0, 4.0, 4.0)));
    rig.pos = pos;
    rig.basis = basisFrom(fwd, vec3(0.0, 1.0, 0.0));
    rig.sunDir = SAT_SUN;
}

// 태양: 반지름 1
const vec3 SUN_VIEW_DIR = normalize(vec3(0.0, 0.0, -1.0));
void rigSun(float lt, inout Rig rig) {
    float s = smoother01(lt / 105.0) + 0.0012 * max(lt - 98.0, 0.0);
    vec3 pos = bez3(vec3(-0.9, 0.7, 3.8), vec3(-0.3, 0.5, 2.9), vec3(0.6, 0.35, 2.2), vec3(1.2, 0.2, 1.6), s);
    vec3 look = mix(vec3(0.0), vec3(-0.85, 0.35, 0.0), smoother01(remap(lt, 30.0, 70.0)));
    rig.pos = pos;
    rig.basis = basisFrom(normalize(look - pos), vec3(0.0, 1.0, 0.0));
    rig.sunDir = normalize(-pos);
}

// 베텔게우스: 반지름 1
void rigBetel(float lt, inout Rig rig) {
    float s = smoother01(lt / 72.0);
    vec3 pos = bez3(vec3(1.5, 0.5, 4.2), vec3(0.7, 0.4, 3.6), vec3(-0.5, 0.25, 3.0), vec3(-1.2, 0.12, 2.5), s);
    rig.pos = pos;
    rig.basis = basisFrom(normalize(vec3(0.25, 0.0, 0.0) - pos), vec3(0.0, 1.0, 0.0));
    rig.sunDir = normalize(-pos);
}

// 펄사: 중성자별 반지름 0.02, 원점
void rigPulsar(float lt, inout Rig rig) {
    float a = 0.6 + lt * 0.006;
    float r = mix(7.0, 2.4, smoother01(lt / 60.0));
    vec3 pos = vec3(r * sin(a), 0.8 - lt * 0.004, r * cos(a));
    rig.pos = pos;
    rig.basis = basisFrom(normalize(vec3(0.12, 0.0, 0.0) - pos), vec3(0.0, 1.0, 0.0));
    rig.sunDir = normalize(-pos);
}

// 블랙홀: 질량 1(슈바르츠실트 반지름 2), 원반 평면 y 0
float bhRadius(float lt) {
    float r = mix(110.0, 34.0, smoother01(lt / 50.0));
    r = mix(r, 13.0, smoother01(remap(lt, 50.0, 110.0)));
    r = mix(r, 2.6, smoother01(remap(lt, 110.0, 181.5)));
    return r;
}

void rigBlackHole(float lt, inout Rig rig) {
    float r = bhRadius(lt);
    float a = 0.4 + lt * 0.010 + 0.8 * smoother01(remap(lt, 90.0, 181.5));
    float elev = mix(0.16, 0.08, smoother01(lt / 120.0));
    vec3 pos = r * vec3(sin(a) * cos(elev), sin(elev), cos(a) * cos(elev));
    vec3 fwd = normalize(-pos + vec3(0.0, -0.02 * r, 0.0));
    float roll = 0.15 * sin(lt * 0.05) + 0.4 * smoother01(remap(lt, 100.0, 183.5));
    vec3 up = normalize(vec3(sin(roll), cos(roll), 0.0));
    rig.pos = pos;
    rig.basis = basisFrom(fwd, up);
    rig.sunDir = normalize(-pos);
}

// 블랙홀 내부: 격자 간격 INSIDE_CELL, 기둥은 격자선 위. 카메라는 칸 가운데를 잇는 경로(tools/paths)를 따라 꺾으며 난다
const float INSIDE_CELL = 8.0;
#ifndef BH_INSIDE_PATH_GLSL
#define BH_INSIDE_PATH_GLSL

// tools/paths/build_inside_path.py 가 만든다(손으로 고치지 말 것)
const int INSIDE_N = 152;
const vec4 INSIDE_WP[152] = vec4[](
    vec4(4.0, 4.0, 4.0, 0.000),
    vec4(4.0, 4.0, -4.0, 0.800),
    vec4(4.0, 4.0, -12.0, 1.559),
    vec4(4.0, 4.0, -20.0, 2.284),
    vec4(4.0, 4.0, -28.0, 2.978),
    vec4(4.0, 4.0, -36.0, 3.646),
    vec4(12.0, 4.0, -36.0, 4.289),
    vec4(20.0, 4.0, -36.0, 4.912),
    vec4(28.0, 4.0, -36.0, 5.514),
    vec4(28.0, 4.0, -44.0, 6.099),
    vec4(28.0, 4.0, -52.0, 6.667),
    vec4(28.0, 4.0, -60.0, 7.216),
    vec4(28.0, 4.0, -68.0, 7.747),
    vec4(28.0, 4.0, -76.0, 8.262),
    vec4(28.0, 12.0, -76.0, 8.763),
    vec4(28.0, 20.0, -76.0, 9.250),
    vec4(28.0, 28.0, -76.0, 9.725),
    vec4(28.0, 36.0, -76.0, 10.188),
    vec4(28.0, 44.0, -76.0, 10.641),
    vec4(28.0, 52.0, -76.0, 11.084),
    vec4(28.0, 52.0, -84.0, 11.518),
    vec4(28.0, 52.0, -92.0, 11.943),
    vec4(28.0, 52.0, -100.0, 12.359),
    vec4(20.0, 52.0, -100.0, 12.768),
    vec4(12.0, 52.0, -100.0, 13.170),
    vec4(4.0, 52.0, -100.0, 13.564),
    vec4(-4.0, 52.0, -100.0, 13.952),
    vec4(-12.0, 52.0, -100.0, 14.334),
    vec4(-20.0, 52.0, -100.0, 14.715),
    vec4(-28.0, 52.0, -100.0, 15.095),
    vec4(-28.0, 52.0, -108.0, 15.475),
    vec4(-28.0, 52.0, -116.0, 15.854),
    vec4(-28.0, 52.0, -124.0, 16.233),
    vec4(-28.0, 52.0, -132.0, 16.612),
    vec4(-28.0, 52.0, -140.0, 16.990),
    vec4(-20.0, 52.0, -140.0, 17.368),
    vec4(-12.0, 52.0, -140.0, 17.745),
    vec4(-4.0, 52.0, -140.0, 18.122),
    vec4(4.0, 52.0, -140.0, 18.499),
    vec4(12.0, 52.0, -140.0, 18.875),
    vec4(20.0, 52.0, -140.0, 19.251),
    vec4(20.0, 44.0, -140.0, 19.626),
    vec4(20.0, 36.0, -140.0, 20.001),
    vec4(20.0, 28.0, -140.0, 20.376),
    vec4(20.0, 20.0, -140.0, 20.750),
    vec4(20.0, 12.0, -140.0, 21.124),
    vec4(20.0, 4.0, -140.0, 21.497),
    vec4(20.0, -4.0, -140.0, 21.871),
    vec4(20.0, -4.0, -148.0, 22.243),
    vec4(20.0, -4.0, -156.0, 22.616),
    vec4(20.0, -4.0, -164.0, 22.988),
    vec4(20.0, -4.0, -172.0, 23.359),
    vec4(12.0, -4.0, -172.0, 23.730),
    vec4(4.0, -4.0, -172.0, 24.101),
    vec4(-4.0, -4.0, -172.0, 24.472),
    vec4(-12.0, -4.0, -172.0, 24.842),
    vec4(-20.0, -4.0, -172.0, 25.212),
    vec4(-28.0, -4.0, -172.0, 25.581),
    vec4(-28.0, -4.0, -180.0, 25.950),
    vec4(-28.0, -4.0, -188.0, 26.319),
    vec4(-28.0, -4.0, -196.0, 26.687),
    vec4(-28.0, -4.0, -204.0, 27.055),
    vec4(-28.0, -4.0, -212.0, 27.422),
    vec4(-28.0, -4.0, -220.0, 27.789),
    vec4(-28.0, -4.0, -228.0, 28.156),
    vec4(-20.0, -4.0, -228.0, 28.523),
    vec4(-12.0, -4.0, -228.0, 28.889),
    vec4(-4.0, -4.0, -228.0, 29.254),
    vec4(4.0, -4.0, -228.0, 29.620),
    vec4(4.0, -12.0, -228.0, 29.985),
    vec4(4.0, -20.0, -228.0, 30.349),
    vec4(4.0, -28.0, -228.0, 30.714),
    vec4(4.0, -36.0, -228.0, 31.077),
    vec4(4.0, -44.0, -228.0, 31.441),
    vec4(12.0, -44.0, -228.0, 31.804),
    vec4(20.0, -44.0, -228.0, 32.167),
    vec4(28.0, -44.0, -228.0, 32.530),
    vec4(36.0, -44.0, -228.0, 32.892),
    vec4(44.0, -44.0, -228.0, 33.254),
    vec4(52.0, -44.0, -228.0, 33.615),
    vec4(60.0, -44.0, -228.0, 33.976),
    vec4(60.0, -36.0, -228.0, 34.337),
    vec4(60.0, -28.0, -228.0, 34.697),
    vec4(60.0, -20.0, -228.0, 35.057),
    vec4(60.0, -20.0, -236.0, 35.417),
    vec4(60.0, -20.0, -244.0, 35.776),
    vec4(60.0, -20.0, -252.0, 36.136),
    vec4(60.0, -20.0, -260.0, 36.494),
    vec4(60.0, -28.0, -260.0, 36.853),
    vec4(60.0, -36.0, -260.0, 37.211),
    vec4(60.0, -44.0, -260.0, 37.568),
    vec4(60.0, -52.0, -260.0, 37.926),
    vec4(60.0, -60.0, -260.0, 38.283),
    vec4(60.0, -60.0, -268.0, 38.639),
    vec4(60.0, -60.0, -276.0, 38.996),
    vec4(60.0, -60.0, -284.0, 39.352),
    vec4(60.0, -60.0, -292.0, 39.707),
    vec4(60.0, -60.0, -300.0, 40.063),
    vec4(60.0, -60.0, -308.0, 40.418),
    vec4(60.0, -60.0, -316.0, 40.773),
    vec4(60.0, -52.0, -316.0, 41.127),
    vec4(60.0, -44.0, -316.0, 41.481),
    vec4(60.0, -36.0, -316.0, 41.835),
    vec4(60.0, -28.0, -316.0, 42.188),
    vec4(60.0, -20.0, -316.0, 42.541),
    vec4(60.0, -12.0, -316.0, 42.894),
    vec4(60.0, -12.0, -324.0, 43.246),
    vec4(60.0, -12.0, -332.0, 43.598),
    vec4(60.0, -12.0, -340.0, 43.950),
    vec4(60.0, -12.0, -348.0, 44.302),
    vec4(60.0, -12.0, -356.0, 44.653),
    vec4(60.0, -12.0, -364.0, 45.004),
    vec4(60.0, -12.0, -372.0, 45.354),
    vec4(60.0, -20.0, -372.0, 45.704),
    vec4(60.0, -28.0, -372.0, 46.054),
    vec4(60.0, -36.0, -372.0, 46.404),
    vec4(60.0, -44.0, -372.0, 46.753),
    vec4(60.0, -52.0, -372.0, 47.102),
    vec4(60.0, -60.0, -372.0, 47.451),
    vec4(60.0, -68.0, -372.0, 47.799),
    vec4(60.0, -68.0, -380.0, 48.147),
    vec4(60.0, -68.0, -388.0, 48.497),
    vec4(60.0, -68.0, -396.0, 48.853),
    vec4(60.0, -60.0, -396.0, 49.214),
    vec4(60.0, -52.0, -396.0, 49.581),
    vec4(60.0, -44.0, -396.0, 49.955),
    vec4(60.0, -36.0, -396.0, 50.335),
    vec4(60.0, -36.0, -404.0, 50.722),
    vec4(60.0, -36.0, -412.0, 51.116),
    vec4(60.0, -36.0, -420.0, 51.519),
    vec4(60.0, -36.0, -428.0, 51.929),
    vec4(60.0, -36.0, -436.0, 52.349),
    vec4(60.0, -36.0, -444.0, 52.778),
    vec4(60.0, -36.0, -452.0, 53.217),
    vec4(60.0, -44.0, -452.0, 53.667),
    vec4(60.0, -52.0, -452.0, 54.128),
    vec4(60.0, -60.0, -452.0, 54.602),
    vec4(60.0, -68.0, -452.0, 55.090),
    vec4(60.0, -68.0, -460.0, 55.593),
    vec4(60.0, -68.0, -468.0, 56.112),
    vec4(60.0, -68.0, -476.0, 56.648),
    vec4(60.0, -68.0, -484.0, 57.195),
    vec4(60.0, -68.0, -492.0, 57.753),
    vec4(60.0, -76.0, -492.0, 58.325),
    vec4(60.0, -84.0, -492.0, 58.910),
    vec4(60.0, -92.0, -492.0, 59.510),
    vec4(60.0, -100.0, -492.0, 60.126),
    vec4(60.0, -108.0, -492.0, 60.758),
    vec4(60.0, -116.0, -492.0, 61.410),
    vec4(60.0, -116.0, -500.0, 62.082),
    vec4(60.0, -116.0, -508.0, 62.776),
    vec4(60.0, -116.0, -516.0, 63.495)
);
const vec4 INSIDE_UP[152] = vec4[](
    vec4(0.0000, 1.0000, 0.0000, 0.0000),
    vec4(0.0000, 1.0000, 0.0000, 0.0000),
    vec4(0.0000, 1.0000, 0.0000, 0.1273),
    vec4(0.0000, 1.0000, 0.0000, 0.3073),
    vec4(0.0000, 1.0000, 0.0000, 0.4346),
    vec4(0.0000, 1.0000, 0.0000, 0.3073),
    vec4(0.0000, 1.0000, 0.0000, 0.1273),
    vec4(0.0000, 1.0000, 0.0000, -0.1273),
    vec4(0.0000, 1.0000, 0.0000, -0.3073),
    vec4(0.0000, 1.0000, 0.0000, -0.4346),
    vec4(0.0000, 1.0000, 0.0000, -0.3073),
    vec4(0.0000, 1.0000, 0.0000, -0.1273),
    vec4(0.0000, 1.0000, 0.0000, 0.0000),
    vec4(0.0000, 0.7071, 0.7071, 0.0000),
    vec4(0.0000, 0.0000, 1.0000, 0.0000),
    vec4(0.0000, 0.0000, 1.0000, 0.0000),
    vec4(0.0000, 0.0000, 1.0000, 0.0000),
    vec4(0.0000, 0.0000, 1.0000, 0.0000),
    vec4(0.0000, 0.0000, 1.0000, 0.0000),
    vec4(0.0000, 0.7071, 0.7071, -0.1273),
    vec4(0.0000, 1.0000, 0.0000, -0.3073),
    vec4(0.0000, 1.0000, 0.0000, -0.4346),
    vec4(0.0000, 1.0000, 0.0000, -0.4346),
    vec4(0.0000, 1.0000, 0.0000, -0.4346),
    vec4(0.0000, 1.0000, 0.0000, -0.3073),
    vec4(0.0000, 1.0000, 0.0000, -0.1273),
    vec4(0.0000, 1.0000, 0.0000, 0.1273),
    vec4(0.0000, 1.0000, 0.0000, 0.3073),
    vec4(0.0000, 1.0000, 0.0000, 0.4346),
    vec4(0.0000, 1.0000, 0.0000, 0.4346),
    vec4(0.0000, 1.0000, 0.0000, 0.4346),
    vec4(0.0000, 1.0000, 0.0000, 0.4346),
    vec4(0.0000, 1.0000, 0.0000, 0.4346),
    vec4(0.0000, 1.0000, 0.0000, 0.4346),
    vec4(0.0000, 1.0000, 0.0000, 0.4346),
    vec4(0.0000, 1.0000, 0.0000, 0.4346),
    vec4(0.0000, 1.0000, 0.0000, 0.3073),
    vec4(0.0000, 1.0000, 0.0000, 0.1273),
    vec4(0.0000, 1.0000, 0.0000, 0.0000),
    vec4(0.0000, 1.0000, 0.0000, 0.0000),
    vec4(0.7071, 0.7071, 0.0000, 0.0000),
    vec4(1.0000, 0.0000, 0.0000, 0.0000),
    vec4(1.0000, 0.0000, 0.0000, 0.0000),
    vec4(1.0000, 0.0000, 0.0000, 0.0000),
    vec4(1.0000, 0.0000, 0.0000, -0.1273),
    vec4(1.0000, 0.0000, 0.0000, -0.3073),
    vec4(1.0000, 0.0000, 0.0000, -0.4346),
    vec4(1.0000, 0.0000, 0.0000, -0.4346),
    vec4(1.0000, 0.0000, 0.0000, -0.4346),
    vec4(1.0000, 0.0000, 0.0000, -0.3073),
    vec4(1.0000, 0.0000, 0.0000, -0.1273),
    vec4(0.7071, 0.0000, -0.7071, 0.0000),
    vec4(0.0000, 0.0000, -1.0000, 0.0000),
    vec4(0.0000, 0.0000, -1.0000, 0.0000),
    vec4(0.0000, 0.0000, -1.0000, 0.0000),
    vec4(0.0000, 0.0000, -1.0000, 0.0000),
    vec4(0.0000, 0.0000, -1.0000, 0.0000),
    vec4(0.7071, 0.0000, -0.7071, 0.0000),
    vec4(1.0000, 0.0000, 0.0000, 0.0000),
    vec4(1.0000, 0.0000, 0.0000, 0.0000),
    vec4(1.0000, 0.0000, 0.0000, 0.0000),
    vec4(1.0000, 0.0000, 0.0000, 0.0000),
    vec4(1.0000, 0.0000, 0.0000, 0.0000),
    vec4(1.0000, 0.0000, 0.0000, 0.0000),
    vec4(0.7071, 0.0000, 0.7071, 0.0000),
    vec4(0.0000, 0.0000, 1.0000, 0.1273),
    vec4(0.0000, 0.0000, 1.0000, 0.3073),
    vec4(0.0000, 0.0000, 1.0000, 0.4346),
    vec4(0.0000, 0.0000, 1.0000, 0.4346),
    vec4(0.0000, 0.0000, 1.0000, 0.4346),
    vec4(0.0000, 0.0000, 1.0000, 0.1800),
    vec4(0.0000, 0.0000, 1.0000, -0.1800),
    vec4(0.0000, 0.0000, 1.0000, -0.4346),
    vec4(0.0000, 0.0000, 1.0000, -0.4346),
    vec4(0.0000, 0.0000, 1.0000, -0.4346),
    vec4(0.0000, 0.0000, 1.0000, -0.3073),
    vec4(0.0000, 0.0000, 1.0000, -0.1273),
    vec4(0.0000, 0.0000, 1.0000, -0.1273),
    vec4(0.0000, 0.0000, 1.0000, -0.3073),
    vec4(0.0000, 0.0000, 1.0000, -0.4346),
    vec4(0.0000, 0.0000, 1.0000, -0.4346),
    vec4(0.0000, 0.0000, 1.0000, -0.4346),
    vec4(0.0000, 0.0000, 1.0000, -0.3073),
    vec4(0.0000, 0.7071, 0.7071, -0.1273),
    vec4(0.0000, 1.0000, 0.0000, 0.0000),
    vec4(0.0000, 1.0000, 0.0000, 0.0000),
    vec4(0.0000, 1.0000, 0.0000, 0.0000),
    vec4(0.0000, 0.7071, -0.7071, 0.0000),
    vec4(0.0000, 0.0000, -1.0000, 0.0000),
    vec4(0.0000, 0.0000, -1.0000, 0.0000),
    vec4(0.0000, 0.0000, -1.0000, 0.0000),
    vec4(0.0000, 0.0000, -1.0000, 0.0000),
    vec4(0.0000, 0.7071, -0.7071, 0.0000),
    vec4(0.0000, 1.0000, 0.0000, 0.0000),
    vec4(0.0000, 1.0000, 0.0000, 0.0000),
    vec4(0.0000, 1.0000, 0.0000, 0.0000),
    vec4(0.0000, 1.0000, 0.0000, 0.0000),
    vec4(0.0000, 1.0000, 0.0000, 0.0000),
    vec4(0.0000, 1.0000, 0.0000, 0.0000),
    vec4(0.0000, 0.7071, 0.7071, 0.0000),
    vec4(0.0000, 0.0000, 1.0000, 0.0000),
    vec4(0.0000, 0.0000, 1.0000, 0.0000),
    vec4(0.0000, 0.0000, 1.0000, 0.0000),
    vec4(0.0000, 0.0000, 1.0000, 0.0000),
    vec4(0.0000, 0.0000, 1.0000, 0.0000),
    vec4(0.0000, 0.7071, 0.7071, 0.0000),
    vec4(0.0000, 1.0000, 0.0000, 0.0000),
    vec4(0.0000, 1.0000, 0.0000, 0.0000),
    vec4(0.0000, 1.0000, 0.0000, 0.0000),
    vec4(0.0000, 1.0000, 0.0000, 0.0000),
    vec4(0.0000, 1.0000, 0.0000, 0.0000),
    vec4(0.0000, 1.0000, 0.0000, 0.0000),
    vec4(0.0000, 0.7071, -0.7071, 0.0000),
    vec4(0.0000, 0.0000, -1.0000, 0.0000),
    vec4(0.0000, 0.0000, -1.0000, 0.0000),
    vec4(0.0000, 0.0000, -1.0000, 0.0000),
    vec4(0.0000, 0.0000, -1.0000, 0.0000),
    vec4(0.0000, 0.0000, -1.0000, 0.0000),
    vec4(0.0000, 0.0000, -1.0000, 0.0000),
    vec4(0.0000, 0.7071, -0.7071, 0.0000),
    vec4(0.0000, 1.0000, 0.0000, 0.0000),
    vec4(0.0000, 1.0000, 0.0000, 0.0000),
    vec4(0.0000, 0.7071, 0.7071, 0.0000),
    vec4(0.0000, 0.0000, 1.0000, 0.0000),
    vec4(0.0000, 0.0000, 1.0000, 0.0000),
    vec4(0.0000, 0.0000, 1.0000, 0.0000),
    vec4(0.0000, 0.7071, 0.7071, 0.0000),
    vec4(0.0000, 1.0000, 0.0000, 0.0000),
    vec4(0.0000, 1.0000, 0.0000, 0.0000),
    vec4(0.0000, 1.0000, 0.0000, 0.0000),
    vec4(0.0000, 1.0000, 0.0000, 0.0000),
    vec4(0.0000, 1.0000, 0.0000, 0.0000),
    vec4(0.0000, 1.0000, 0.0000, 0.0000),
    vec4(0.0000, 0.7071, -0.7071, 0.0000),
    vec4(0.0000, 0.0000, -1.0000, 0.0000),
    vec4(0.0000, 0.0000, -1.0000, 0.0000),
    vec4(0.0000, 0.0000, -1.0000, 0.0000),
    vec4(0.0000, 0.7071, -0.7071, 0.0000),
    vec4(0.0000, 1.0000, 0.0000, 0.0000),
    vec4(0.0000, 1.0000, 0.0000, 0.0000),
    vec4(0.0000, 1.0000, 0.0000, 0.0000),
    vec4(0.0000, 1.0000, 0.0000, 0.0000),
    vec4(0.0000, 0.7071, -0.7071, 0.0000),
    vec4(0.0000, 0.0000, -1.0000, 0.0000),
    vec4(0.0000, 0.0000, -1.0000, 0.0000),
    vec4(0.0000, 0.0000, -1.0000, 0.0000),
    vec4(0.0000, 0.0000, -1.0000, 0.0000),
    vec4(0.0000, 0.0000, -1.0000, 0.0000),
    vec4(0.0000, 0.7071, -0.7071, 0.0000),
    vec4(0.0000, 1.0000, 0.0000, 0.0000),
    vec4(0.0000, 1.0000, 0.0000, 0.0000),
    vec4(0.0000, 1.0000, 0.0000, 0.0000)
);
const vec3 INSIDE_SPHERE = vec3(60.0, -116.0, -562.0);

#endif

void insidePath(float lt, out vec3 pos, out vec3 fwd, out vec3 up, out float roll) {
    int lo = 0;
    int hi = INSIDE_N - 2;
    for (int k = 0; k < 9; k++) {
        int mid = (lo + hi + 1) / 2;
        if (INSIDE_WP[mid].w <= lt) {
            lo = mid;
        } else {
            hi = mid - 1;
        }
    }
    int i = clamp(lo, 0, INSIDE_N - 2);
    vec3 p0 = INSIDE_WP[max(i - 1, 0)].xyz;
    vec3 p1 = INSIDE_WP[i].xyz;
    vec3 p2 = INSIDE_WP[i + 1].xyz;
    vec3 p3 = INSIDE_WP[min(i + 2, INSIDE_N - 1)].xyz;
    float span = INSIDE_WP[i + 1].w - INSIDE_WP[i].w;
    float over = max(lt - INSIDE_WP[INSIDE_N - 1].w, 0.0);
    float u = clamp((lt - INSIDE_WP[i].w) / span, 0.0, 1.0);
    vec3 a = -p0 + p2;
    vec3 b = 2.0 * p0 - 5.0 * p1 + 4.0 * p2 - p3;
    vec3 c = -p0 + 3.0 * p1 - 3.0 * p2 + p3;
    pos = 0.5 * (2.0 * p1 + a * u + b * u * u + c * u * u * u);
    fwd = normalize(0.5 * (a + 2.0 * b * u + 3.0 * c * u * u));
    pos += fwd * over * 11.0;
    up = normalize(mix(INSIDE_UP[i].xyz, INSIDE_UP[i + 1].xyz, u));
    roll = mix(INSIDE_UP[i].w, INSIDE_UP[i + 1].w, u);
}

void rigInside(float lt, inout Rig rig) {
    vec3 pos;
    vec3 fwd;
    vec3 up;
    float roll;
    insidePath(lt, pos, fwd, up, roll);
    rig.pos = pos;
    rig.basis = basisFrom(fwd, rotAxis(fwd, roll) * up);
    rig.sunDir = normalize(vec3(0.3, 0.8, -0.4));
}

void rigIdle(float lt, inout Rig rig) {
    rig.pos = vec3(0.0);
    rig.basis = basisFrom(normalize(vec3(sin(lt * 0.004), 0.05, -1.0)), vec3(0.0, 1.0, 0.0));
    rig.sunDir = normalize(vec3(0.3, 0.9, 0.25));   // 로비(한낮 야외): 해는 위에서
}

// 도입 샷 궤도: (반지름, 높이, 시작 각, 끝 각)
vec4 introOrbit(int scene) {
    if (scene == S_MARS) {
        return vec4(1.9, 0.22, -0.9, 0.35);
    }
    if (scene == S_JUPITER) {
        return vec4(1.45, 0.25, 1.4, -0.3);
    }
    if (scene == S_SATURN) {
        return vec4(2.6, 0.45, -2.2, -0.6);
    }
    if (scene == S_SUN) {
        return vec4(1.35, 0.2, 2.2, 0.8);
    }
    if (scene == S_BETEL) {
        return vec4(1.6, 0.3, -0.4, 1.2);
    }
    if (scene == S_PULSAR) {
        return vec4(0.9, 0.25, 0.0, 1.8);
    }
    return vec4(18.0, 2.2, 2.3, 5.6);
}

void applyIntro(inout Rig rig) {
    float lt = rig.lt;
    float len = introLen(rig.scene);
    float s = sat(lt / len);
    float e = smoother01(remap(lt, len - 4.0, len));
    vec3 pos;
    vec3 fwd;
    vec3 up = vec3(0.0, 1.0, 0.0);
    if (rig.scene == S_BH) {
        // 위에서 내려다보다 원반 바로 위로 내려와 스치듯 돌고(원반 흐름과 반대 방향), 본 경로와 같은 방향에서 끝난다(이후엔 뒤로 물러나기만)
        float aEnd = atan(rig.pos.x, rig.pos.z) + TAU;
        float a = mix(aEnd - 4.5, aEnd, smoother01(s));
        float dive = smoother01(min(s * 2.6, 1.0));
        float el = mix(0.72, 0.028, dive);
        float r = mix(26.0, 18.0, dive);
        pos = r * vec3(sin(a) * cos(el), sin(el), cos(a) * cos(el));
        fwd = normalize(-pos + vec3(cos(a), 0.0, -sin(a)) * mix(4.0, 8.0, dive) - vec3(0.0, 1.6 * dive, 0.0));
    } else if (rig.scene == S_BELT) {
        pos = rig.pos + vec3(0.0, 6.0 * (1.0 - s), 190.0 * (1.0 - s) * (1.0 - s));
        fwd = rig.basis * vec3(0.0, 0.0, -1.0);
        float roll = TAU * (1.0 - smoother01(s));
        up = rotAxis(fwd, roll) * (rig.basis * vec3(0.0, 1.0, 0.0));
    } else {
        vec4 o = introOrbit(rig.scene);
        float a = mix(o.z, o.w, rig.scene == S_BH ? smoother01(s) : 1.0 - (1.0 - s) * (1.0 - s));
        pos = vec3(o.x * sin(a), o.y, o.x * cos(a));
        vec3 lead = vec3(cos(a), 0.0, -sin(a)) * sign(o.w - o.z) * o.x * 0.35;
        fwd = normalize(lead - pos);
    }
    vec3 nf = rig.basis * vec3(0.0, 0.0, -1.0);
    vec3 nu = rig.basis * vec3(0.0, 1.0, 0.0);
    rig.pos = mix(pos, rig.pos, e);
    rig.basis = basisFrom(normalize(mix(fwd, nf, e)), normalize(mix(up, nu, e)));
    rig.zoom = mix(rig.scene == S_BH ? 0.85 : 1.25, 1.0, smoother01(remap(lt, len - 5.0, len)));
}

Rig rigAt(float t) {
    Rig rig;
    rig.t = t;
    rig.scene = sceneAt(t);
    rig.lt = t - SCENE_START[rig.scene];
    rig.pos = vec3(0.0);
    rig.basis = mat3(1.0);
    rig.sunDir = vec3(0.0, 1.0, 0.0);
    rig.zoom = 1.0;
    if (rig.scene == S_EARTH) {
        rigEarth(rig.lt, rig);
    } else if (rig.scene == S_MARS) {
        rigMars(rig.lt, rig);
    } else if (rig.scene == S_BELT) {
        rigBelt(rig.lt, rig);
    } else if (rig.scene == S_JUPITER) {
        rigJupiter(rig.lt, rig);
    } else if (rig.scene == S_SATURN) {
        rigSaturn(rig.lt, rig);
    } else if (rig.scene == S_SUN) {
        rigSun(rig.lt, rig);
    } else if (rig.scene == S_BETEL) {
        rigBetel(rig.lt, rig);
    } else if (rig.scene == S_PULSAR) {
        rigPulsar(rig.lt, rig);
    } else if (rig.scene == S_BH) {
        rigBlackHole(rig.lt, rig);
    } else if (rig.scene == S_INSIDE) {
        rigInside(rig.lt, rig);
    } else {
        rigIdle(rig.lt, rig);
    }
    if (hasIntro(rig.scene) && rig.lt < introLen(rig.scene)) {
        applyIntro(rig);
    }
    return rig;
}

// 1 = 우주선 숨김
float shipHidden(float t) {
    int scene = sceneAt(t);
    float lt = t - SCENE_START[scene];
    return hasIntro(scene) && lt < introLen(scene) - 1.5 ? 1.0 : 0.0;
}

// 우주선이 뒤(+Z)에서 날아드는 위치 오프셋(블록)
vec3 shipFlyOffset(float t) {
    int scene = sceneAt(t);
    float lt = t - SCENE_START[scene];
    float len = introLen(scene);
    if (!hasIntro(scene) || lt >= len) {
        return vec3(0.0);
    }
    float k = 1.0 - smoother01(remap(lt, len - 1.5, len));
    return vec3(0.0, 2.5 * k, 55.0 * k * k);
}

// 태양 장면 처음 15.5초는 일부러 눈부시게, 나레이터가 '조정'하면 2초 동안 내려간다
float sunGlare(float lt) {
    return 1.0 - smoother01(remap(lt, 15.5, 17.5));
}


// --- 우주선 기동(3인칭: 우주선이 화면 안에서 움직임, 1인칭: 우주가 대신 기울어짐) -----------

const vec3 STAGE_ORIGIN = vec3(0.5, 100.0, 0.5);
const vec3 SHIP_PIVOT = vec3(0.5, 100.3, 0.5);
const vec3 SEAT_EYE = vec3(0.5, 100.8, -2.12);

struct ShipPose {
    vec3 offset;
    vec3 euler;
};

const int MV_JUKE = 0;
const int MV_ROLL = 1;
const int MV_SURGE = 2;
const int MV_JOLT = 3;
const int MV_TUMBLE = 4;
const int MV_BANK = 5;

// (시작 초, 길이, 종류, 값: 방향·거리·세기·바퀴)
const vec4 MANEUVERS[72] = vec4[](
    vec4(36.0, 6.0, 5.0, 0.5), vec4(47.0, 5.0, 2.0, 8.0), vec4(96.0, 6.0, 5.0, -0.5), vec4(112.0, 6.0, 2.0, 10.0),
    vec4(184.5, 1.8, 0.0, -1.0), vec4(188.5, 1.5, 1.0, 1.0), vec4(193.5, 1.8, 0.0, 1.0), vec4(197.5, 4.0, 2.0, 14.0),
    vec4(201.5, 1.5, 1.0, -1.0), vec4(206.5, 1.8, 0.0, -1.0), vec4(211.5, 3.0, 3.0, 0.5), vec4(215.5, 1.4, 1.0, 1.0),
    vec4(219.5, 1.8, 0.0, 1.0), vec4(224.5, 4.0, 3.0, 1.0), vec4(224.5, 6.0, 4.0, 1.0), vec4(230.5, 5.0, 5.0, -0.5),
    vec4(234.5, 3.0, 3.0, 0.6), vec4(234.5, 1.5, 0.0, 1.0), vec4(239.5, 3.5, 2.0, 10.0), vec4(244.5, 1.5, 1.0, -1.0),
    vec4(265.5, 7.0, 2.0, 26.0), vec4(281.5, 7.0, 5.0, 0.5), vec4(295.5, 2.2, -1.0, 0.0), vec4(309.5, 6.0, 2.0, 18.0),
    vec4(325.5, 2.2, 0.0, -1.0), vec4(361.4, 7.0, 5.0, -0.5), vec4(375.4, 2.0, -1.0, 0.0), vec4(387.4, 6.0, 2.0, 16.0),
    vec4(390.4, 1.4, 0.0, -1.0), vec4(391.9, 1.4, 0.0, 1.0), vec4(393.4, 1.2, 1.0, -1.0), vec4(394.9, 1.4, 0.0, 1.0),
    vec4(396.4, 1.4, 0.0, -1.0), vec4(398.4, 4.0, 3.0, 0.9), vec4(398.4, 6.0, 4.0, -0.8), vec4(401.4, 1.4, 0.0, 1.0),
    vec4(402.9, 1.4, 0.0, -1.0), vec4(410.4, 6.0, 5.0, 0.5), vec4(413.1, 2.0, -1.0, 0.0), vec4(443.1, 8.0, 5.0, 0.5),
    vec4(461.1, 7.0, 2.0, 22.0), vec4(499.6, 2.0, 0.0, -1.0), vec4(509.6, 1.6, 1.0, 1.0), vec4(517.4, 4.0, 3.0, 1.0),
    vec4(517.4, 6.0, 4.0, -0.9), vec4(525.4, 6.0, 5.0, -0.5), vec4(642.2, 9.0, 5.0, -0.4), vec4(657.2, 8.0, 2.0, 12.0),
    vec4(676.2, 6.0, 5.0, 0.4), vec4(717.2, 1.6, 1.0, 1.0), vec4(724.2, 5.0, 2.0, 14.0), vec4(732.2, 1.8, 0.0, -1.0),
    vec4(742.2, 1.6, 1.0, -1.0), vec4(752.2, 1.8, 0.0, 1.0), vec4(758.2, 1.4, 1.0, 1.0), vec4(764.2, 4.0, 3.0, 1.0),
    vec4(764.2, 6.0, 4.0, 1.0), vec4(774.2, 7.0, 5.0, -0.5), vec4(814.2, 8.0, 2.0, 16.0), vec4(830.2, 9.0, 5.0, 0.4),
    vec4(902.2, 4.0, 3.0, 1.0), vec4(902.2, 6.0, 4.0, 1.3), vec4(965.9, 1.4, 1.0, -1.0), vec4(971.9, 1.6, 0.0, 1.0),
    vec4(977.9, 1.4, 1.0, 1.0), vec4(983.9, 1.6, 0.0, -1.0), vec4(989.9, 1.4, 1.0, -1.0), vec4(995.9, 1.6, 0.0, 1.0),
    vec4(1001.9, 1.4, 1.0, 1.0), vec4(1006.9, 1.6, 0.0, -1.0), vec4(980.9, 5.0, 2.0, 12.0), vec4(0.0, 0.0, -1.0, 0.0)
);

// 0→1→0, 시작·끝 속도 0
float arc(float s) {
    float a = s <= 0.0 || s >= 1.0 ? 0.0 : sin(PI * s);
    return a * a;
}

void maneuver(inout ShipPose p, vec4 m, float t) {
    int kind = int(m.z + 0.5);
    float d = t - m.x;
    float s = d / max(m.y, 1e-3);
    if (m.z < 0.0 || d < 0.0 || s > 1.0) {
        return;
    }
    float v = m.w;
    if (kind == MV_JUKE) {
        float sw = s <= 0.0 || s >= 1.0 ? 0.0 : sin(TAU * s) * sin(PI * s);
        p.offset += vec3(v * 4.5, -0.8, 0.0) * arc(s);
        p.euler.z += -v * 0.55 * sw;
        p.euler.y += -v * 0.15 * sw;
    } else if (kind == MV_ROLL) {
        p.euler.z += v * TAU * smoother01(s);
        p.offset += vec3(v * 2.2, 0.6, 0.0) * arc(s);
    } else if (kind == MV_SURGE) {
        float out_ = smoother01(min(s / 0.35, 1.0));
        float back = smoother01(max((s - 0.35) / 0.65, 0.0));
        p.offset.z -= v * out_ * (1.0 - back);
        p.euler.x += 0.08 * arc(s);
    } else if (kind == MV_JOLT) {
        float e = exp(-d * 2.2) * v;
        p.euler += e * vec3(0.35 * sin(d * 19.0), 0.2 * sin(d * 17.0 + 2.0), 0.6 * sin(d * 13.0 + 1.0));
        p.offset += e * 0.5 * vec3(sin(d * 23.0), sin(d * 29.0 + 1.0), sin(d * 31.0 + 2.0));
    } else if (kind == MV_TUMBLE) {
        // 충격으로 빠르게 기울었다가 자동조종이 천천히 바로잡는다(끝까지 연속, 값 = 기울기 라디안)
        float k = (1.0 - exp(-d * 6.0)) * exp(-d * 0.9);
        p.euler += vec3(0.30 * abs(v), 0.12 * v, v) * k;
    } else {
        p.offset += vec3(v * 4.0, 0.0, 0.0) * arc(s);
        p.euler.z += v * 0.5 * arc(s);
        p.euler.y += v * 0.12 * arc(s);
    }
}

ShipPose shipPose(float t) {
    ShipPose p;
    p.offset = vec3(0.0);
    p.euler = vec3(0.0);
    if (t >= T_IDLE || t >= 1018.9 || (t >= 953.9 && t < 956.9)) {
        return p;
    }
    p.offset = vec3(0.5 * sin(t * 0.31), 0.3 * sin(t * 0.47 + 1.0), 0.6 * sin(t * 0.23 + 2.0));
    p.euler = vec3(0.02 * sin(t * 0.37), 0.02 * sin(t * 0.29), 0.035 * sin(t * 0.21));
    for (int i = 0; i < 72; i++) {
        maneuver(p, MANEUVERS[i], t);
    }
    for (int i = S_MARS; i <= S_BH; i++) {
        float b = SCENE_START[i];
        float lead = smoother01(remap(t, b - 6.0, b - 0.6));
        float shoot = remap(t, b - 0.6, b);
        if (t > b - 6.0 && t < b) {
            p.offset.z -= 8.0 * lead + 320.0 * shoot * shoot * shoot;
        }
    }
    float pull = t < 955.9 ? smoother01(remap(t, 842.2, 882.2)) * 22.0 + smoother01(remap(t, 907.2, 955.9)) * 40.0 : 0.0;
    p.offset.z -= pull;
    float sh = shakeAmount(t);
    p.offset += sh * 0.12 * (vec3(vnoise(vec3(t * 31.0, 0.0, 0.0)), vnoise(vec3(0.0, t * 37.0, 0.0)), vnoise(vec3(0.0, 0.0, t * 29.0))) - 0.5);
    return p;
}

mat3 poseRotation(ShipPose p) {
    return rotY(p.euler.y) * rotX(p.euler.x) * rotZ(p.euler.z);
}

// 카메라(장면 회전)보다 우주선이 0.45초 늦게 돈다
mat3 shipLag(float t) {
    if (t >= T_IDLE) {
        return mat3(1.0);
    }
    float tl = t - 0.45;
    if (sceneAt(tl) != sceneAt(t) || tl < 0.0) {
        return mat3(1.0);
    }
    mat3 m = transpose(rigAt(t).basis) * rigAt(tl).basis;
    float angle = acos(clamp((m[0][0] + m[1][1] + m[2][2] - 1.0) * 0.5, -1.0, 1.0));
    float k = angle > 0.35 ? 0.35 / angle : 1.0;
    return basisFrom(normalize(mix(vec3(0.0, 0.0, -1.0), m * vec3(0.0, 0.0, -1.0), k)), normalize(mix(vec3(0.0, 1.0, 0.0), m * vec3(0.0, 1.0, 0.0), k)));
}

mat3 shipRotation(float t, ShipPose p) {
    return shipLag(t) * poseRotation(p);
}

// 회전을 일부만(k) 적용: 1인칭에선 배경 기울기를 약하게
mat3 dampRotation(mat3 m, float k) {
    return basisFrom(normalize(mix(vec3(0.0, 0.0, -1.0), m * vec3(0.0, 0.0, -1.0), k)), normalize(mix(vec3(0.0, 1.0, 0.0), m * vec3(0.0, 1.0, 0.0), k)));
}

bool isFirstPerson(vec3 camWorld) {
    return length(camWorld - SEAT_EYE) < 3.0;
}

// --- 우주선 조명(아이템 셰이더가 씀) -----------------------------------------

struct ShipLight {
    vec3 keyDir;
    vec3 keyColor;
    vec3 fill;
    vec3 rimDir;
    vec3 rimColor;
};

// 가상 좌표의 광원 방향 → 실제(월드) 방향은 transpose(basis)
ShipLight shipLight(Rig rig) {
    ShipLight l;
    mat3 toReal = transpose(rig.basis);
    l.keyDir = normalize(toReal * rig.sunDir);
    l.keyColor = vec3(1.0, 0.97, 0.92) * 2.2;
    l.fill = vec3(0.020, 0.024, 0.032);
    l.rimDir = -l.keyDir;
    l.rimColor = vec3(0.0);
    float lt = rig.lt;
    if (rig.scene == S_EARTH) {
        vec3 p = rig.pos;
        vec3 s = rig.sunDir;
        float b = dot(p, s);
        float shadow = (b < 0.0 && length(p - b * s) < 1.0) ? 1.0 : 0.0;
        float lit = 1.0 - shadow * (1.0 - remap(length(p - b * s), 0.985, 1.02));
        l.keyColor *= lit;
        vec3 down = normalize(-p);
        l.rimDir = normalize(toReal * down);
        l.rimColor = vec3(0.10, 0.20, 0.42) * (0.25 + 0.75 * sat(dot(-down, s) + 0.3)) * remap(length(p), 9.0, 1.05);
        l.fill = vec3(0.012, 0.016, 0.026);
    } else if (rig.scene == S_BELT) {
        l.keyColor = vec3(1.0, 0.96, 0.90) * 1.7;
    } else if (rig.scene == S_JUPITER) {
        l.keyColor = vec3(1.0, 0.95, 0.88) * 1.2;
        l.rimDir = normalize(toReal * normalize(-rig.pos));
        l.rimColor = vec3(0.30, 0.22, 0.14) * 0.6;
    } else if (rig.scene == S_MARS) {
        l.keyColor = vec3(1.0, 0.95, 0.88) * 1.7;
        l.rimDir = normalize(toReal * normalize(-rig.pos));
        l.rimColor = vec3(0.45, 0.20, 0.10) * 0.4;
    } else if (rig.scene == S_SATURN) {
        l.keyColor = vec3(1.0, 0.96, 0.88) * 1.1;
        l.rimDir = normalize(toReal * normalize(-rig.pos));
        l.rimColor = vec3(0.30, 0.27, 0.20) * 0.5;
    } else if (rig.scene == S_SUN) {
        l.keyColor = vec3(1.0, 0.86, 0.62) * (4.5 + 12.0 * sunGlare(lt));
        l.fill = vec3(0.18, 0.08, 0.02);
    } else if (rig.scene == S_BETEL) {
        l.keyColor = vec3(1.0, 0.42, 0.16) * 2.6;
        l.fill = vec3(0.10, 0.02, 0.005);
    } else if (rig.scene == S_PULSAR) {
        float beat = pow(0.5 + 0.5 * cos(TAU * 1.4 * rig.t), 24.0);
        l.keyColor = vec3(0.55, 0.75, 1.0) * (0.6 + 4.0 * beat);
        l.fill = vec3(0.04, 0.03, 0.08);
    } else if (rig.scene == S_BH) {
        vec3 diskUp = normalize(toReal * vec3(0.0, 1.0, 0.0));
        l.keyDir = normalize(toReal * normalize(-rig.pos + vec3(0.0, -0.2 * length(rig.pos), 0.0)));
        l.keyColor = vec3(1.0, 0.62, 0.30) * 2.0 * (1.0 - remap(lt, 125.0, 183.5));
        l.rimDir = -diskUp;
        l.rimColor = vec3(1.0, 0.5, 0.2) * 0.4;
        l.fill = vec3(0.02, 0.012, 0.008);
    } else if (rig.scene == S_INSIDE) {
        float pulse = 0.75 + 0.25 * sin(rig.t * 3.0);
        l.keyDir = normalize(toReal * normalize(vec3(0.3, 1.0, 0.2)));
        l.keyColor = vec3(1.0, 0.72, 0.38) * 1.6 * pulse;
        l.rimDir = normalize(toReal * normalize(vec3(-0.5, -0.4, 0.6)));
        l.rimColor = vec3(0.3, 0.75, 1.0) * 0.9;
        l.fill = vec3(0.06, 0.04, 0.03);
    } else if (rig.scene == S_IDLE) {
        // 로비 = 한낮 야외: 하늘 주변광이 커서 어느 쪽에서 봐도 하얀 배(나레이션 '크고 하얀 물체')
        l.keyColor = vec3(1.0, 0.97, 0.92) * 0.9;
        l.fill = vec3(0.46, 0.50, 0.56);
    } else {
        l.keyColor = vec3(0.0);
        l.fill = vec3(0.0);
    }
    float wf = warpFlash(rig.t) + impactFlash(rig.t);
    l.fill += vec3(0.8, 0.9, 1.0) * wf;
    return l;
}

#endif

#ifndef BH_BODIES_GLSL
#define BH_BODIES_GLSL

// 모든 천체 함수는 가상 좌표의 광선(ro, rd)을 받는다. 색은 선형 HDR.
// 불투명 천체는 vec4(색, 덮임) 을 돌려주고, 겹치는 순서는 bh_sky.glsl 이 거리로 정한다.

// ---------------------------------------------------------------- 배경 ----

vec3 starLayer(vec3 d, float cells, float pixAngle, float seed, float prob) {
    vec3 cell = floor(d * cells);
    vec3 h = hash33(cell + seed);
    if (h.z < 1.0 - prob) {
        return vec3(0.0);
    }
    vec3 star = normalize((cell + 0.15 + 0.7 * h) / cells);
    float ang = acos(clamp(dot(d, star), -1.0, 1.0));
    float mag = pow(hash13(cell * 1.7 + seed + 3.1), 5.0);
    float size = pixAngle * (0.7 + 0.6 * mag);
    float core = exp(-ang * ang / (size * size));
    float temp = mix(3200.0, 11000.0, pow(hash13(cell + seed + 7.7), 1.4));
    return mix(vec3(1.0), blackbody(temp), 0.55) * core * (0.03 + 2.2 * mag);
}

vec3 starfield(vec3 d, float pixAngle) {
    return starLayer(d, 60.0, pixAngle, 0.0, 0.10) + starLayer(d, 150.0, pixAngle, 17.0, 0.035) * 0.6 + starLayer(d, 380.0, pixAngle, 41.0, 0.012) * 0.35;
}

vec3 milkyWay(sampler2D atlas, vec3 d, mat3 skyRot, float gain) {
    vec2 uv = dirToEquirect(skyRot * d);
    vec3 c = regionSample(atlas, R_SKY, uv).rgb;
    return c * c * gain;
}

vec3 nebulaHaze(vec3 d, vec3 colA, vec3 colB, float scale, float seed) {
    vec3 q = d * scale + seed;
    float n = fbm3(q, 4);
    float m = fbm3(q * 2.3 + 11.0, 3);
    float filament = pow(1.0 - abs(n * 2.0 - 1.0), 6.0);
    float cloud = smoothstep(0.45, 0.85, n);
    return (colA * cloud + colB * filament * smoothstep(0.35, 0.7, m)) ;
}

vec3 background(sampler2D atlas, vec3 d, float pixAngle, int scene) {
    mat3 skyRot = rotY(0.6) * rotX(0.35);
    float gain = 0.55;
    vec3 neb = vec3(0.0);
    if (scene == S_BETEL) {
        skyRot = rotZ(1.1) * rotY(2.0);
        gain = 0.5;
        neb = nebulaHaze(d, vec3(0.020, 0.006, 0.004), vec3(0.03, 0.012, 0.006), 2.0, 3.0);
    } else if (scene == S_PULSAR) {
        skyRot = rotX(1.2) * rotY(-0.7);
        gain = 0.35;
    } else if (scene == S_BH) {
        skyRot = rotZ(-0.4) * rotY(2.6) * rotX(-0.25);
        gain = 0.9;
        neb = nebulaHaze(d, vec3(0.010, 0.012, 0.030), vec3(0.030, 0.010, 0.040), 1.6, 7.0);
    } else if (scene == S_IDLE) {
        skyRot = rotX(-0.5) * rotY(1.3);
        gain = 0.8;
        neb = nebulaHaze(d, vec3(0.018, 0.010, 0.030), vec3(0.035, 0.020, 0.010), 1.8, 5.0);
    }
    return milkyWay(atlas, d, skyRot, gain) + starfield(d, pixAngle) + neb;
}

// 슬립스트림: 진행 방향을 축으로 흐르는 빛의 터널
vec3 slipstream(vec3 d, vec3 fwd, float w, float t) {
    float c = dot(d, fwd);
    vec3 side = d - fwd * c;
    float sl = length(side);
    vec3 e1 = normalize(cross(fwd, abs(fwd.y) < 0.9 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0)));
    vec3 e2 = cross(fwd, e1);
    vec2 ring = vec2(dot(side, e1), dot(side, e2)) / max(sl, 1e-4);
    float depth = c / max(sl, 0.02);
    float flow = depth * 0.35 - t * 9.0;
    float streak = vnoise(vec3(ring * 9.0, flow));
    streak = pow(smoothstep(0.45, 0.95, streak), 2.0);
    float fine = vnoise(vec3(ring * 31.0, flow * 3.0 + 7.0));
    float walls = smoothstep(-0.2, 0.6, c) * (1.0 - smoothstep(0.92, 0.995, c));
    float core = exp(-sl * sl * 40.0) * step(0.0, c);
    vec3 col = mix(vec3(0.10, 0.25, 0.9), vec3(0.75, 0.9, 1.0), streak) * (streak * 2.2 + fine * 0.25) * walls;
    col += vec3(0.8, 0.9, 1.0) * core * 0.9;
    return col * smoothstep(0.25, 0.75, w);
}

// 워프: 진행 방향(fwd) 둘레 별이 늘어난다
vec3 warpStreaks(sampler2D atlas, vec3 d, vec3 fwd, float w, float pixAngle, int scene) {
    vec3 acc = vec3(0.0);
    vec3 side = d - fwd * dot(d, fwd);
    float sl = length(side);
    if (sl < 1e-4) {
        return background(atlas, d, pixAngle, scene);
    }
    side /= sl;
    float a = acos(clamp(dot(d, fwd), -1.0, 1.0));
    const int N = 10;
    for (int i = 0; i < N; i++) {
        float k = float(i) / float(N - 1);
        float ai = a * (1.0 - w * 0.85 * k);
        vec3 di = normalize(fwd * cos(ai) + side * sin(ai));
        acc = max(acc, starLayer(di, 60.0, pixAngle * (1.0 + 3.0 * w), 0.0, 0.10));
    }
    vec3 base = background(atlas, d, pixAngle, scene) * (1.0 - w);
    return base + acc * (1.0 + 2.0 * w);
}

// --------------------------------------------------------- 지구·달 -------

const float ATM_TOP = 1.026;
const float ATM_HR = 0.0030;
const float ATM_HM = 0.0011;
const vec3 ATM_BR = vec3(16.8, 39.1, 95.9);
const float ATM_BM = 22.0;

vec2 atmDensity(vec3 p) {
    float h = max(length(p) - 1.0, 0.0);
    return vec2(exp(-h / ATM_HR), exp(-h / ATM_HM));
}

vec2 lightDepth(vec3 p, vec3 s) {
    vec2 hit = raySphere(p, s, vec3(0.0), ATM_TOP);
    float len = hit.y;
    const int M = 5;
    float ds = len / float(M);
    vec2 od = vec2(0.0);
    for (int j = 0; j < M; j++) {
        od += atmDensity(p + s * ds * (float(j) + 0.5));
    }
    return od * ds;
}

// 대기 산란: 들어오는 빛(rgb)과 투과율(a)
vec4 atmosphere(vec3 ro, vec3 rd, vec3 s, float tMax) {
    vec2 hit = raySphere(ro, rd, vec3(0.0), ATM_TOP);
    if (hit.x > hit.y || hit.y < 0.0) {
        return vec4(0.0, 0.0, 0.0, 1.0);
    }
    float t0 = max(hit.x, 0.0);
    float t1 = min(hit.y, tMax);
    const int N = 14;
    float ds = (t1 - t0) / float(N);
    vec2 odView = vec2(0.0);
    vec3 sumR = vec3(0.0);
    vec3 sumM = vec3(0.0);
    for (int i = 0; i < N; i++) {
        vec3 p = ro + rd * (t0 + ds * (float(i) + 0.5));
        vec2 dens = atmDensity(p) * ds;
        odView += dens;
        vec2 shadow = raySphere(p, s, vec3(0.0), 0.999);
        if (shadow.x < shadow.y && shadow.y > 0.0) {
            continue;
        }
        vec2 odLight = lightDepth(p, s);
        vec3 tau = ATM_BR * (odView.x + odLight.x) + ATM_BM * 1.1 * (odView.y + odLight.y);
        vec3 att = exp(-tau);
        sumR += dens.x * att;
        sumM += dens.y * att;
    }
    float mu = dot(rd, s);
    float phaseR = 3.0 / (16.0 * PI) * (1.0 + mu * mu);
    const float g = 0.76;
    float phaseM = 3.0 / (8.0 * PI) * ((1.0 - g * g) * (1.0 + mu * mu)) / ((2.0 + g * g) * pow(1.0 + g * g - 2.0 * g * mu, 1.5));
    vec3 inscatter = 14.0 * (sumR * ATM_BR * phaseR + sumM * ATM_BM * phaseM);
    float trans = exp(-dot(ATM_BR * odView.x + ATM_BM * odView.y, vec3(0.3333)));
    return vec4(inscatter, trans);
}

mat3 earthFrame(float t) {
    float lat0 = radians(41.0);
    float lon0 = radians(28.0) + t * 0.0004;
    vec3 n = vec3(cos(lat0) * sin(lon0), sin(lat0), cos(lat0) * cos(lon0));
    vec3 e = vec3(cos(lon0), 0.0, -sin(lon0));
    return mat3(e, n, cross(e, n));
}

vec2 sphereUV(vec3 n) {
    return vec2(atan(n.x, n.z) / TAU + 0.5, acos(clamp(n.y, -1.0, 1.0)) / PI);
}

vec4 earth(sampler2D atlas, vec3 ro, vec3 rd, vec3 s, float t, float pixAngle, out float hitT) {
    vec2 hit = raySphere(ro, rd, vec3(0.0), 1.0);
    bool ground = hit.x < hit.y && hit.x > 0.0;
    hitT = ground ? hit.x : 1e30;
    vec4 atm = atmosphere(ro, rd, s, ground ? hit.x : 1e30);
    if (!ground) {
        return vec4(0.0);
    }
    vec3 p = ro + rd * hit.x;
    vec3 n = normalize(p);
    mat3 frame = earthFrame(t);
    vec3 ne = frame * n;
    vec2 uv = sphereUV(ne);
    float tpp = pixAngle * hit.x / (TAU / 4096.0) / max(dot(n, -rd), 0.15);
    vec4 alb = regionSampleLod(atlas, R_EARTH, R_EARTH_L2, uv, tpp);
    vec4 aux = regionSampleLod(atlas, R_EARTH_AUX, R_EARTH_AUX_L2, uv + vec2(t * 0.00002, 0.0), tpp);
    vec3 sl = frame * s;
    vec2 uvShadow = sphereUV(normalize(ne + sl * 0.012));
    float cloudShadow = regionSample(atlas, R_EARTH_AUX_L2, uvShadow + vec2(t * 0.00002, 0.0)).r;
    vec3 albedo = alb.rgb * alb.rgb * 0.9;
    float ocean = alb.a;
    albedo = mix(albedo, vec3(0.010, 0.025, 0.060), ocean * 0.55);
    float clouds = smoothstep(0.08, 0.85, aux.r);
    float ndl = dot(n, s);
    float day = smoothstep(-0.06, 0.12, ndl);
    vec3 h = normalize(s - rd);
    float glint = pow(max(dot(n, h), 0.0), 180.0) * ocean * (1.0 - clouds) * 6.0;
    vec3 ground_c = albedo * max(ndl, 0.0) * (1.0 - 0.55 * smoothstep(0.2, 0.9, cloudShadow));
    vec3 cloud_c = vec3(0.95, 0.96, 1.0) * max(ndl + 0.05, 0.0) * 1.1;
    vec3 surf = mix(ground_c, cloud_c * 0.8, clouds) * 2.3 + vec3(1.0, 0.92, 0.8) * glint * day;
    float night = 1.0 - smoothstep(-0.18, 0.06, ndl);
    vec3 lights = vec3(1.0, 0.62, 0.28) * aux.g * aux.g * 0.9 * night * (1.0 - 0.75 * clouds);
    vec3 col = surf + lights;
    col = col * atm.a + atm.rgb;
    return vec4(col, 1.0);
}

// 지구 밖 대기 빛(지구에 안 맞는 광선)
vec3 earthLimb(vec3 ro, vec3 rd, vec3 s) {
    vec2 hit = raySphere(ro, rd, vec3(0.0), 1.0);
    if (hit.x < hit.y && hit.x > 0.0) {
        return vec3(0.0);
    }
    return atmosphere(ro, rd, s, 1e30).rgb;
}

mat3 moonFrame() {
    vec3 z = normalize(-MOON_POS);
    vec3 x = normalize(cross(vec3(0.0, 1.0, 0.0), z));
    vec3 y = cross(z, x);
    return mat3(x, y, z);
}

vec4 moon(sampler2D atlas, vec3 ro, vec3 rd, vec3 s, float pixAngle, out float hitT) {
    vec2 hit = raySphere(ro, rd, MOON_POS, MOON_R);
    hitT = 1e30;
    if (hit.x > hit.y || hit.x < 0.0) {
        return vec4(0.0);
    }
    hitT = hit.x;
    vec3 p = ro + rd * hit.x;
    vec3 n = normalize(p - MOON_POS);
    mat3 f = moonFrame();
    vec3 nm = transpose(f) * n;
    vec2 uv = sphereUV(nm);
    float tpp = pixAngle * hit.x / (TAU * MOON_R / 2048.0) * MOON_R / max(dot(n, -rd), 0.15);
    vec4 a = regionSampleLod(atlas, R_MOON, R_MOON_L2, uv, tpp);
    float e = 1.0 / 2048.0;
    float hx = regionSample(atlas, R_MOON, uv + vec2(e, 0.0)).a - a.a;
    float hy = regionSample(atlas, R_MOON, uv + vec2(0.0, e)).a - a.a;
    vec3 tx = normalize(cross(vec3(0.0, 1.0, 0.0), n) + 1e-4);
    vec3 ty = cross(n, tx);
    vec3 nb = normalize(n - (tx * hx + ty * hy) * 3.0 * smoothstep(0.0, 0.25, dot(n, -rd)));
    float mu0 = max(dot(nb, s), 0.0);
    float mu = max(dot(n, -rd), 0.05);
    vec3 albedo = a.rgb * a.rgb;
    vec3 col = albedo * 1.5 * mu0 / (mu0 + mu);
    col += albedo * vec3(0.10, 0.16, 0.30) * 0.08 * sat(dot(n, normalize(-MOON_POS)));
    return vec4(col, 1.0);
}

// --------------------------------------------------------------- 화성 ------

// 반지름 1, 원점. 지도 = 아틀라스 R_MARS(알파 = 밝기에서 뽑은 높이), 얇은 먼지 대기는 테두리에 버터스카치 빛
const vec3 MARS_HAZE = vec3(0.95, 0.62, 0.40);

vec4 mars(sampler2D atlas, vec3 ro, vec3 rd, vec3 s, float t, float pixAngle, out float hitT) {
    vec2 hit = raySphere(ro, rd, vec3(0.0), 1.0);
    hitT = 1e30;
    if (hit.x > hit.y || hit.x < 0.0) {
        float b = length(cross(ro, rd));
        vec3 limbN = normalize(ro + rd * max(-dot(ro, rd), 0.0));
        float glow = exp(-max(b - 1.0, 0.0) * 70.0) * step(0.0, -dot(ro, rd));
        return vec4(MARS_HAZE * glow * smoothstep(-0.25, 0.35, dot(limbN, s)) * 0.3, 0.0);
    }
    hitT = hit.x;
    vec3 n = normalize(ro + rd * hit.x);
    float rot = t * 0.004;
    vec3 nm = vec3(n.x * cos(rot) - n.z * sin(rot), n.y, n.x * sin(rot) + n.z * cos(rot));
    vec2 uv = sphereUV(nm);
    float tpp = pixAngle * hit.x / (TAU / 1024.0) / max(dot(n, -rd), 0.15);
    vec4 a = regionSampleLod(atlas, R_MARS, R_MARS_L2, uv, tpp);
    float e = 1.0 / 1024.0;
    float hx = regionSample(atlas, R_MARS, uv + vec2(e, 0.0)).a - a.a;
    float hy = regionSample(atlas, R_MARS, uv + vec2(0.0, e)).a - a.a;
    vec3 tx = normalize(cross(vec3(0.0, 1.0, 0.0), n) + 1e-4);
    vec3 ty = cross(n, tx);
    vec3 nb = normalize(n - (tx * hx + ty * hy) * 0.8 * smoothstep(0.0, 0.25, dot(n, -rd)));
    float mu0 = max(dot(nb, s), 0.0);
    float mu = max(dot(n, -rd), 0.05);
    vec3 albedo = a.rgb * a.rgb;
    vec3 col = albedo * 1.7 * mu0 / (mu0 + mu * 0.6);
    col += MARS_HAZE * pow(1.0 - mu, 4.0) * 0.22 * smoothstep(-0.2, 0.4, dot(n, s));
    return vec4(col, 1.0);
}

// --------------------------------------------------------- 가스 행성 ------

const float JUP_U0 = -0.242;
const float JUP_OBL = 0.935;

float jupiterShear(float lat, float t) {
    return 0.0004 * t * sin(lat * 11.0) + 0.0010 * t;
}

// 대적점(지도 u 0.366, 남위 18도)의 현재 위치(목성 반지름 1)
vec3 jupiterGRS(float t) {
    float lat = radians(-18.0);
    float phi = TAU * (0.366 - 0.5 - jupiterShear(lat, t) - JUP_U0);
    vec3 nl = vec3(cos(lat) * sin(phi), sin(lat), cos(lat) * cos(phi));
    return vec3(nl.x, nl.y * JUP_OBL, nl.z);
}

vec4 jupiter(sampler2D atlas, vec3 ro, vec3 rd, vec3 s, float t, float pixAngle, out float hitT) {
    const float OBL = 0.935;
    vec3 sc = vec3(1.0, 1.0 / OBL, 1.0);
    vec3 ros = ro * sc;
    vec3 rds = normalize(rd * sc);
    vec2 hit = raySphere(ros, rds, vec3(0.0), 1.0);
    hitT = 1e30;
    float limbB = length(cross(ros, rds));
    vec3 limbN = normalize(ros + rds * max(-dot(ros, rds), 0.0));
    vec3 haze = vec3(0.75, 0.70, 0.62) * exp(-max(limbB - 1.0, 0.0) * 90.0) * sat(dot(limbN, s) + 0.1) * 0.35;
    if (hit.x > hit.y || hit.x < 0.0) {
        return vec4(haze, 0.0);
    }
    vec3 ps = ros + rds * hit.x;
    hitT = length(ps / sc - ro);
    vec3 n = normalize(ps * sc);
    vec3 nl = normalize(ps);
    float lat = asin(clamp(nl.y, -1.0, 1.0));
    vec2 uv = vec2(atan(nl.x, nl.z) / TAU + 0.5 + jupiterShear(lat, t) + JUP_U0, acos(clamp(nl.y, -1.0, 1.0)) / PI);
    float tpp = pixAngle * hitT / (TAU / 4096.0) / max(dot(n, -rd), 0.15);
    vec3 albedo = regionSampleLod(atlas, R_JUPITER, R_JUPITER_L2, uv, tpp).rgb;
    float swirl = noiseTex(atlas, uv * vec2(8.0, 4.0) + vec2(t * 0.002, 0.0)).g;
    albedo = albedo * albedo * (0.92 + 0.16 * swirl);
    albedo = max(mix(vec3(luma(albedo)), albedo, 1.2), 0.0) * vec3(1.0, 0.96, 0.88);
    float ndl = dot(n, s);
    float mu = max(dot(n, -rd), 0.0);
    float limb = pow(mu, 0.35);
    vec3 col = albedo * smoothstep(-0.08, 0.35, ndl) * max(ndl + 0.08, 0.0) * 1.6 * limb;
    vec3 ioRel = IO_POS;
    vec2 ioShadow = raySphere(ps / sc, s, ioRel, IO_R * 1.25);
    if (ioShadow.x < ioShadow.y && ioShadow.y > 0.0) {
        col *= 0.04;
    }
    vec2 cuv = uv * vec2(90.0, 45.0);
    vec2 cellId = floor(cuv);
    float tick = floor(t * 3.0);
    vec2 spot = vec2(hash12(cellId + tick * 1.7), hash12(cellId.yx + tick * 2.3)) * 0.6 + 0.2;
    float glow = exp(-dot(fract(cuv) - spot, fract(cuv) - spot) * 40.0);
    float flash = step(0.985, hash12(cellId + tick)) * glow * (1.0 - smoothstep(-0.1, 0.05, ndl));
    col += vec3(0.6, 0.7, 1.0) * flash * 0.9;
    col += haze * pow(1.0 - mu, 3.0) * 1.5;
    return vec4(col, 1.0);
}

vec4 io(vec3 ro, vec3 rd, vec3 s, out float hitT) {
    vec2 hit = raySphere(ro, rd, IO_POS, IO_R);
    hitT = 1e30;
    if (hit.x > hit.y || hit.x < 0.0) {
        return vec4(0.0);
    }
    hitT = hit.x;
    vec3 n = normalize(ro + rd * hit.x - IO_POS);
    float v = fbm3(n * 6.0, 4);
    vec3 albedo = mix(vec3(0.85, 0.75, 0.30), vec3(0.55, 0.30, 0.12), smoothstep(0.45, 0.7, v));
    albedo = mix(albedo, vec3(0.15, 0.10, 0.08), smoothstep(0.72, 0.8, v));
    return vec4(albedo * max(dot(n, s), 0.0) * 2.4, 1.0);
}

vec4 ringSample(sampler2D atlas, float r) {
    float u = (r - 1.11) / (2.35 - 1.11);
    if (u < 0.0 || u > 1.0) {
        return vec4(0.0);
    }
    return regionSample(atlas, R_RINGS, vec2(u, 0.5));
}

vec4 saturn(sampler2D atlas, vec3 ro, vec3 rd, vec3 s, float t, float pixAngle, out float hitT) {
    const float OBL = 0.902;
    vec3 sc = vec3(1.0, 1.0 / OBL, 1.0);
    vec3 ros = ro * sc;
    vec3 rds = normalize(rd * sc);
    vec2 hit = raySphere(ros, rds, vec3(0.0), 1.0);
    float tPlanet = 1e30;
    vec4 planet = vec4(0.0);
    if (hit.x < hit.y && hit.x > 0.0) {
        vec3 ps = ros + rds * hit.x;
        vec3 p = ps / sc;
        tPlanet = length(p - ro);
        vec3 n = normalize(ps * sc);
        vec3 nl = normalize(ps);
        float lat = nl.y;
        vec3 band = regionSample(atlas, R_SATURN, vec2(lat * 0.5 + 0.5, 0.5)).rgb;
        float fine = noiseTex(atlas, vec2(atan(nl.x, nl.z) / TAU * 3.0 + t * 0.001, lat * 18.0)).r;
        vec3 albedo = band * band * (0.93 + 0.1 * fine);
        float ndl = dot(n, s);
        float mu = max(dot(n, -rd), 0.0);
        vec3 col = albedo * max(ndl, 0.0) * 2.5 * pow(mu, 0.3);
        float tr = -p.y / s.y;
        if (tr > 0.0) {
            vec3 q = p + s * tr;
            col *= 1.0 - ringSample(atlas, length(q.xz)).a * 0.9;
        }
        col += albedo * vec3(0.9, 0.8, 0.6) * 0.06 * sat(-ndl + 0.3);
        planet = vec4(col, 1.0);
    }
    float tRing = -ro.y / rd.y;
    vec4 ring = vec4(0.0);
    if (tRing > 0.0) {
        vec3 q = ro + rd * tRing;
        float r = length(q.xz);
        vec4 rs = ringSample(atlas, r);
        if (rs.a > 0.0) {
            vec2 sh = raySphere(q * sc, normalize(s * sc), vec3(0.0), 1.0);
            float lit = (sh.x < sh.y && sh.y > 0.0) ? 0.03 : 1.0;
            bool sameSide = sign(ro.y) == sign(s.y);
            float mu0 = abs(s.y);
            float fwd = pow(sat(dot(rd, s)), 6.0);
            float bright = sameSide ? mu0 * 2.2 : (0.08 + 2.0 * fwd) * (1.0 - rs.a) * 1.2;
            float grain = 0.85 + 0.3 * hash12(vec2(floor(r * 2000.0), 1.0));
            ring = vec4(rs.rgb * rs.rgb * bright * lit * grain * 2.0, rs.a);
        }
    }
    bool ringFront = tRing > 0.0 && tRing < tPlanet;
    hitT = min(tPlanet, ring.a > 0.0 ? tRing : 1e30);
    if (ringFront) {
        return vec4(ring.rgb * ring.a + planet.rgb * (1.0 - ring.a), max(ring.a, planet.a));
    }
    return planet.a > 0.0 ? planet : ring;
}

// ------------------------------------------------------------ 항성 -------

float granulationPhase(sampler2D atlas, vec3 n, float scale, float t, float phase) {
    vec3 w = abs(n);
    w = pow(w, vec3(4.0));
    w /= w.x + w.y + w.z;
    vec2 o = vec2(hash11(phase) * 17.3, hash11(phase + 5.1) * 11.9);
    vec3 q = n * scale;
    vec3 flow = 0.18 * vec3(sin(q.y * 0.7 + t * 0.35), sin(q.z * 0.6 + t * 0.29), sin(q.x * 0.8 + t * 0.31));
    q += flow;
    float gx = noiseTex(atlas, q.yz + o).b;
    float gy = noiseTex(atlas, q.zx + o.yx).b;
    float gz = noiseTex(atlas, q.xy - o).b;
    return gx * w.x + gy * w.y + gz * w.z;
}

// 셀이 생겼다 사라지는 끓음: 3초마다 다른 위상으로 넘어간다
float granulation(sampler2D atlas, vec3 n, float scale, float t) {
    float ph = t / 3.0;
    float k = floor(ph);
    float f = smoothstep(0.15, 0.85, fract(ph));
    return mix(granulationPhase(atlas, n, scale, t, k), granulationPhase(atlas, n, scale, t, k + 1.0), f);
}

const vec3 FLARE_N = normalize(vec3(-0.55, 0.45, 0.70));
// 플레어 터지는 태양 장면 시각(초) — 태양 장면 앞쪽에 대사를 끼워 넣으면 같이 민다(build.py MINOR 'flare' = 장면 시작 + 이 값)
const float SUN_FLARE = 86.5;
const vec3 SPOT_N = normalize(vec3(0.35, 0.18, 0.92));

vec4 sun(sampler2D atlas, vec3 ro, vec3 rd, float t, out float hitT) {
    vec2 hit = raySphere(ro, rd, vec3(0.0), 1.0);
    hitT = 1e30;
    float b = length(cross(ro, rd));
    vec3 cdir = normalize(ro + rd * max(-dot(ro, rd), 0.0));
    float streamer = fbm3(cdir * 3.0 + vec3(0.0, t * 0.05, t * 0.02), 4);
    float corona = pow(max(b, 1.0), -4.0) * (0.25 + 1.2 * smoothstep(0.45, 0.78, streamer));
    vec3 glow = vec3(1.0, 0.70, 0.40) * corona * 4.0;
    if (hit.x > hit.y || hit.x < 0.0) {
        float behind = step(dot(ro, rd), 0.0);
        float shell = 0.0;
        for (int i = 0; i < 10; i++) {
            float tt = -dot(ro, rd) + (float(i) - 4.5) * 0.05;
            vec3 p = ro + rd * tt;
            float r = length(p);
            if (r > 1.0 && r < 1.3) {
                vec3 pn = normalize(p);
                float loop = fbm3(pn * 7.0 + vec3(t * 0.08, t * 0.03, 0.0), 4);
                float mask = smoothstep(0.58, 0.75, fbm3(pn * 2.5 + 3.0, 2));
                shell += smoothstep(0.55, 0.70, loop) * mask * exp(-(r - 1.0) * 10.0);
            }
        }
        vec3 prom = vec3(1.0, 0.28, 0.12) * shell * 7.0 * behind;
        float chromo = exp(-max(b - 1.0, 0.0) * 80.0) * behind;
        return vec4(glow * behind + prom + vec3(1.0, 0.32, 0.15) * chromo * 9.0, 0.0);
    }
    hitT = hit.x;
    vec3 n = normalize(ro + rd * hit.x);
    float mu = max(dot(n, -rd), 0.0);
    float limb = 1.0 - 0.6 * (1.0 - mu) - 0.25 * (1.0 - mu) * (1.0 - mu);
    float g = granulation(atlas, n, 22.0, t);
    float cells = smoothstep(0.03, 0.42, g);
    float super = granulation(atlas, n, 4.0, t * 0.3);
    vec3 hotC = vec3(1.0, 0.66, 0.24);
    vec3 coolC = vec3(0.75, 0.24, 0.04);
    vec3 col = mix(coolC, hotC, cells) * 8.0 * limb * (0.85 + 0.3 * super);
    col *= mix(vec3(0.85, 0.55, 0.30), vec3(1.0), pow(mu, 0.5));
    float spotN = fbm3(n * 4.0 + 20.0, 3);
    float band = 1.0 - smoothstep(0.15, 0.45, abs(abs(n.y) - 0.28));
    float pen = smoothstep(0.66, 0.70, spotN) * band;
    float umbra = smoothstep(0.71, 0.74, spotN) * band;
    col *= 1.0 - pen * 0.55 - umbra * 0.4;
    float sd = acos(clamp(dot(n, SPOT_N), -1.0, 1.0));
    float spotEdge = 0.045 * (0.85 + 0.3 * vnoise(n * 40.0));
    col *= 1.0 - 0.55 * smoothstep(spotEdge, spotEdge * 0.6, sd) - 0.35 * smoothstep(spotEdge * 0.45, spotEdge * 0.25, sd);
    col += vec3(1.0, 0.85, 0.6) * smoothstep(0.60, 0.66, spotN) * band * (1.0 - mu) * 2.0;
    float fd = acos(clamp(dot(n, FLARE_N), -1.0, 1.0));
    float flare = exp(-fd * fd / 0.003) * (pulse(t, SUN_FLARE, 0.22) * 1.0 + 0.12);
    col += vec3(1.0, 0.92, 0.8) * flare * 30.0;
    return vec4(col, 1.0);
}

// 질량 방출 껍질: 플레어 순간 그 자리에서 출발해 7.8초 뒤 카메라를 지남(build.py MAJOR 'cme' = 플레어 + 7.8)
vec3 cmeShell(vec3 ro, vec3 rd, float lt) {
    float age = lt - SUN_FLARE;
    if (age < 0.0 || age > 12.0) {
        return vec3(0.0);
    }
    vec3 origin = FLARE_N * 1.02;
    float radius = 0.05 + age * 0.2833;
    vec2 hit = raySphere(ro, rd, origin + FLARE_N * radius * 0.9, radius);
    if (hit.x > hit.y) {
        return vec3(0.0);
    }
    float thick = (hit.y - max(hit.x, 0.0)) / (2.0 * radius);
    float edge = pow(1.0 - sat(thick), 3.0);
    float tex = fbm3(normalize(ro + rd * max(hit.x, 0.0) - origin) * 6.0 + age * 0.3, 4);
    float fade = 1.0 - remap(age, 7.2, 12.0);
    return vec3(1.0, 0.36, 0.10) * edge * edge * edge * (0.2 + 1.0 * tex) * 7.0 * fade;
}

vec4 betelgeuse(sampler2D atlas, vec3 ro, vec3 rd, float t, out float hitT) {
    float R = 1.0 + 0.02 * sin(t * 0.3);
    vec2 hit = raySphere(ro, rd, vec3(0.0), R);
    hitT = 1e30;
    float b = length(cross(ro, rd));
    vec3 cdir = normalize(ro + rd * max(-dot(ro, rd), 0.0));
    float plume = fbm3(cdir * 2.2 + vec3(t * 0.004), 5);
    float envelope = exp(-max(b - R, 0.0) * 1.6) * (0.25 + 1.6 * smoothstep(0.45, 0.8, plume));
    vec3 env = vec3(1.0, 0.28, 0.08) * envelope * 3.5 + vec3(0.6, 0.16, 0.05) * exp(-max(b - R, 0.0) * 0.35) * 0.4;
    float behind = step(dot(ro, rd), 0.0);
    if (hit.x > hit.y || hit.x < 0.0) {
        return vec4(env * behind, 0.0);
    }
    hitT = hit.x;
    vec3 n = normalize(ro + rd * hit.x);
    float mu = max(dot(n, -rd), 0.0);
    float limb = pow(mu, 0.9);
    vec3 q = n * 1.6 + vec3(0.0, t * 0.02, t * 0.015);
    float big = fbm3(q + fbm3(q * 2.0 + 7.0 + vec3(t * 0.05, 0.0, 0.0), 3) * 1.2, 5);
    float cells = smoothstep(0.35, 0.68, big);
    float lanes = 1.0 - smoothstep(0.0, 0.12, abs(big - 0.5));
    vec3 col = mix(vec3(0.55, 0.12, 0.03), vec3(1.0, 0.55, 0.18), cells) * 8.0 * limb * (1.0 - 0.35 * lanes);
    col += env * (1.0 - mu) * 0.5;
    return vec4(col, 1.0);
}

// ------------------------------------------------------------ 펄사 -------

const vec3 PULSAR_SPIN = normalize(vec3(0.25, 1.0, -0.15));
const float PULSAR_TILT = 0.62;
const float PULSAR_HZ = 1.4;
const float PULSAR_R = 0.02;

vec3 pulsarAxis(float t) {
    vec3 e1 = normalize(cross(PULSAR_SPIN, vec3(0.0, 0.0, 1.0)));
    vec3 e2 = cross(PULSAR_SPIN, e1);
    float ph = TAU * PULSAR_HZ * t;
    return normalize(cos(PULSAR_TILT) * PULSAR_SPIN + sin(PULSAR_TILT) * (cos(ph) * e1 + sin(ph) * e2));
}

// 광선과 반직선(원점에서 dir 쪽) 사이 최단 거리와 반직선 위 위치
vec2 rayRayDist(vec3 ro, vec3 rd, vec3 dir) {
    vec3 w = ro;
    float b = dot(rd, dir);
    float d = dot(rd, w);
    float e = dot(dir, w);
    float denom = 1.0 - b * b;
    float sc = denom > 1e-5 ? (b * e - d) / denom : 0.0;
    float tc = denom > 1e-5 ? (e - b * d) / denom : e;
    sc = max(sc, 0.0);
    tc = max(tc, 0.0);
    vec3 diff = (ro + rd * sc) - dir * tc;
    return vec2(length(diff), tc);
}

vec3 pulsar(vec3 ro, vec3 rd, float t, float pixAngle) {
    vec3 m = pulsarAxis(t);
    vec3 col = vec3(0.0);
    for (int k = 0; k < 2; k++) {
        vec3 dir = k == 0 ? m : -m;
        vec2 dd = rayRayDist(ro, rd, dir);
        float w = 0.01 + dd.y * 0.07;
        float core = exp(-dd.x * dd.x / (w * w));
        float fall = exp(-dd.y * 0.12);
        float sparkle = 0.7 + 0.6 * vnoise(vec3(dd.y * 8.0 - t * 30.0, dd.x * 40.0, float(k)));
        col += vec3(0.55, 0.75, 1.0) * core * fall * sparkle * 3.5;
        col += vec3(0.4, 0.5, 1.0) * exp(-dd.x / (w * 3.0)) * fall * 0.25;
    }
    float d = rayPointDist(ro, rd, vec3(0.0));
    float ang = d / max(length(ro), 1e-3);
    float star = PULSAR_R / max(length(ro), 1e-3);
    col += vec3(0.75, 0.85, 1.0) * (exp(-ang * ang / (star * star + pixAngle * pixAngle)) * 60.0 + 0.0008 / (ang * ang + 1e-5) * 0.02);
    float field = 0.0;
    float t0 = max(-dot(ro, rd) - 1.6, 0.0);
    for (int i = 0; i < 20; i++) {
        vec3 p = ro + rd * (t0 + float(i) * 0.16);
        float r = length(p);
        if (r < 0.05 || r > 1.7) {
            continue;
        }
        vec3 pn = p / r;
        float c = dot(pn, m);
        float s2 = max(1.0 - c * c, 1e-3);
        float L = r / s2;
        vec3 perp = normalize(pn - m * c + 1e-5);
        vec3 ref = normalize(cross(m, vec3(0.3, 1.0, 0.1)));
        float phi = atan(dot(perp, cross(m, ref)), dot(perp, ref));
        float shell = exp(-pow(fract(L * 1.6) - 0.5, 2.0) * 180.0);
        float spoke = exp(-pow(fract(phi * 6.0 / TAU) - 0.5, 2.0) * 60.0);
        field += shell * spoke * exp(-r * 1.4) * step(L, 2.6);
    }
    col += vec3(0.35, 0.55, 1.0) * field * 0.06;
    return col;
}

vec3 pulsarNebula(vec3 ro, vec3 rd, float t) {
    vec3 d = rd;
    float body = fbm3(d * 1.7 + 5.0, 5);
    float rid = 1.0 - abs(fbm3(d * 3.4 + 1.3, 5) * 2.0 - 1.0);
    float fil = pow(rid, 7.0) * smoothstep(0.38, 0.62, body);
    float glowRegion = smoothstep(0.35, 0.7, body);
    float core = exp(-pow(rayPointDist(ro, rd, vec3(0.0)) / 2.5, 2.0));
    vec3 col = vec3(1.0, 0.30, 0.12) * fil * 0.22;
    col += vec3(0.9, 0.55, 0.25) * pow(rid, 16.0) * 0.08 * glowRegion;
    col += vec3(0.15, 0.25, 0.65) * glowRegion * 0.035;
    col += vec3(0.35, 0.45, 1.0) * core * 0.14 * (0.6 + 0.4 * body);
    return col;
}

// -------------------------------------------------------------- 블랙홀 ----

const float BH_RS = 2.0;
const float DISK_IN = 6.0;
const float DISK_OUT = 26.0;

vec3 diskPalette(float x) {
    vec3 outer = vec3(0.55, 0.16, 0.04);
    vec3 mid = vec3(1.0, 0.55, 0.18);
    vec3 inner = vec3(1.0, 0.92, 0.80);
    return x < 0.5 ? mix(outer, mid, x * 2.0) : mix(mid, inner, x * 2.0 - 1.0);
}

// near = 카메라가 원반 바로 위를 스칠 때 1(잘게 부서진 덩어리가 빠르게 흘러가 보이게)
vec3 diskEmission(sampler2D atlas, vec3 p, vec3 photonDir, float t, float near) {
    float r = length(p.xz);
    float phi = atan(p.z, p.x);
    float omega = 9.0 * pow(r, -1.5);
    float a = (phi - omega * t) / TAU;
    float lr = log(r);
    float clumps = noiseTex(atlas, vec2(a * 3.0, lr * 2.2)).r;
    float streaks = noiseTex(atlas, vec2(a * 1.0, lr * 9.0)).a;
    float rr = (r - DISK_IN) / (DISK_OUT - DISK_IN);
    float dens = (0.25 + 0.9 * clumps * clumps) * (0.55 + 0.7 * streaks) * smoothstep(0.0, 0.025, rr) * (1.0 - smoothstep(0.45, 1.0, rr));
    if (near > 0.0) {
        float fine = noiseTex(atlas, vec2(a * 24.0, lr * 30.0)).a;
        dens *= mix(1.0, 0.3 + 1.4 * fine * fine, near);
    }
    float heat = pow(max(1.0 - rr, 0.0), 1.6);
    vec3 vel = normalize(vec3(-p.z, 0.0, p.x));
    float beta = clamp(1.0 / sqrt(max(r - 2.0, 0.5)), 0.0, 0.72);
    float gamma = 1.0 / sqrt(1.0 - beta * beta);
    float dop = 1.0 / (gamma * (1.0 - beta * dot(vel, -photonDir)));
    float grav = sqrt(max(1.0 - BH_RS / r, 0.0));
    float g = dop * grav;
    vec3 c = diskPalette(sat(heat * 0.85 + (g - 1.0) * 0.35));
    c = mix(c, vec3(0.75, 0.85, 1.0), sat((g - 1.25) * 0.8));
    return c * pow(g, 4.0) * dens * (0.6 + 3.0 * heat) * 2.2;
}

vec4 blackHole(sampler2D atlas, vec3 ro, vec3 rd, float t, float pixAngle, out vec3 outDir) {
    vec3 p = ro;
    vec3 v = rd;
    vec3 col = vec3(0.0);
    float trans = 1.0;
    float h2 = dot(cross(p, v), cross(p, v));
    outDir = v;
    float bImpact = sqrt(h2);
    if (bImpact > 60.0 && dot(p, v) > 0.0) {
        return vec4(0.0, 0.0, 0.0, 1.0);
    }
    for (int i = 0; i < 180; i++) {
        float r = length(p);
        if (r < BH_RS * 1.001) {
            trans = 0.0;
            break;
        }
        if (r > 140.0 && dot(p, v) > 0.0) {
            break;
        }
        float dl = clamp(0.07 * r, 0.03, 4.0);
        vec3 acc = -1.5 * BH_RS * h2 * p / pow(r, 5.0);
        vec3 pn = p + v * dl + 0.5 * acc * dl * dl;
        float rn = length(pn);
        vec3 accn = -1.5 * BH_RS * h2 * pn / pow(rn, 5.0);
        vec3 vn = normalize(v + 0.5 * (acc + accn) * dl);
        if (p.y * pn.y < 0.0) {
            float f = p.y / (p.y - pn.y);
            vec3 q = mix(p, pn, f);
            float rq = length(q.xz);
            if (rq > DISK_IN && rq < DISK_OUT) {
                float dist = length(q - ro);
                vec3 e = diskEmission(atlas, q, v, t, 1.0 - smoothstep(3.0, 14.0, dist));
                float a = sat(luma(e) * 0.9 + 0.35) * smoothstep(DISK_IN, DISK_IN + 0.6, rq);
                col += e * trans;
                // 가까이서 스칠 땐 원반이 불투명(뒤로 비치는 광자 고리가 금처럼 보이지 않게)
                trans *= 1.0 - mix(a * 0.85, 1.0, 1.0 - smoothstep(4.0, 22.0, dist));
            }
        }
        p = pn;
        v = vn;
        if (trans < 0.02) {
            break;
        }
    }
    outDir = v;
    float jet = 0.0;
    vec2 jd = rayRayDist(ro, rd, vec3(0.0, 1.0, 0.0));
    vec2 jd2 = rayRayDist(ro, rd, vec3(0.0, -1.0, 0.0));
    float jw = 0.8 + jd.y * 0.09;
    jet += exp(-jd.x * jd.x / (jw * jw)) * exp(-jd.y * 0.025) * smoothstep(3.0, 8.0, jd.y);
    jw = 0.8 + jd2.y * 0.09;
    jet += exp(-jd2.x * jd2.x / (jw * jw)) * exp(-jd2.y * 0.025) * smoothstep(3.0, 8.0, jd2.y) * trans;
    col += vec3(0.45, 0.6, 1.0) * jet * 0.06 * (0.8 + 0.4 * vnoise(vec3(jd.y * 0.3 - t * 2.0, 0.0, 0.0)));
    return vec4(col, trans);
}


// ------------------------------------------------------ 블랙홀 내부 ------

// 격자선 위 기둥(세 축) + 칸마다 가끔 판. 공간은 z 를 따라 비틀리고 숨 쉰다
float insideSdf(vec3 p, out float glowId) {
    vec3 g = mod(p + INSIDE_CELL * 0.5, INSIDE_CELL) - INSIDE_CELL * 0.5;
    float rx = length(g.yz) - 0.09;
    float ry = length(g.xz) - 0.09;
    float rz = length(g.xy) - 0.09;
    float d = min(rx, min(ry, rz));
    vec3 cell = floor(p / INSIDE_CELL);
    float h = hash13(cell);
    float panel = h > 0.82 ? abs(g.x) - 0.04 : 1e3;
    panel = max(panel, max(abs(g.y), abs(g.z)) - INSIDE_CELL * 0.42);
    glowId = h;
    return min(d, panel);
}

vec3 insideSpace(vec3 ro, vec3 rd, float t, float lt) {
    vec3 col = vec3(0.0);
    float tt = 0.2;
    float glowId = 0.0;
    vec3 sphere = INSIDE_SPHERE;
    float sphereR = 26.0;
    vec2 sh = raySphere(ro, rd, sphere, sphereR);
    if (sh.x < 0.0 && sh.y > 0.0) {
        return vec3(0.0);
    }
    float sphereT = sh.x < sh.y && sh.x > 0.0 ? sh.x : 1e30;
    float open = smoothstep(48.0, 58.0, lt);
    for (int i = 0; i < 72; i++) {
        vec3 p = ro + rd * tt;
        float d = insideSdf(p, glowId);
        float fade = exp(-tt * 0.03) * (1.0 - open * smoothstep(sphereR + 30.0, sphereR, length(p - sphere)));
        float flow = 0.5 + 0.5 * sin(dot(p, vec3(0.13, 0.17, 0.21)) * 2.0 - t * 6.0);
        vec3 hue = mix(vec3(1.0, 0.62, 0.25), vec3(0.35, 0.8, 1.0), step(0.6, fract(glowId * 7.0)));
        col += hue * exp(-max(d, 0.0) * 9.0) * 0.03 * (0.4 + 1.2 * flow * flow) * fade;
        if (d < 0.02) {
            col += hue * (0.25 + 1.6 * pow(flow, 4.0)) * fade * 0.35;
            break;
        }
        tt += max(d * 0.85, 0.05);
        if (tt > 160.0 || tt > sphereT) {
            break;
        }
    }
    float rim = sh.x < sh.y ? 0.0 : exp(-max(length(cross(sphere - ro, rd)) - sphereR, 0.0) * 0.35);
    col *= sphereT < 1e29 ? 0.0 : 1.0;
    col += vec3(1.0, 0.85, 0.6) * rim * open * 1.5;
    col += vec3(0.05, 0.035, 0.02) * (1.0 - open);
    return col;
}

// ------------------------------------------------- 소행성·얼음 알갱이 층 ---

// 가상 z 축에 수직인 판 여러 장에 바위를 흩뿌린다(카메라는 -z 로 전진)
vec4 rockLayers(vec3 ro, vec3 rd, vec3 s, float spacing, float cell, float density, float rMin, float rMax, vec3 tint, float icy, float sheetHalf, float pixAngle, out float hitT) {
    hitT = 1e30;
    if (abs(rd.z) < 1e-3) {
        return vec4(0.0);
    }
    float dir = sign(rd.z);
    float k0 = dir < 0.0 ? floor(ro.z / spacing) : ceil(ro.z / spacing);
    for (int i = 0; i < 22; i++) {
        float k = k0 + dir * float(i);
        float tz = (k * spacing - ro.z) / rd.z;
        if (tz <= 0.0) {
            continue;
        }
        vec3 pz = ro + rd * tz;
        vec2 c = floor(pz.xy / cell);
        vec3 h = hash33(vec3(c, k));
        float layerDensity = sheetHalf > 0.0 ? density * exp(-pow(k * spacing / sheetHalf, 2.0)) : density;
        if (h.x > layerDensity) {
            continue;
        }
        float rad = mix(rMin, rMax, h.y * h.y * h.y) * cell * 0.4;
        vec3 center = vec3((c + 0.5 + (h.zx - 0.5) * 0.3) * cell, k * spacing);
        vec2 hit = raySphere(ro, rd, center, rad * 1.15);
        if (hit.x > hit.y || hit.x <= 0.0) {
            continue;
        }
        vec3 toC = center - ro;
        float along = dot(toC, rd);
        vec3 closest = ro + rd * along - center;
        float dc = length(closest);
        vec3 cn = normalize(closest + 1e-5);
        float edge = rad * (0.78 + 0.32 * vnoise(cn * 2.5 + h * 10.0));
        if (dc > edge) {
            continue;
        }
        float depth = sqrt(max(edge * edge - dc * dc, 0.0));
        vec3 p = ro + rd * (along - depth);
        vec3 n = normalize(p - center);
        float bump = fbm3(n * 4.0 + h * 7.0, 3);
        n = normalize(n + (vec3(vnoise(n * 6.0 + 1.0), vnoise(n * 6.0 + 2.0), vnoise(n * 6.0 + 3.0)) - 0.5) * 0.9);
        vec3 albedo = mix(vec3(0.07, 0.065, 0.06), vec3(0.17, 0.155, 0.14), bump) * mix(vec3(1.0), tint, h.z);
        albedo = mix(albedo, vec3(0.75, 0.82, 0.9), icy);
        float ndl = max(dot(n, s), 0.0);
        float spec = icy * pow(max(dot(reflect(-s, n), -rd), 0.0), 24.0) * 2.0;
        vec3 col = albedo * (ndl * 2.6 + 0.015) + spec;
        float size = rad / max(tz, 1e-3);
        float fade = smoothstep(pixAngle * 0.6, pixAngle * 2.5, size);
        hitT = tz;
        return vec4(col, fade);
    }
    return vec4(0.0);
}

// 거대 소행성(울퉁불퉁한 구를 거리장으로 따라감)
const vec3 BIG_ROCK_POS = vec3(-62.0, 12.0, -1104.0);
const float BIG_ROCK_R = 34.0;

float bigRockSdf(vec3 p, vec3 c, float r) {
    vec3 q = p - c;
    vec3 n = normalize(q);
    float disp = 0.20 * fbm3(n * 2.2, 4) + 0.06 * fbm3(n * 9.0, 3) - 0.12;
    return length(q * vec3(1.0, 0.8, 1.3)) - r * (1.0 + disp);
}

vec4 bigAsteroid(vec3 ro, vec3 rd, vec3 s, vec3 c, float r, float t, out float hitT) {
    hitT = 1e30;
    vec2 b = raySphere(ro, rd, c, r * 1.6);
    if (b.x > b.y || b.y < 0.0) {
        return vec4(0.0);
    }
    float tt = max(b.x, 0.0);
    bool hit = false;
    for (int i = 0; i < 48; i++) {
        float d = bigRockSdf(ro + rd * tt, c, r);
        if (d < 0.02 * tt * 0.01 + 0.03) {
            hit = true;
            break;
        }
        tt += d * 0.8;
        if (tt > b.y) {
            break;
        }
    }
    if (!hit) {
        return vec4(0.0);
    }
    vec3 p = ro + rd * tt;
    const vec2 e = vec2(0.25, -0.25);
    vec3 n = normalize(e.xyy * bigRockSdf(p + e.xyy, c, r) + e.yyx * bigRockSdf(p + e.yyx, c, r) + e.yxy * bigRockSdf(p + e.yxy, c, r) + e.xxx * bigRockSdf(p + e.xxx, c, r));
    vec3 ln = normalize(p - c);
    float crater = smoothstep(0.55, 0.8, vnoise(ln * 5.0));
    vec3 albedo = mix(vec3(0.11, 0.10, 0.09), vec3(0.21, 0.19, 0.17), fbm3(ln * 14.0, 3)) * (1.0 - crater * 0.35);
    float ndl = max(dot(n, s), 0.0);
    hitT = tt;
    return vec4(albedo * (ndl * 2.8 + 0.01), 1.0);
}

// 가까운 우주 먼지: 진행 방향 반대로 흐르는 가는 줄
vec3 spaceDust(vec3 ro, vec3 rd, vec3 vel, float pixAngle) {
    vec3 col = vec3(0.0);
    float speed = length(vel);
    if (speed < 1e-3) {
        return col;
    }
    for (int i = 1; i <= 6; i++) {
        float dist = float(i) * 3.0;
        vec3 p = ro + rd * dist;
        vec3 cell = floor(p / 2.5);
        vec3 h = hash33(cell);
        vec3 dp = (cell + h) * 2.5;
        float d = rayPointDist(ro, rd, dp);
        float streak = exp(-d * d / (0.0004 + pixAngle * pixAngle * dist * dist));
        col += vec3(0.6, 0.7, 0.8) * streak * step(0.7, h.x) * 0.25 / float(i);
    }
    return col * sat(speed * 0.05);
}

#endif

#ifndef BH_SKY_GLSL
#define BH_SKY_GLSL
#ifndef BH_FX_GLSL
#define BH_FX_GLSL

// 우주선 손상 효과(바닐라 파티클 대신): 하늘 셰이더가 지점을 화면에 투영해 데이터 칸에 쓰고, 후처리가 그린다.
// 지점 = show/ship_layout.json points(무대 원점 기준 블록), 우주선 기동 자세를 따라간다.
const int FX_SLOTS = 6;
const int FX_DATA_BASE = 8;

const vec3 P_NOSE = vec3(0.0, 0.05, -5.15);
const vec3 P_COCKPIT = vec3(0.0, 0.85, -3.0);
const vec3 P_WING_L = vec3(-3.1, -0.2, 2.1);
const vec3 P_WING_R = vec3(3.1, -0.2, 2.1);
const vec3 P_ANTENNA = vec3(0.35, 1.3, 0.92);
const vec3 P_ENGINE_L = vec3(-1.55, 0.12, 5.15);
const vec3 P_DORSAL = vec3(0.0, 0.98, 0.0);

const float BLAST_T[7] = float[](211.5, 224.5, 234.5, 398.4, 517.4, 764.2, 902.2);
const float BLAST_POWER[7] = float[](0.6, 1.0, 0.5, 0.9, 0.7, 1.0, 1.4);
const float BLAST_LEN = 1.8;

vec3 blastPoint(int i) {
    if (i == 0) {
        return P_WING_L;
    }
    if (i == 1) {
        return P_NOSE;
    }
    if (i == 2) {
        return P_WING_R;
    }
    if (i == 3) {
        return P_ANTENNA;
    }
    if (i == 4) {
        return P_ENGINE_L;
    }
    if (i == 5) {
        return P_COCKPIT;
    }
    return P_DORSAL;
}

// 칸 0 = 가장 최근 폭발, 1~5 = 손상 지점 불꽃·가스(시작 이후 계속)
// 돌려줌: 지점(무대 기준), x = 세기, y = 나이(초), z = 종류(0 폭발, 1 불꽃+가스)
vec3 fxSlot(int slot, float t, out vec3 point) {
    point = vec3(0.0);
    if (t >= 955.9 || t < 0.0) {
        return vec3(0.0);
    }
    if (slot == 0) {
        for (int i = 6; i >= 0; i--) {
            float age = t - BLAST_T[i];
            if (age >= 0.0 && age < BLAST_LEN) {
                point = blastPoint(i);
                return vec3(BLAST_POWER[i], age, 0.0);
            }
        }
        return vec3(0.0);
    }
    vec3 starts = vec3(0.0);
    float begin = 1e9;
    float end = 955.9;
    if (slot == 1) {
        point = P_NOSE;
        begin = 224.9;
    } else if (slot == 2) {
        point = P_ANTENNA;
        begin = 398.8;
    } else if (slot == 3) {
        point = P_ENGINE_L;
        begin = 517.9;
    } else if (slot == 4) {
        point = P_COCKPIT;
        begin = 764.6;
    } else {
        point = P_WING_R;
        begin = 234.8;
        end = 275.5;
    }
    if (t < begin || t > end) {
        return vec3(0.0);
    }
    float fade = remap(t, begin, begin + 0.5) * (1.0 - remap(t, end - 2.0, end));
    return vec3(fade, t - begin, 1.0);
}

#endif

#ifndef BH_ANNOT_DATA_GLSL
#define BH_ANNOT_DATA_GLSL

// tools/annot/build_annot.py 가 만든다(손으로 고치지 말 것)
const int ANN_COUNT = 24;
const float ANN_T0[24] = float[](35.40, 68.21, 77.38, 90.17, 138.00, 200.24, 261.50, 288.68, 300.51, 357.30, 367.71, 441.50, 461.94, 469.65, 497.40, 510.60, 638.20, 719.07, 734.72, 800.20, 809.01, 817.53, 823.26, 1009.30);
const float ANN_T1[24] = float[](44.20, 77.01, 86.18, 98.97, 145.20, 204.70, 270.20, 297.48, 309.31, 366.10, 375.94, 450.30, 470.30, 476.73, 506.20, 517.80, 646.10, 727.87, 743.18, 809.00, 817.81, 823.91, 831.80, 1018.10);
const int ANN_TARGET[24] = int[](0, 1, 2, 3, 22, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 16, 17, 18, 19, 20, 21);
const int ANN_STYLE[24] = int[](0, 1, 2, 0, 1, 0, 1, 0, 0, 1, 2, 1, 0, 0, 2, 4, 1, 0, 0, 1, 6, 1, 0, 4);
const vec2 LABELS_SIZE = vec2(1024.0, 768.0);

#endif

// 우주 합성: 장면마다 배경 → 먼 것 → 가까운 것 순으로 덮는다. 결과는 선형 HDR.


vec3 sunDisk(vec3 rd, vec3 s, float radius, float intensity) {
    float a = acos(clamp(dot(rd, s), -1.0, 1.0));
    float disk = smoothstep(radius * 1.05, radius * 0.95, a);
    float glare = exp(-a / (radius * 2.5)) * 0.35 + exp(-a / (radius * 12.0)) * 0.06;
    return vec3(1.0, 0.96, 0.9) * (disk * intensity + glare * intensity * 0.12);
}

// 먼 것부터 부르면 가까운 것이 덮는다
void over(inout vec3 col, vec4 layer) {
    col = mix(col, layer.rgb, layer.a);
}

float sceneExposure(int scene, float lt) {
    if (scene == S_SUN) {
        return mix(0.085, 0.75, sunGlare(lt));
    }
    if (scene == S_BETEL) {
        return 0.17;
    }
    if (scene == S_MARS) {
        return 1.15;
    }
    if (scene == S_JUPITER || scene == S_SATURN) {
        return 0.95;
    }
    if (scene == S_BH) {
        return mix(0.55, 0.26, smoothstep(60.0, 115.0, lt));
    }
    return 1.0;
}

void over2(inout vec3 col, vec4 a, float ta, vec4 b, float tb) {
    if (ta > tb) {
        over(col, a);
        over(col, b);
    } else {
        over(col, b);
        over(col, a);
    }
}

vec3 universe(sampler2D atlas, vec3 dirReal, Rig rig, vec3 camOffReal, float pixAngle) {
    vec3 rd = normalize(rig.basis * dirReal);
    vec3 fwd = rig.basis * vec3(0.0, 0.0, -1.0);
    int scene = rig.scene;
    float lt = rig.lt;
    float t = rig.t;
    vec3 s = rig.sunDir;
    vec3 ro = rig.pos;
    float warp = max(warpOut(t), warpIn(t));
    vec3 col = warp > 0.002 ? warpStreaks(atlas, rd, fwd, warp, pixAngle, scene) + slipstream(rd, fwd, warp, t) : background(atlas, rd, pixAngle, scene);
    float tA;
    float tB;

    if (scene == S_EARTH) {
        vec2 occ = raySphere(ro, s, vec3(0.0), 1.0);
        float sunVis = (occ.x < occ.y && occ.y > 0.0) ? 0.0 : 1.0;
        col += sunDisk(rd, s, 0.0047, 140.0) * sunVis;
        col += earthLimb(ro, rd, s);
        vec4 m = moon(atlas, ro, rd, s, pixAngle, tA);
        vec4 e = earth(atlas, ro, rd, s, t, pixAngle, tB);
        over2(col, m, tA, e, tB);
    } else if (scene == S_MARS) {
        col += sunDisk(rd, s, 0.0031, 130.0);
        vec4 m = mars(atlas, ro, rd, s, t, pixAngle, tA);
        col += m.a > 0.0 ? vec3(0.0) : m.rgb;
        over(col, m);
    } else if (scene == S_BELT) {
        col += sunDisk(rd, s, 0.0018, 120.0);
        col += vec3(0.20, 0.17, 0.12) * pow(sat(dot(rd, s) * 0.5 + 0.5), 6.0) * 0.05;
        vec4 far = rockLayers(ro * 0.25 + vec3(0.0, 40.0, 0.0), rd, s, 20.0, 18.0, 0.06, 0.3, 1.0, vec3(1.0, 0.9, 0.8), 0.0, 0.0, pixAngle, tB);
        over(col, vec4(far.rgb * 0.7, far.a));
        vec4 rocks = rockLayers(ro + camOffReal * 0.15, rd, s, 16.0, 10.0, 0.045, 0.2, 1.0, vec3(1.1, 0.95, 0.8), 0.0, 0.0, pixAngle, tA);
        vec4 big = bigAsteroid(ro, rd, s, BIG_ROCK_POS, BIG_ROCK_R, lt, tB);
        over2(col, rocks, tA, big, tB);
        col += spaceDust(ro, rd, vec3(0.0, 0.0, -28.0), pixAngle);
    } else if (scene == S_JUPITER) {
        col += sunDisk(rd, s, 0.0009, 100.0);
        vec4 j = jupiter(atlas, ro, rd, s, lt, pixAngle, tB);
        col += j.a > 0.0 ? vec3(0.0) : j.rgb;
        vec4 i = io(ro, rd, s, tA);
        over2(col, i, tA, j, tB);
    } else if (scene == S_SATURN) {
        col += sunDisk(rd, s, 0.0005, 100.0);
        over(col, saturn(atlas, ro, rd, s, lt, pixAngle, tA));
        float crossing = window(lt * (60.0 / 49.0), 50.0, 68.0, 2.0, 2.0);   // 토성 경로와 같은 압축(rigSaturn)
        if (crossing > 0.0) {
            const float K = 2400.0;
            vec3 lro = vec3(ro.x * K, ro.z * K, ro.y * K);
            vec3 lrd = vec3(rd.x, rd.z, rd.y);
            vec4 ice = rockLayers(lro, lrd, s.xzy, 7.0, 6.0, 0.10 * crossing, 0.05, 0.35, vec3(1.0), 1.0, 260.0, pixAngle, tB);
            over(col, ice);
        }
    } else if (scene == S_SUN) {
        vec4 su = sun(atlas, ro, rd, lt, tA);
        col += su.a > 0.0 ? vec3(0.0) : su.rgb;
        over(col, su);
        col += cmeShell(ro, rd, lt);
    } else if (scene == S_BETEL) {
        vec4 b = betelgeuse(atlas, ro, rd, lt, tA);
        col += b.a > 0.0 ? vec3(0.0) : b.rgb;
        over(col, b);
    } else if (scene == S_PULSAR) {
        col += pulsarNebula(ro, rd, t);
        col += pulsar(ro, rd, t, pixAngle);
    } else if (scene == S_BH) {
        vec3 outDir;
        vec4 bh = blackHole(atlas, ro, rd, lt, pixAngle, outDir);
        vec3 bg = warp > 0.002 ? col : background(atlas, normalize(outDir), pixAngle, scene);
        col = bh.rgb + bg * bh.a;
    } else if (scene == S_INSIDE) {
        col = insideSpace(ro, rd, t, lt);
    } else if (scene == S_END) {
        col = vec3(0.0);
    }

    col *= sceneExposure(scene, lt);
    return col;
}

// 화면 맨 아래 줄 왼쪽 칸에 후처리용 데이터(주 광원 화면 위치 등)
const vec3 DATA_CHECK = vec3(51.0, 153.0, 230.0) / 255.0;

vec3 encode16(float v) {
    float x = floor(sat(v) * 65535.0 + 0.5);
    return vec3(floor(x / 256.0), mod(x, 256.0), 0.0) / 255.0;
}

vec4 mainLight(Rig rig) {
    vec3 s = rig.sunDir;
    float intensity = 0.0;
    float size = 0.0;
    if (rig.scene == S_EARTH) {
        vec2 occ = raySphere(rig.pos, s, vec3(0.0), 1.01);
        intensity = (occ.x < occ.y && occ.y > 0.0) ? 0.0 : 1.0;
        size = 0.12;
    } else if (rig.scene == S_BELT) {
        intensity = 0.8;
        size = 0.06;
    } else if (rig.scene == S_JUPITER || rig.scene == S_SATURN) {
        vec2 occ = raySphere(rig.pos, s, vec3(0.0), 1.0);
        intensity = (occ.x < occ.y && occ.y > 0.0) ? 0.0 : 0.6;
        size = 0.04;
    } else if (rig.scene == S_PULSAR) {
        s = normalize(-rig.pos);
        intensity = 0.5 + 0.5 * pow(0.5 + 0.5 * cos(TAU * 1.4 * rig.t), 16.0);
        size = 0.05;
    } else if (rig.scene == S_IDLE) {
        intensity = 0.0;
    }
    return vec4(s, intensity * (1.0 - warpOut(rig.t)) * (1.0 - warpIn(rig.t)) + 0.0 * size);
}

vec2 screenUV(vec3 virtualDir, Rig rig, mat4 modelView, mat4 proj, out float front) {
    vec3 dirReal = transpose(rig.basis) * virtualDir;
    vec4 clip = proj * (modelView * vec4(dirReal, 0.0));
    front = step(1e-4, clip.w);
    return front > 0.0 ? clip.xy / clip.w * 0.5 + 0.5 : vec2(-1.0);
}

// 0 = 확인색, 1·2 = 주 광원(화면 uv 16비트·세기·장면), 3·4 = 블랙홀(화면 uv·세기·그림자 반지름)
float deviceDepth(vec4 clip) {
    float z = clip.z / clip.w;
    #ifdef RENDERPEARL_DEPTH_IS_ZERO_TO_ONE
    return z;
    #else
    return z * 0.5 + 0.5;
    #endif
}


// --- 홀로그램 주석 대상 -------------------------------------------------------

// 대상의 가상 중심과 반지름(blocks 아님, 장면 단위). 표면 지점은 보이는 면일 때만
bool annotTarget(int id, Rig rig, out vec3 center, out float radius) {
    center = vec3(0.0);
    radius = 1.0;
    float lt = rig.lt;
    if (id == 0) {
        center = rig.pos + rig.sunDir * 200.0;
        radius = 2.0;
    } else if (id == 2) {
        radius = 1.035;
    } else if (id == 3) {
        center = MOON_POS;
        radius = MOON_R;
    } else if (id == 4) {
        center = BIG_ROCK_POS;
        radius = BIG_ROCK_R;
    } else if (id == 6) {
        center = jupiterGRS(lt);
        radius = 0.12;
    } else if (id == 7) {
        vec3 sc = vec3(1.0, 1.0 / JUP_OBL, 1.0);
        vec2 h = raySphere(IO_POS * sc, normalize(-JUP_SUN * sc), vec3(0.0), 1.0);
        if (h.x > h.y) {
            return false;
        }
        center = (IO_POS * sc + normalize(-JUP_SUN * sc) * h.x) / sc;
        radius = 0.06;
    } else if (id == 9) {
        radius = 2.3;
    } else if (id == 11) {
        center = normalize(normalize(rig.pos) + vec3(0.12, -0.18, 0.0));
        radius = 0.06;
    } else if (id == 12) {
        center = SPOT_N;
        radius = 0.07;
    } else if (id == 13) {
        radius = 1.35;
    } else if (id == 14) {
        center = FLARE_N;
        radius = 0.1;
    } else if (id == 16) {
        radius = 0.05;
    } else if (id == 17 || id == 18) {
        radius = 5.2;
    } else if (id == 19) {
        radius = 26.0;
    } else if (id == 20) {
        center = vec3(0.0, 7.5, 0.0);
        radius = 2.5;
    } else if (id == 21) {
        center = INSIDE_SPHERE;
        radius = 26.0;
    }
    bool surface = id == 6 || id == 7 || id == 11 || id == 12 || id == 14;
    return !surface || dot(normalize(center), normalize(rig.pos - center)) > -0.02;
}

// 칸 3개: (u 16비트, v 상위) · (v 하위, 반지름, 보임) · (라벨 번호, 모양, 나타난 지 경과)
vec4 annotPixel(int slot, int part, Rig rig, mat4 modelView, mat4 proj) {
    int found = -1;
    int seen = 0;
    for (int i = 0; i < ANN_COUNT; i++) {
        if (rig.t >= ANN_T0[i] - 0.2 && rig.t < ANN_T1[i] + 0.6) {
            if (seen == slot) {
                found = i;
                break;
            }
            seen++;
        }
    }
    vec3 center;
    float radius;
    bool ok = found >= 0 && annotTarget(ANN_TARGET[found], rig, center, radius);
    float front = 0.0;
    vec2 uv = vec2(-1.0);
    float r = 0.0;
    if (ok) {
        vec3 to = center - rig.pos;
        float dist = length(to);
        uv = screenUV(to / dist, rig, modelView, proj, front);
        r = tan(asin(min(radius / dist, 0.999))) * proj[1][1] * 0.5;
    }
    float vis = found >= 0 && ok ? front * remap(rig.t, ANN_T0[found], ANN_T0[found] + 0.3) * (1.0 - remap(rig.t, ANN_T1[found], ANN_T1[found] + 0.6)) : 0.0;
    if (part == 0) {
        return vec4(encode16(uv.x * 0.25 + 0.375).xy, encode16(uv.y * 0.25 + 0.375).x, 1.0);
    }
    if (part == 1) {
        return vec4(encode16(uv.y * 0.25 + 0.375).y, sat(r / 0.6), vis, 1.0);
    }
    float age = found >= 0 ? sat((rig.t - ANN_T0[found]) / 1.2) : 0.0;
    return vec4(float(max(found, 0)) / 255.0, float(found >= 0 ? ANN_STYLE[found] : 0) / 255.0, age, 1.0);
}

// 효과 칸: 0 = 화면 uv(16비트 x, y 상위), 1 = (y 하위, 세기, 블록당 픽셀/4), 2 = (깊이 16비트, 나이·종류)
vec4 fxPixel(int slot, int part, Rig rig, mat4 modelView, mat4 proj, vec3 camWorld) {
    float t = rig.t;
    vec3 local;
    vec3 fx = fxSlot(slot, t, local);
    vec3 world = STAGE_ORIGIN + local;
    if (!isFirstPerson(camWorld) && t < T_IDLE) {
        ShipPose sp = shipPose(t);
        world = SHIP_PIVOT + shipRotation(t, sp) * (world - SHIP_PIVOT) + sp.offset + shipFlyOffset(t);
    }
    vec4 view = modelView * vec4(world - camWorld, 1.0);
    vec4 clip = proj * view;
    bool front = clip.w > 0.05 && fx.x > 0.0 && shipHidden(t) < 0.5;
    vec2 uv = front ? clip.xy / clip.w * 0.5 + 0.5 : vec2(-1.0);
    float px = front ? proj[1][1] / clip.w * ScreenSize.y * 0.5 : 0.0;
    if (part == 0) {
        return vec4(encode16(uv.x * 0.25 + 0.375).xy, encode16(uv.y * 0.25 + 0.375).x, 1.0);
    }
    if (part == 1) {
        return vec4(encode16(uv.y * 0.25 + 0.375).y, front ? sat(fx.x * 0.7) : 0.0, sat(px / 1020.0), 1.0);
    }
    return vec4(encode16(front ? deviceDepth(clip) : 0.0).xy, sat(fx.y / 2.0) * 0.5 + fx.z * 0.5 + 0.001, 1.0);
}

vec4 dataPixel(int x, Rig rig, mat4 modelView, mat4 proj, vec3 camWorld) {
    if (x == 0) {
        return vec4(DATA_CHECK, 1.0);
    }
    if (x >= 26 && x < 32) {
        return annotPixel((x - 26) / 3, (x - 26) % 3, rig, modelView, proj);
    }
    if (x >= FX_DATA_BASE && x < FX_DATA_BASE + FX_SLOTS * 3) {
        int i = x - FX_DATA_BASE;
        return fxPixel(i / 3, i % 3, rig, modelView, proj, camWorld);
    }
    float front;
    if (x == 5 || x == 6) {
        vec2 uv = screenUV(rig.basis * vec3(0.0, 0.0, -1.0), rig, modelView, proj, front);
        return x == 5 ? vec4(encode16(uv.x * 0.25 + 0.375).xy, encode16(uv.y * 0.25 + 0.375).x, 1.0)
                      : vec4(encode16(uv.y * 0.25 + 0.375).y, front, 0.0, 1.0);
    }
    if (x <= 2) {
        vec4 light = mainLight(rig);
        vec2 uv = screenUV(light.xyz, rig, modelView, proj, front);
        float on = front * light.w;
        return x == 1 ? vec4(encode16(uv.x * 0.25 + 0.375).xy, encode16(uv.y * 0.25 + 0.375).x, 1.0)
                      : vec4(encode16(uv.y * 0.25 + 0.375).y, on, float(rig.scene) / 255.0, 1.0);
    }
    if (x <= 4 && rig.scene == S_BH) {
        float r = length(rig.pos);
        vec2 uv = screenUV(normalize(-rig.pos), rig, modelView, proj, front);
        float strength = front * remap(rig.lt, 60.0, 140.0);
        float shadow = tan(asin(min(5.2 / r, 0.999))) * proj[1][1] * 0.5;
        return x == 3 ? vec4(encode16(uv.x * 0.25 + 0.375).xy, encode16(uv.y * 0.25 + 0.375).x, 1.0)
                      : vec4(encode16(uv.y * 0.25 + 0.375).y, strength, sat(shadow), 1.0);
    }
    return vec4(0.0, 0.0, 0.0, 1.0);
}

#endif

uniform sampler2D Sampler0;

layout(location = 0) in vec2 texCoord0;
layout(location = 1) in vec4 vertexColor;
layout(location = 2) in vec3 skyPos;
layout(location = 3) flat in vec4 rigA;
layout(location = 4) flat in vec4 rigB0;
layout(location = 5) flat in vec4 rigB1;
layout(location = 6) flat in vec4 rigB2;
layout(location = 7) flat in vec4 rigS;

layout(location = 0) out vec4 fragColor;

Rig unpackRig() {
    Rig rig;
    rig.pos = rigA.xyz;
    rig.scene = int(rigA.w + 0.5);
    rig.basis = mat3(rigB0.xyz, rigB1.xyz, rigB2.xyz);
    rig.lt = rigB0.w;
    rig.t = rigB1.w;
    rig.sunDir = rigS.xyz;
    rig.zoom = rigS.w;
    return rig;
}

void main() {
    if (rigB2.w > 0.5 && isUniverseAtlas(Sampler0)) {
        Rig rig = unpackRig();
        ivec2 px = ivec2(gl_FragCoord.xy);
        if (px.y == 0 && px.x < 32) {
            fragColor = dataPixel(px.x, rig, ModelViewMat, ProjMat, vec3(CameraBlockPos) - CameraOffset);
            return;
        }
        vec3 camPos = vec3(CameraBlockPos) - CameraOffset;
        mat3 view = mat3(ModelViewMat);
        vec3 dv = view * normalize(skyPos);
        dv.xy /= rig.zoom;
        float pixAngle = 2.0 / (ProjMat[1][1] * ScreenSize.y * rig.zoom);
        vec3 col = universe(Sampler0, normalize(transpose(view) * normalize(dv)), rig, camPos - STAGE_ORIGIN, pixAngle);
        fragColor = vec4(tonemap(col) * (1.0 - blackout(rig.t)), 1.0);
        return;
    }
    vec4 color = texture(Sampler0, texCoord0) * vertexColor;
    if (color.a == 0.0) {
        discard;
    }
    fragColor = color * ColorModulator;
}
