#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:light.glsl>
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:sample_lightmap.glsl>
#ifndef OIT
#include <minecraft:globals.glsl>
#include <bh:bh_common.glsl>
#include <bh:bh_timeline.glsl>
#include <bh:bh_material.glsl>
#endif

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
layout(location = 3) in ivec2 UV1;
layout(location = 4) in ivec2 UV2;
#ifdef GLINT_SPECIAL
layout(location = 5) in vec2 UV3;
#endif
layout(location = 6) in vec3 Normal;

#ifndef OIT_ALPHA_ONLY
uniform sampler2D Sampler1;
uniform sampler2D Sampler2;

layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif
layout(location = 2) out vec4 vertexColor;
#ifndef OIT_ALPHA_ONLY
layout(location = 3) out vec4 lightMapColor;
layout(location = 4) out vec4 overlayColor;
#endif

layout(location = 5) out vec2 texCoord0;
#ifdef GLINT
layout(location = 6) out vec2 texCoordGlint;
#endif

#ifndef OIT
layout(location = 7) flat out vec4 bhA;
layout(location = 8) out vec3 bhLight;
layout(location = 9) out vec3 bhSpec;
layout(location = 10) out vec3 bhView;
layout(location = 11) out vec2 bhCorner;
layout(location = 12) flat out vec4 bhKey;
layout(location = 13) flat out vec4 bhKeyColor;
#endif

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    #ifndef OIT_ALPHA_ONLY
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    #endif
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
    #ifndef OIT_ALPHA_ONLY
    lightMapColor = sample_lightmap(Sampler2, UV2);
    overlayColor = texelFetch(Sampler1, UV1, 0);
    #endif

    texCoord0 = UV0;
    #ifdef GLINT
    #ifdef GLINT_SPECIAL
    texCoordGlint = (TextureMat * vec4(UV3, 0.0, 1.0)).xy;
    #else
    texCoordGlint = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
    #endif
    #endif

    #ifndef OIT
    bhA = vec4(0.0);
    bhLight = vec3(0.0);
    bhSpec = vec3(0.0);
    bhView = vec3(0.0);
    bhCorner = vec2(0.0);
    bhKey = vec4(0.0);
    bhKeyColor = vec4(0.0);
    int mode = bhMaterialMode(Color);
    if (mode == BHM_NONE) {
        return;
    }
    float t = showTime(GameTime);
    bool ship = mode != BHM_ROCK && mode != BHM_ICE;
    vec3 camWorld = vec3(CameraBlockPos) - CameraOffset;
    vec3 pos = Position;
    vec3 n = normalize(Normal);
    if (ship && t < T_IDLE && !isFirstPerson(camWorld)) {
        ShipPose sp = shipPose(t);
        mat3 rot = shipRotation(t, sp);
        vec3 pivot = SHIP_PIVOT - camWorld;
        pos = pivot + rot * (Position - pivot) + sp.offset + shipFlyOffset(t);
        n = normalize(rot * Normal);
    }
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);
    Rig rig = rigAt(t);
    ShipLight l = shipLight(rig);
    vec3 worldPos = Position + camWorld;
    bhA = vec4(float(mode), bhMaterialSeed(Color), t, hash13(floor(worldPos * 2.0)));
    vec3 v = normalize(-pos);
    float em = emergencyOn(t);
    vec3 fill = l.fill + vec3(0.30, 0.015, 0.01) * em * (0.6 + 0.4 * sin(t * 3.0)) + vec3(0.35, 0.02, 0.01) * alarmOn(t) * pow(0.5 + 0.5 * sin(t * TAU * 1.2), 2.0) * 0.5;
    float wrapDiff = max((dot(n, l.keyDir) + 0.08) / 1.08, 0.0);
    bhLight = l.keyColor * wrapDiff + fill + l.rimColor * max(dot(n, l.rimDir), 0.0) + vec3(0.02, 0.022, 0.03);
    vec3 h = normalize(l.keyDir + v);
    bhSpec = l.keyColor * pow(max(dot(n, h), 0.0), 40.0) * 0.35 * step(0.0, dot(n, l.keyDir));
    bhView = (ModelViewMat * vec4(pos, 1.0)).xyz;
    int k = gl_VertexIndex % 4;
    bhCorner = vec2(k == 1 || k == 2 ? 1.0 : -1.0, k >= 2 ? 1.0 : -1.0);
    bhKey = vec4(mat3(ModelViewMat) * l.keyDir, ship ? shipHidden(t) : 0.0);
    bhKeyColor = vec4(l.keyColor + l.fill * 6.0, 0.0);
    #endif
}
