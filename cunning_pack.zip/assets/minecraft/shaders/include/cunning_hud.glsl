#ifndef CUNNING_HUD_GLSL
#define CUNNING_HUD_GLSL
#include <minecraft:globals.glsl>   // ScreenSize(11/20: 예전엔 팩의 projection.glsl 이 같이 줬다 — 시야각 강제를 걷어 내며 그 파일을 지움)

// 컨닝 2D 화면: 플러그인(cn.show.Hud)이 HUD_Y 블록 아래로 보낸 디스플레이 정점을 1920x1080 화면에 바로 찍는다(격투 akbfighter_hud 방식).
// 1px = 100 블록, x·y = 화면 가운데 기준(오른쪽·위 +), z = 층(클수록 앞). 세로는 화면에 꽉 차고 가로는 16:9 를 지킨다.
// 깊이: 26.x 는 깊이가 거꾸로(가까울수록 1)라 0.99 이상이면 세계(벽·반투명·파티클)보다 늘 앞(11/19, −0.99 는 잘려서 안 보였음).
bool cunning_hud() {
    if (Position.y > -500000.0) {
        return false;
    }
    vec3 p = vec3(Position.x, Position.y + 1000000.0, Position.z) / 100.0;
    float keep = 16.0 / 9.0 * ScreenSize.y / ScreenSize.x;   // 창 비율로
    gl_Position = vec4(p.x / 960.0 * keep, p.y / 540.0, 0.99 + p.z * 1.0e-5, 1.0);
    return true;
}

#endif
