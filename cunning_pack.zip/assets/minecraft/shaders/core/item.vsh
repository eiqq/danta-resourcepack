// 컨닝: 26.3 원본 + 끝에 2D 화면(cunning_hud)
#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:light.glsl>
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:sample_lightmap.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
layout(location = 3) in ivec2 UV1;
layout(location = 4) in ivec2 UV2;
#ifdef GLINT_SPECIAL
layout(location = 5) in vec2 UV3;
#endif
layout(location = 6) in vec3 Normal;

#ifndef OIT_ALPHA_ONLY
uniform sampler2D Sampler1;
uniform sampler2D Sampler2;

layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif
layout(location = 2) out vec4 vertexColor;
#ifndef OIT_ALPHA_ONLY
layout(location = 3) out vec4 lightMapColor;
layout(location = 4) out vec4 overlayColor;
#endif

layout(location = 5) out vec2 texCoord0;
layout(location = 7) flat out float cunningKeep;   // 컨닝: 시간 정지에도 색을 남길 인형(색 칸 = 255,254,255)
#ifdef GLINT
layout(location = 6) out vec2 texCoordGlint;
#endif

#include <minecraft:cunning_hud.glsl>

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    #ifndef OIT_ALPHA_ONLY
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    #endif
    cunningKeep = (Color.r > 0.999 && Color.b > 0.999 && abs(Color.g - 254.0 / 255.0) < 0.0015) ? 1.0 : 0.0;
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, cunningKeep > 0.5 ? vec4(1.0, 1.0, 1.0, Color.a) : Color);
    if (Color.r > 0.999 && Color.b > 0.999 && abs(Color.g - 252.0 / 255.0) < 0.0015) vertexColor = vec4(1.0, 1.0, 1.0, Color.a);   // 컨닝: 빛(섬광·고리, 색 칸 = 255,252,255 — pack_art.item(flat=True))은 음영 없이
    #ifndef OIT_ALPHA_ONLY
    lightMapColor = sample_lightmap(Sampler2, UV2);
    overlayColor = texelFetch(Sampler1, UV1, 0);
    #endif

    texCoord0 = UV0;
    #ifdef GLINT
    #ifdef GLINT_SPECIAL
    texCoordGlint = (TextureMat * vec4(UV3, 0.0, 1.0)).xy;
    #else
    texCoordGlint = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
    #endif
    #endif

    if (cunning_hud()) {
        vertexColor = Color;
        #ifndef OIT_ALPHA_ONLY
        sphericalVertexDistance = 0.0;
        cylindricalVertexDistance = 0.0;
        lightMapColor = vec4(1.0);
        overlayColor = vec4(1.0);
        #endif
    }
}
