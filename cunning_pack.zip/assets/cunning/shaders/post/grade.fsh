#version 330
#extension GL_ARB_separate_shader_objects : require

// 컨닝 화면 효과(프레임 끝 후처리). 효과 번호 fx 와 매개값 p(0~239)는 플러그인이 시계에 싣는다: 시계 = 4 × (fx × 240 + p)
//   21 광각 왜곡(거인 사냥: 가운데 부풂 + 가장자리 번짐, 세기 p/239 — 아래 bulge)
//   11/20: 시야각 강제는 없앴다. p = 그 효과의 세기·값(7 사고 가속: 가장자리 늘어짐 세기 p/239 · 20 주변 블러: 초점 거리 p/10 블록, 0 이면 5.5)
//   0 없음 · 1 재연(바랜 색) · 2 시간 정지(회녹색 무채) · 3 충격 프레임(흑백 반전 선화) · 4 흰 화면 · 5 검은 화면 · 6 정전 · 7 사고 가속(찬 색) · 8 시간 정지(색 남김) · 10~19 엔딩 단계 0~9 · 20 주변 블러(5.5블록 안만 선명, 깊이 버퍼)
#include <minecraft:globals.glsl>

uniform sampler2D MainSampler;
uniform sampler2D MainDepthSampler;

// 26.x 깊이는 거꾸로(가까울수록 1) → 카메라에서 거리(블록). near 0.05
float dist(vec2 uv) {
    return 0.05 / max(texture(MainDepthSampler, uv).r, 1e-7);
}

// 주변 블러: 초점 거리 F 보다 먼 곳만 흐린다. 선명한 앞(두 사람) 표본은 섞지 않아 테두리가 번지지 않는다
vec3 dof(vec2 uv, float F) {
    vec3 c0 = texture(MainSampler, uv).rgb;
    float k0 = clamp((dist(uv) - F) / 3.0, 0.0, 1.0);
    if (k0 <= 0.0) return c0;
    vec2 sz = vec2(textureSize(MainSampler, 0));
    float R = k0 * 11.0 * sz.y / 1080.0;
    vec3 acc = c0;
    float w = 1.0;
    for (int i = 1; i < 40; i++) {
        float a = float(i) * 2.39996;
        vec2 o = uv + vec2(cos(a), sin(a)) * sqrt(float(i) / 40.0) * R / sz;
        float k = clamp((dist(o) - F) / 3.0, 0.0, 1.0);
        acc += texture(MainSampler, o).rgb * k;
        w += k;
    }
    return acc / w;
}

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

// 사고 가속(브레인 악셀)의 '시야가 늘어남': 화면을 가운데로 살짝 당기고 가장자리를 바깥으로 길게 끈다 — 시야각은 건드리지 않는다
vec3 streak(vec2 uv, float k) {
    k *= smoothstep(0.12, 0.30, uv.y);   // 자막 띠(화면 아래 — bulge 와 같은 띠)는 걸지 않는다. 제작자 11/20 밤: "비네트 효과가 자막을 읽지못하게 흐트려트리는걸 확인"
    vec2 d = (uv - 0.5) * (1.0 - 0.06 * k);
    float r2 = dot(d, d);
    vec3 acc = vec3(0.0);
    for (int i = 0; i < 14; i++) {
        float s = 1.0 - k * 1.3 * r2 * (float(i) / 13.0);
        acc += texture(MainSampler, 0.5 + d * s).rgb;
    }
    return acc / 14.0;
}

// 광각 왜곡(fx 21 — 거인 사냥. 제작자 11/20: "왜곡같은거 사용해서 이재명이 더 빨라보이고 로봇이 모델보다 화면상에서 더 커보이는 연출"). 세기 k = p/239
//   ① 가운데를 부풀린다(어안): 가운데의 것이 1/(1 − 0.30k) 배(k 1 에서 1.43배)로 크고 가깝게 보인다. 화면 네 변에서는 0 이라 변 밖을 읽지 않는다
//   ② 가장자리의 그림을 바깥으로 길게 번지게 한다(속도). 시야각은 건드리지 않는다(후처리만)
//   자막이 사는 화면 아래 띠(texCoord.y < 0.12 — 아래가 0 쪽인 것은 11/20 게임에서 확인)는 걸지 않고 0.30 까지 부드럽게 풀린다. 띠가 위에 걸리면 SUB_FLIP 을 1.0 으로
const float SUB_FLIP = 0.0;
vec3 bulge(vec2 uv, float k) {
    k *= smoothstep(0.12, 0.30, mix(uv.y, 1.0 - uv.y, SUB_FLIP));
    vec2 d = uv - 0.5;
    float w = (1.0 - 4.0 * d.x * d.x) * (1.0 - 4.0 * d.y * d.y);   // 가운데 1 → 네 변 0
    vec2 c = d * (1.0 - 0.30 * k * w);
    float r2 = dot(d, d) * 2.0;                                     // 0(가운데) ~ 1(귀퉁이)
    vec3 acc = vec3(0.0);
    for (int i = 0; i < 10; i++) {
        float s = 1.0 - 0.16 * k * r2 * (float(i) / 9.0);          // 안쪽으로만 당겨 읽는다(|c·s| ≤ |d|) → 그림이 바깥으로 번진다
        acc += texture(MainSampler, 0.5 + c * s).rgb;
    }
    return acc / 10.0;
}

void main() {
    float code = floor(floor(GameTime * 24000.0 + 0.01) / 4.0 + 0.001);
    float fx = floor(code / 240.0 + 0.001);
    float p = mod(code, 240.0);
    vec3 c = fx == 20.0 ? dof(texCoord, p > 0.5 ? p / 10.0 : 5.5) : (fx == 7.0 && p > 0.5) ? streak(texCoord, p / 239.0) : (fx == 21.0 && p > 0.5) ? bulge(texCoord, p / 239.0) : texture(MainSampler, texCoord).rgb;
    float l = dot(c, vec3(0.299, 0.587, 0.114));
    if (fx == 1.0) {
        c = mix(vec3(l), c, 0.3);
        c = mix(c, vec3(1.0), 0.32);
        c *= vec3(0.98, 1.0, 1.03);
    } else if (fx == 2.0) {
        c = vec3(l) * vec3(0.9, 1.0, 0.94);
    } else if (fx == 8.0) {   // 시간 정지(색 남김): 화면 전체를 회녹색 무채로, 알파 표식(0.5 — item.fsh 가 남긴다)이 있는 화소만 색을 둔다
        // 자막의 빨간 강조 구절(Show.java EMPH — 6-44b "같은 방법으로")은 무채 속에서도 빨갛게 둔다: 화면 아래 자막 띠의 짙은 빨강 화소만(SUB_BAND — 위아래가 뒤집혀 있으면 1.0 - texCoord.y 로)
        bool redsub = texCoord.y < 0.10 && c.r > 0.72 && c.g < 0.42 && c.b < 0.42;
        if (!redsub && abs(texture(MainSampler, texCoord).a - 0.502) > 0.012) c = vec3(l) * vec3(0.9, 1.0, 0.94);
    } else if (fx == 3.0) {
        c = vec3(step(l, 0.42));
    } else if (fx == 4.0) {
        c = vec3(1.0);
    } else if (fx == 5.0) {
        c = vec3(0.0);
    } else if (fx == 6.0) {
        c = c * 0.05 + c * smoothstep(0.78, 0.95, l);   // 정전: 아주 밝은 것(햇빛 줄기)만 남는다
    } else if (fx == 7.0) {
        c = mix(c, vec3(l) * vec3(0.84, 0.95, 1.16), 0.65);   // 사고 가속: 차가운 색(리미트리스·투명한 세계)
    } else if (fx >= 10.0 && fx <= 19.0) {
        float k = (fx - 10.0) / 9.0;
        vec3 g = mix(c, vec3(l), 0.4 * k);                          // 채도를 빼고
        g *= mix(vec3(1.0), vec3(1.08, 0.97, 0.86), k);             // 노을빛
        g = mix(g, g * 0.9 + 0.07, k);                              // 종이처럼 들뜬 검정(밝게)
        vec2 d = texCoord - 0.5;
        g *= 1.0 - k * 0.8 * dot(d, d);                             // 비네트
        float lb = 0.1 * k;
        if (texCoord.y < lb || texCoord.y > 1.0 - lb) g = vec3(0.0);
        c = g;
    } else if (fx == 22.0) {   // 진짜 엔딩(제작자 11/20 밤: 세피아 같은 색감으로 순한맛, '페르소나'처럼 색과 스타일): 갈색 → 크림 두 색 + 살짝 층진 명암 + 비네트
        float t = smoothstep(0.04, 0.92, l);
        t = mix(t, floor(t * 5.0 + 0.5) / 5.0, 0.4);
        vec3 g = mix(vec3(0.21, 0.13, 0.10), vec3(0.99, 0.93, 0.80), t);
        g = mix(g, c, 0.2);
        vec2 d = texCoord - 0.5;
        g *= 1.0 - 0.7 * dot(d, d);
        if (p > 19.5) g *= (p - 20.0) / 219.0;   // 암전과 밝아짐(샷의 dip·fade — 플러그인이 p 를 20(검정) → 239 로 올린다). p 0~19 = 다 밝음
        c = g;
    }
    fragColor = vec4(c, 1.0);
}
